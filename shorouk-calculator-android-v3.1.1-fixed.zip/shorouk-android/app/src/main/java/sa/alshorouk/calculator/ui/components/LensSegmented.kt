package sa.alshorouk.calculator.ui.components

import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.launch
import sa.alshorouk.calculator.ui.LocalHaptics
import sa.alshorouk.calculator.ui.LocalMotion
import sa.alshorouk.calculator.ui.LocalPalette
import sa.alshorouk.calculator.ui.glass.GlassQuality
import sa.alshorouk.calculator.ui.glass.GlassSpec
import sa.alshorouk.calculator.ui.glass.GlassSurface
import sa.alshorouk.calculator.ui.glass.LocalGlass
import sa.alshorouk.calculator.ui.glass.Refraction
import sa.alshorouk.calculator.ui.motion.Springs
import sa.alshorouk.calculator.ui.motion.rubberBand
import kotlin.math.abs
import kotlin.math.roundToInt

/*
 * Segmented control with a liquid lens (components/LensSegmented.tsx).
 *
 * The selected option sits on a soft pill; over it rides a clear lens that magnifies what is underneath.
 * Tap an option and the lens springs across, stretching with its speed like a drop of water; grab it and
 * drag: it lifts off the surface, follows the finger, resists at the ends and settles on the nearest
 * option carrying the speed of the throw.
 *
 * The lens is real: the options are recorded once into a GPU layer, drawn normally with a hole where the
 * lens is, and drawn again inside the lens — magnified, and on Android 13+ bent by the drop's curved edge with
 * the same shader as every pane (a label sliding under the drop squeezes at its rim, as under real glass).
 * Moving the lens re-records nothing: only the lens's few uniforms change.
 */
@Composable
fun <T> LensSegmented(
    options: List<T>,
    selected: T,
    onSelect: (T) -> Unit,
    label: (T) -> String,
    modifier: Modifier = Modifier,
    onTrack: Boolean = true,
    radius: Dp = 28.dp,
    pad: Dp = 5.dp,
    height: Dp = 46.dp,
    trackColor: Color = Color.Unspecified,
    content: @Composable (option: T, selected: Boolean) -> Unit,
) {
    val p = LocalPalette.current
    val haptics = LocalHaptics.current
    val motion = LocalMotion.current
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val index = options.indexOf(selected).coerceAtLeast(0)
    val pos = remember { Animatable(index.toFloat()) }      // logical position: 0 … n − 1
    val lift = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val latestSelect by rememberUpdatedState(onSelect)
    // The gesture below is started once and lives on; it must always see the selection as it is now,
    // not as it was when the gesture code was first set up (that was the "drags one way only" bug).
    val currentIndex by rememberUpdatedState(index)
    val currentOptions by rememberUpdatedState(options)
    var dragging by remember { mutableIntStateOf(0) }

    // whatever ended the drag, the drop never stays lifted
    LaunchedEffect(dragging) {
        if (dragging == 0 && lift.value != 0f) lift.animateTo(0f, Springs.LensLift.float)
    }
    LaunchedEffect(index) {
        if (dragging == 0) {
            if (motion) pos.animateTo(index.toFloat(), Springs.LensTravel.float) else pos.snapTo(index.toFloat())
        }
    }

    val track: @Composable (Modifier, @Composable () -> Unit) -> Unit = { m, inner ->
        if (onTrack) {
            GlassSurface(m, radius = radius, spec = GlassSpec(bezel = 18.dp, depth = 20.dp, blur = 3.dp)) { inner() }
        } else {
            Box(m.background(if (trackColor == Color.Unspecified) p.well else trackColor, RoundedCornerShape(radius))) { inner() }
        }
    }

    track(modifier.fillMaxWidth()) {
        BoxWithConstraints(Modifier.fillMaxWidth().padding(pad)) {
            val density = LocalDensity.current
            val n = options.size
            val segW = with(density) { maxWidth.toPx() } / n
            val h = with(density) { height.toPx() }
            val r = h / 2f
            val recorded = rememberGraphicsLayer()
            val lensLayer = rememberGraphicsLayer()
            // the drop's own optics (Android 13+); without them it still magnifies
            val optics = remember {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) runCatching { Refraction() }.getOrNull() else null
            }
            val refracting = LocalGlass.current.settings.quality == GlassQuality.Full

            fun lensRect(): RoundRect {
                val v = pos.value
                val left = if (rtl) (n - 1 - v) * segW else v * segW
                val speed = abs(pos.velocity) * segW
                val stretch = (speed / 2600f).coerceAtMost(0.22f)
                val l = lift.value
                val sx = 1f + stretch + l * 0.05f
                val sy = 1f - stretch * 0.25f + l * 0.14f
                val cx = left + segW / 2f
                val cy = h / 2f
                val w = segW * sx
                val hh = h * sy
                return RoundRect(cx - w / 2f, cy - hh / 2f, cx + w / 2f, cy + hh / 2f, CornerRadius(r * sy))
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .height(height)
                    .selectableGroup()
                    .drawWithContent {
                        val lens = lensRect()
                        drawPill(lens, p.pill.first, p.pill.second, p.hairline)
                        recorded.record { this@drawWithContent.drawContent() }
                        val hole = Path().apply { addRoundRect(lens) }
                        clipPath(hole, ClipOp.Difference) { drawLayer(recorded) }
                        // inside the lens: the same options, a little larger — and, where the device can,
                        // bent by the curved edge of the drop exactly like every other piece of glass here
                        val lifted = lift.value
                        val mag = 1.04f + lifted * 0.1f
                        val lensW = lens.right - lens.left
                        val lensH = lens.bottom - lens.top
                        // The drop bends what is under it while it is in the hand or on its way — that is
                        // when a label slides under its rim. At rest it is a still, flat pill: a wordmark
                        // that reaches the rim (the Arabic «تابي», with its dots) is left exactly as drawn.
                        val travelling = (abs(pos.velocity) / 2.2f).coerceAtMost(1f)
                        val alive = maxOf(lifted.coerceIn(0f, 1f), travelling)
                        val bent = if (alive > 0.02f && optics != null && refracting && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            optics.lens(
                                ox = lens.left, oy = lens.top, w = lensW, h = lensH, radius = lensH / 2f,
                                bezel = lensH * 0.36f, depth = lensH * 0.3f * alive,
                                dispersion = 0.045f, magnify = mag, cutout = true, input = null,
                            )
                        } else null
                        if (bent != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            lensLayer.renderEffect = bent.asComposeRenderEffect()
                            lensLayer.record { drawLayer(recorded) }
                            drawLayer(lensLayer)
                        } else {
                            val lensCentre = Offset((lens.left + lens.right) / 2f, (lens.top + lens.bottom) / 2f)
                            clipPath(hole) {
                                withTransform({ scale(mag, mag, lensCentre) }) { drawLayer(recorded) }
                            }
                        }
                        drawLensRim(lens, p.rim, lifted)
                    }
                    .pointerInput(n, rtl, segW) {
                        val tracker = VelocityTracker()
                        var start = 0f
                        var acc = 0f
                        var lastSnap = -1
                        detectHorizontalDragGestures(
                            onDragStart = {
                                dragging = 1
                                tracker.resetTracking()
                                start = pos.value
                                acc = 0f
                                lastSnap = start.roundToInt()
                                scope.launch { lift.animateTo(1f, Springs.LensLift.float) }
                            },
                            onDragEnd = {
                                dragging = 0
                                val v = tracker.calculateVelocity().x / segW * (if (rtl) -1f else 1f)
                                // where the throw would carry it, then the nearest option
                                val target = (pos.value + v * 0.12f).roundToInt().coerceIn(0, n - 1)
                                scope.launch { lift.animateTo(0f, Springs.LensLift.float) }
                                scope.launch(start = CoroutineStart.UNDISPATCHED) { pos.animateTo(target.toFloat(), Springs.LensTravel.float, initialVelocity = v) }
                                if (target != currentIndex) latestSelect(currentOptions[target])
                            },
                            onDragCancel = {
                                dragging = 0
                                val home = currentIndex
                                scope.launch { lift.animateTo(0f, Springs.LensLift.float) }
                                scope.launch { pos.animateTo(home.toFloat(), Springs.LensTravel.float) }
                            },
                        ) { change, amount ->
                            tracker.addPosition(change.uptimeMillis, change.position)
                            acc += amount / segW * (if (rtl) -1f else 1f)
                            var next = start + acc
                            val max = (n - 1).toFloat()
                            if (next < 0f) next = rubberBand(next, 1f, 0.35f)
                            if (next > max) next = max + rubberBand(next - max, 1f, 0.35f)
                            // at once, inside this pointer event: the drop is under the finger in the same frame
                            scope.launch(start = CoroutineStart.UNDISPATCHED) { pos.snapTo(next) }
                            val snap = next.roundToInt().coerceIn(0, n - 1)
                            if (snap != lastSnap) { lastSnap = snap; haptics.tick() }
                        }
                    },
            ) {
                options.forEachIndexed { i, option ->
                    val isSelected = i == index
                    Box(
                        Modifier
                            .weight(1f)
                            .height(height)
                            .selectable(
                                selected = isSelected,
                                interactionSource = null,
                                indication = null,
                                role = Role.Tab,
                                onClick = {
                                    if (!isSelected) { haptics.tick(); latestSelect(option) }
                                },
                            )
                            .semantics { contentDescription = label(option) },
                        contentAlignment = Alignment.Center,
                    ) { content(option, isSelected) }
                }
            }
        }
    }
}

private fun DrawScope.drawPill(r: RoundRect, top: Color, bottom: Color, hairline: Color) {
    val path = Path().apply { addRoundRect(r) }
    // soft shadow under the pill
    val shadowOffsetY = 3.dp.toPx()
    withTransform({ translate(0f, shadowOffsetY) }) {
        drawPath(path, Color(0x220D3438))
    }
    drawPath(path, Brush.verticalGradient(listOf(top, bottom), r.top, r.bottom))
    drawPath(path, hairline, style = Stroke(0.5.dp.toPx()))
}

private fun DrawScope.drawLensRim(r: RoundRect, rim: Color, lift: Float) {
    val path = Path().apply { addRoundRect(r) }
    drawPath(
        path,
        Brush.verticalGradient(listOf(rim.copy(alpha = 0.95f), rim.copy(alpha = 0.18f + lift * 0.2f), rim.copy(alpha = 0.6f)), r.top, r.bottom),
        style = Stroke((1f + lift * 0.6f).dp.toPx()),
    )
    if (lift > 0.01f) {
        // a drop of glass lifted off the surface catches a highlight on its upper left
        drawPath(
            path,
            Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.5f * lift), Color.Transparent),
                center = Offset(r.left + r.width * 0.3f, r.top + r.height * 0.1f),
                radius = r.width * 0.6f,
            ),
        )
    }
}
