/*
 * The Arabic typeface: خط ثمانية (Thmanyah Serif Display), Regular and Bold.
 *
 * It is used for Arabic letters only. Digits, Latin and symbols stay in IBM Plex Sans, because amounts
 * need figures of equal width (they roll like an odometer and line up in the breakdown) and this
 * typeface's figures are proportional. The split is done with a unicode-range on the font faces.
 *
 * The files ship packed inside the app (see tools/pack-fonts.mjs for why) and are unpacked here in memory.
 */

export const ARABIC_FAMILY = 'Thmanyah Serif Display';
const ARABIC_RANGE = 'U+0600-06FF, U+0750-077F, U+08A0-08FF, U+FB50-FDFF, U+FE70-FEFF';
const ARABIC_SCALE = '110%';
const PACK_URL = './type/thmanyah.pack';

let loading: Promise<boolean> | null = null;

async function load(): Promise<boolean> {
    if (typeof FontFace === 'undefined' || typeof DecompressionStream === 'undefined' || !document.fonts) return false;
    const response = await fetch(new URL(PACK_URL, document.baseURI).href);
    if (!response.ok || !response.body) return false;
    const bytes = new Uint8Array(await new Response(response.body.pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());
    if (String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]) !== 'SHF1') return false;

    const view = new DataView(bytes.buffer);
    const count = bytes[4];
    let offset = 5 + count * 6;
    const faces: FontFace[] = [];
    for (let i = 0; i < count; i++) {
        const weight = view.getUint16(5 + i * 6, true);
        const length = view.getUint32(7 + i * 6, true);
        const file = bytes.buffer.slice(offset, offset + length);
        offset += length;
        // sizeAdjust: this display face draws its letters smaller than the Latin figures beside them
        const descriptors = { weight: String(weight), style: 'normal', unicodeRange: ARABIC_RANGE, sizeAdjust: ARABIC_SCALE };
        faces.push(new FontFace(ARABIC_FAMILY, file, descriptors as FontFaceDescriptors));
    }
    await Promise.all(faces.map((face) => face.load()));
    faces.forEach((face) => document.fonts.add(face));
    return true;
}

/** Resolves true once the typeface is usable. Safe to call again: the work is done once. */
export function loadArabicType(): Promise<boolean> {
    if (!loading) {
        loading = load().catch(() => false).then((ok) => {
            if (!ok) loading = null;          // offline on a first visit: try again next time it is asked for
            return ok;
        });
    }
    return loading;
}
