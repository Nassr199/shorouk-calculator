/*
 * Amount field helpers.
 * The calculation keeps receiving the same plain number string as before ("2500.5");
 * these helpers only decide what the person sees while typing ("2,500.5") and where the caret goes.
 */

export const MAX_INT_DIGITS = 9;
export const MAX_DEC_DIGITS = 2;

const ARABIC_INDIC = '٠١٢٣٤٥٦٧٨٩';
const PERSIAN = '۰۱۲۳۴۵۶۷۸۹';

/** Arabic-Indic and Persian digits become 0-9, the Arabic decimal mark becomes '.', separators and spaces go. */
export function normalizeDigits(text: string): string {
    let out = '';
    for (const ch of text) {
        const a = ARABIC_INDIC.indexOf(ch);
        const p = PERSIAN.indexOf(ch);
        if (a !== -1) out += String(a);
        else if (p !== -1) out += String(p);
        else if (ch === '٫') out += '.';
        else if (ch === ',' || ch === '٬' || /\s/.test(ch)) continue;
        else out += ch;
    }
    return out;
}

/**
 * Turns raw field text into the canonical number string, or returns null when the edit
 * should be refused (a second decimal point, too many digits) so the field keeps its old value.
 */
export function toCanonical(raw: string): string | null {
    const cleaned = normalizeDigits(raw).replace(/[^0-9.]/g, '');
    if ((cleaned.match(/\./g) || []).length > 1) return null;

    const dot = cleaned.indexOf('.');
    let int = dot === -1 ? cleaned : cleaned.slice(0, dot);
    const dec = dot === -1 ? null : cleaned.slice(dot + 1);

    int = int.replace(/^0+(?=\d)/, '');
    if (int.length > MAX_INT_DIGITS) return null;
    if (dec !== null && dec.length > MAX_DEC_DIGITS) return null;

    if (dec === null) return int;
    return `${int === '' ? '0' : int}.${dec}`;
}

/**
 * First amount found in pasted text, decimals cut to two:
 * "1,500.00 ر.س" → "1500.00", "SAR 2,727.91" → "2727.91", "٢٬٥٠٠٫٥٠ ر.س" → "2500.50". null if there is none.
 */
export function extractAmount(text: string): string | null {
    const match = normalizeDigits(text).match(/\d+(?:\.\d*)?|\.\d+/);
    if (!match) return null;
    const [int, dec] = match[0].split('.');
    return dec === undefined ? int : `${int}.${dec.slice(0, MAX_DEC_DIGITS)}`;
}

/** Does typed or dropped text contain anything an amount can use (a digit or a decimal mark)? */
export function hasAmountChars(text: string): boolean {
    return /[0-9.٫]/.test(normalizeDigits(text));
}

/** "2500.5" → "2,500.5" (a trailing "." is kept while the person is still typing). */
export function toDisplay(canonical: string): string {
    if (canonical === '') return '';
    const dot = canonical.indexOf('.');
    const int = dot === -1 ? canonical : canonical.slice(0, dot);
    const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return dot === -1 ? grouped : `${grouped}.${canonical.slice(dot + 1)}`;
}

/** How many digits / decimal points sit before the caret. */
export function significantBefore(text: string, caret: number): number {
    return normalizeDigits(text.slice(0, caret)).replace(/[^0-9.]/g, '').length;
}

/** Caret index in the formatted text that follows the same number of digits / points. */
export function caretAfterSignificant(display: string, count: number): number {
    if (count <= 0) return 0;
    let seen = 0;
    for (let i = 0; i < display.length; i++) {
        if (display[i] !== ',') {
            seen++;
            if (seen === count) return i + 1;
        }
    }
    return display.length;
}

/** Rough width of the formatted value in em, used to shrink long numbers so they always fit. */
export function emWidth(display: string, digitEm = 0.6, sepEm = 0.3): number {
    let w = 0;
    for (const ch of display) w += /\d/.test(ch) ? digitEm : sepEm;
    return Math.max(w, digitEm);
}
