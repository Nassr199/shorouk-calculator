import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'sa.shorouk.calculator',
  appName: 'حاسبة الشروق',
  webDir: 'dist',
  android: {
    backgroundColor: '#A9C8D3',
    allowMixedContent: false,
    webContentsDebuggingEnabled: false,
    loggingBehavior: 'none',
  },
};

export default config;
