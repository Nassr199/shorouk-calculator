package sa.alshorouk.calculator.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sa.alshorouk.calculator.core.Amount
import sa.alshorouk.calculator.core.CalculationResult
import sa.alshorouk.calculator.core.fill
import sa.alshorouk.calculator.core.formatMoney
import sa.alshorouk.calculator.core.formatPercent
import sa.alshorouk.calculator.core.splitMoney
import sa.alshorouk.calculator.ui.LocalPalette
import sa.alshorouk.calculator.ui.LocalStrings
import sa.alshorouk.calculator.ui.LocalType
import sa.alshorouk.calculator.ui.glass.GlassSpec
import sa.alshorouk.calculator.ui.glass.GlassSurface
import sa.alshorouk.calculator.ui.glass.rememberPressFx
import sa.alshorouk.calculator.ui.motion.Springs

/*
 * The one large pane (components/ResultSlab.tsx). The sun rises behind it, so the amount is read through
 * lit glass. Tapping the amount copies it. Below: what reaches the store and what goes in fees, and a bar.
 */
@Composable
fun ResultSlab(
    result: CalculationResult,
    sun: () -> Float,
    onCopy: () -> Unit,
    onPlaced: (LayoutCoordinates) -> Unit,
    compact: Boolean,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val s = LocalStrings.current
    val type = LocalType.current
    val ready = result.hasAmount
    val money = "${formatMoney(result.x)} ${s.currency}"
    val shown by animateFloatAsState(if (ready) 1f else 0f, Springs.Gentle.float, label = "slab")

    GlassSurface(
        modifier = modifier.fillMaxWidth().onGloballyPositioned(onPlaced),
        radius = 34.dp,
        spec = GlassSpec(bezel = 30.dp, depth = 32.dp, blur = 4.dp, dispersion = 0.04f),
    ) {
        // the sun's light inside the top of the pane
        Spacer(
            Modifier.matchParentSize().graphicsLayer { alpha = sun().coerceIn(0f, 1f) }.drawBehind {
                drawRect(Brush.verticalGradient(listOf(Color(255, 212, 132, 150), Color.Transparent), 0f, 34.dp.toPx()))
            },
        )
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = if (compact) 12.dp else 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            BasicText(
                s.resultLabel,
                style = type.labelSmall.copy(color = p.ink2, textAlign = TextAlign.Center),
                modifier = Modifier.semantics { heading() },
            )

            // the amount: tap to copy
            val source = remember { MutableInteractionSource() }
            val fx = rememberPressFx(source)
            BoxWithConstraints(
                Modifier
                    .padding(top = 2.dp)
                    .fillMaxWidth()
                    .height(67.dp)
                    .graphicsLayer {
                        val k = 1f - 0.04f * fx.swell.value
                        scaleX = k; scaleY = k
                    }
                    .clickable(source, null, enabled = ready, role = Role.Button, onClickLabel = fill(s.copyThis, mapOf("X" to money)), onClick = onCopy)
                    .clearAndSetSemantics {
                        contentDescription = if (ready) fill(s.copyThis, mapOf("X" to money)) else money
                    },
                contentAlignment = Alignment.Center,
            ) {
                val density = LocalDensity.current
                val em = Amount.emWidth(splitMoney(result.x).int, 0.62f, 0.3f) + 1.9f
                val fit = with(density) { ((maxWidth - 60.dp).toPx() / em).toSp() }
                // The figures are always shaped at one size; a long amount is scaled down to fit, on a
                // spring. Nothing is re-measured as the amount grows, and the size never jumps.
                val fitted by animateFloatAsState((minOf(FULL_SP, fit.value).coerceAtLeast(20f)) / FULL_SP, Springs.Settle.float, label = "amountFit")
                val color = if (ready) p.ink else p.ink3.copy(alpha = 0.7f)
                Row(
                    Modifier.wrapContentWidth(unbounded = true).graphicsLayer { scaleX = fitted; scaleY = fitted },
                    verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.Center,
                ) {
                    // as on the web: figures, then the currency (the row mirrors it into place in Arabic)
                    RollingNumber(result.x, type.money(FULL_SP.sp, FontWeight.SemiBold), color)
                    Currency(s.currency, FULL_SP, color)
                }
            }

            // what it is made of; until there is an amount, a line saying what to do
            Box(Modifier.fillMaxWidth().padding(top = 12.dp), contentAlignment = Alignment.Center) {
                Column(
                    Modifier.fillMaxWidth().graphicsLayer { alpha = shown; translationY = (1f - shown) * 6.dp.toPx() },
                ) {
                    Legend(result)
                    Spacer(Modifier.height(10.dp))
                    CompositionBar(
                        net = result.pInput, fee = result.totalServiceFee, settle = result.sFinal,
                        description = fill(s.breakdownLabel, mapOf(
                            "X" to money, "P" to "${formatMoney(result.pInput)} ${s.currency}",
                            "F" to "${formatMoney(result.fees)} ${s.currency}",
                        )),
                    )
                }
                if (shown < 0.99f) {
                    BasicText(
                        s.resultEmpty,
                        style = type.labelSmall.copy(color = p.ink2, textAlign = TextAlign.Center, fontWeight = FontWeight.Normal),
                        modifier = Modifier.fillMaxWidth(0.82f).graphicsLayer { alpha = 1f - shown },
                    )
                }
            }
        }
    }
}

/** The size the amount is shaped at, sp; narrower panes scale it down. */
private const val FULL_SP = 56f

@Composable
private fun Currency(text: String, sizeSp: Float, color: Color) {
    val type = LocalType.current
    BasicText(
        text,
        style = type.caption.copy(color = color.copy(alpha = color.alpha * 0.8f), fontSize = (sizeSp * 0.32f).coerceAtLeast(11f).sp, fontWeight = FontWeight.Medium),
        modifier = Modifier.padding(horizontal = 5.dp).padding(bottom = (sizeSp * 0.24f).dp),
    )
}

@Composable
private fun Legend(r: CalculationResult) {
    val p = LocalPalette.current
    val s = LocalStrings.current
    val type = LocalType.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Swatch(p.petrol); Spacer(Modifier.width(6.dp))
                BasicText(s.netShort, style = type.caption.copy(color = p.ink2))
            }
            BasicText(formatMoney(r.pInput), style = type.money(16.sp).copy(color = p.ink))
        }
        Column(horizontalAlignment = Alignment.End) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Swatch(p.amber); Spacer(Modifier.width(6.dp))
                BasicText(s.feesShort, style = type.caption.copy(color = p.ink2))
                Spacer(Modifier.width(6.dp))
                BasicText(
                    fill(s.feeShare, mapOf("R" to formatPercent(r.feeShare))),
                    style = type.caption.copy(color = p.ink3, fontFeatureSettings = "tnum"),
                )
            }
            BasicText(formatMoney(r.fees), style = type.money(16.sp).copy(color = p.ink))
        }
    }
}

@Composable
private fun Swatch(color: Color) {
    Spacer(Modifier.size(8.dp).background(color, CircleShape))
}

/** Net | fees | settlement, sliding to their new shares on springs; drawn, never laid out per frame. */
@Composable
private fun CompositionBar(net: Double, fee: Double, settle: Double, description: String) {
    val p = LocalPalette.current
    val total = net + fee + settle
    // with no amount the bar keeps its last shares while it fades out
    val last = remember { floatArrayOf(0.9f, 1f) }
    if (total > 0) { last[0] = (net / total).toFloat(); last[1] = ((net + fee) / total).toFloat() }
    val a by animateFloatAsState(last[0], Springs.Spring.float, label = "a")
    val b by animateFloatAsState(last[1], Springs.Spring.float, label = "b")
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Canvas(Modifier.fillMaxWidth().height(7.dp).semantics { contentDescription = description }) {
        val gap = 1.5.dp.toPx()
        val r = CornerRadius(size.height / 2)
        drawRoundRect(p.well, cornerRadius = r)
        fun seg(from: Float, to: Float, color: Color) {
            val w = (to - from) * size.width
            if (w <= 0.5f) return
            val x = if (rtl) size.width - to * size.width else from * size.width
            drawRoundRect(color, Offset(x + gap / 2, 0f), Size((w - gap).coerceAtLeast(0f), size.height), r)
        }
        seg(0f, a, p.petrol)
        seg(a, b, p.amber)
        seg(b, 1f, p.ember)
    }
}
