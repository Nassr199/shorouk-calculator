import React from 'react';

type IconProps = React.SVGProps<SVGSVGElement> & { size?: number };

const strokeProps = (size: number): React.SVGProps<SVGSVGElement> => ({
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.75,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    'aria-hidden': true,
    focusable: 'false',
});

export const IconCopy = ({ size = 20, ...rest }: IconProps) => (
    <svg {...strokeProps(size)} {...rest}>
        <rect x="8.5" y="8.5" width="11.5" height="11.5" rx="2.75" />
        <path d="M15.5 8.5V6.75A2.75 2.75 0 0 0 12.75 4h-6A2.75 2.75 0 0 0 4 6.75v6a2.75 2.75 0 0 0 2.75 2.75H8.5" />
    </svg>
);

export const IconCheck = ({ size = 20, ...rest }: IconProps) => (
    <svg {...strokeProps(size)} {...rest}>
        <path d="M5 12.6l4.3 4.3L19 7.2" />
    </svg>
);

export const IconSend = ({ size = 20, ...rest }: IconProps) => (
    <svg {...strokeProps(size)} {...rest}>
        <path d="M20.5 3.5L10.6 13.4" />
        <path d="M20.5 3.5l-6.3 17-3.6-7.1-7.1-3.6 17-6.3z" />
    </svg>
);

export const IconPrinter = ({ size = 20, ...rest }: IconProps) => (
    <svg {...strokeProps(size)} {...rest}>
        <path d="M7 8.5V4h10v4.5" />
        <path d="M7 17H5.5A2.5 2.5 0 0 1 3 14.5V11a2.5 2.5 0 0 1 2.5-2.5h13A2.5 2.5 0 0 1 21 11v3.5a2.5 2.5 0 0 1-2.5 2.5H17" />
        <rect x="7" y="13.5" width="10" height="7" rx="1.25" />
    </svg>
);

export const IconChevron = ({ size = 20, ...rest }: IconProps) => (
    <svg {...strokeProps(size)} {...rest}>
        <path d="M6.5 9.5l5.5 5.5 5.5-5.5" />
    </svg>
);

export const IconClose = ({ size = 20, ...rest }: IconProps) => (
    <svg {...strokeProps(size)} strokeWidth={2.25} {...rest}>
        <path d="M8 8l8 8M16 8l-8 8" />
    </svg>
);

export const IconBank = ({ size = 20, ...rest }: IconProps) => (
    <svg {...strokeProps(size)} {...rest}>
        <path d="M3.5 9.5L12 4.5l8.5 5" />
        <path d="M5.5 10.5v7M9.8 10.5v7M14.2 10.5v7M18.5 10.5v7" />
        <path d="M3.5 20h17" />
    </svg>
);

export const IconReceipt = ({ size = 20, ...rest }: IconProps) => (
    <svg {...strokeProps(size)} {...rest}>
        <path d="M6 4.6a1.1 1.1 0 0 1 1.1-1.1h9.8A1.1 1.1 0 0 1 18 4.6v15.6l-2.4-1.5-2.4 1.5-2.4-1.5-2.4 1.5L6 20.2z" />
        <path d="M9.3 8.3h5.4M9.3 11.7h5.4M9.3 15.1h2.8" />
    </svg>
);

/** Sun over a horizon line; the sun sets and the moon rises when the theme turns dark. */
export const ThemeGlyph = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"
        strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">
        <defs>
            <clipPath id="theme-glyph-sky">
                <rect x="0" y="0" width="24" height="18.4" />
            </clipPath>
        </defs>
        <g clipPath="url(#theme-glyph-sky)">
            <g className="tg-sun">
                <circle cx="12" cy="12.6" r="3.5" />
                <path d="M12 5.4v1.5M6.9 7.5l1.05 1.05M17.1 7.5l-1.05 1.05M4.8 12.6h1.5M17.7 12.6h1.5" />
            </g>
            <g className="tg-moon">
                <path d="M15.9 14.9a5.3 5.3 0 0 1-6.6-8.2 5.6 5.6 0 1 0 6.6 8.2z" />
            </g>
        </g>
        <path d="M3.5 19.6h17" />
    </svg>
);
