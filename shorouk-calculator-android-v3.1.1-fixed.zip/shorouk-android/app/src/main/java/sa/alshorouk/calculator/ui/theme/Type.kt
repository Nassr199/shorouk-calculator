package sa.alshorouk.calculator.ui.theme

import android.content.Context
import androidx.compose.runtime.Immutable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.File
import java.util.zip.GZIPInputStream

/*
 * خط ثمانية (Thmanyah Serif Display) for Arabic letters, as in v3.1.
 *
 * The licence allows the typeface only inside a packaged product and forbids offering the font files
 * themselves, so the APK carries the same gzip pack as the web app (assets/type/thmanyah.pack, bytes
 * unchanged). It is unpacked once into the app's private no-backup storage, never into shared storage.
 *
 * Amounts are always drawn in the system sans with tabular figures ("tnum"), because they roll like an
 * odometer and line up in the ledger, and Thmanyah's figures are proportional.
 */
object ArabicType {
    private const val PACK = "type/thmanyah.pack"

    @OptIn(ExperimentalTextApi::class)
    suspend fun load(context: Context): FontFamily? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.noBackupFilesDir, "type").apply { mkdirs() }
            val regular = File(dir, "t400.bin")
            val bold = File(dir, "t700.bin")
            if (!regular.isFile || !bold.isFile || regular.length() == 0L || bold.length() == 0L) unpack(context, dir)
            FontFamily(Font(regular, FontWeight.Normal), Font(bold, FontWeight.Bold))
        }.getOrNull()
    }

    // "SHF1" · count · (weight uint16 LE, length uint32 LE) per font · the font files one after another
    private fun unpack(context: Context, dir: File) {
        DataInputStream(GZIPInputStream(context.assets.open(PACK)).buffered()).use { input ->
            val magic = ByteArray(4).also { input.readFully(it) }
            require(String(magic, Charsets.ISO_8859_1) == "SHF1") { "bad font pack" }
            val count = input.readUnsignedByte()
            val entries = List(count) {
                val w = input.readUnsignedByte() or (input.readUnsignedByte() shl 8)
                val len = (input.readUnsignedByte()) or (input.readUnsignedByte() shl 8) or
                    (input.readUnsignedByte() shl 16) or (input.readUnsignedByte() shl 24)
                w to len
            }
            for ((weight, length) in entries) {
                val bytes = ByteArray(length).also { input.readFully(it) }
                val tmp = File(dir, "t$weight.tmp")
                tmp.writeBytes(bytes)
                tmp.renameTo(File(dir, "t$weight.bin"))
            }
        }
    }
}

/** Every text style of the interface, in sp. Arabic letters draw ~10% larger (the web app's size-adjust). */
@Immutable
class AppType(val text: FontFamily, val figures: FontFamily, arabic: Boolean) {
    private val k = if (arabic) 1.1f else 1f
    private fun s(size: Float, weight: FontWeight = FontWeight.Normal, line: Float = 1.45f): TextStyle =
        TextStyle(
            fontFamily = text, fontSize = (size * k).sp, fontWeight = weight, lineHeight = (size * k * line).sp,
        )

    fun money(size: TextUnit, weight: FontWeight = FontWeight.SemiBold): TextStyle =
        TextStyle(fontFamily = figures, fontSize = size, fontWeight = weight, fontFeatureSettings = "tnum, lnum", letterSpacing = (-0.01f).sp)

    val brand = s(15f, FontWeight.SemiBold, 1.3f)
    val label = s(14f, FontWeight.Medium)
    val labelSmall = s(13f, FontWeight.Medium)
    val hint = s(12f, line = 1.55f)
    val body = s(15f)
    val bodyStrong = s(15f, FontWeight.SemiBold, 1.4f)
    val caption = s(12f, FontWeight.Medium)
    val tiny = s(11f)
    val title = s(18f, FontWeight.SemiBold, 1.4f)
    val button = s(15f, FontWeight.SemiBold)
    val dockItem = s(11.5f, FontWeight.Medium, 1.2f)
    val latinButton = TextStyle(fontFamily = figures, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.26.sp)
}
