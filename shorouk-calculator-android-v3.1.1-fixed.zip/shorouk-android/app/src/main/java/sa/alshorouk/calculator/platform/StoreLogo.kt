package sa.alshorouk.calculator.platform

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/*
 * The store's logo, from the same address the web app uses (components/Extras.tsx).
 * Downloaded once, kept in the app's private files, so it is there offline and in printed receipts.
 * Until then — or if it can never be fetched — the drawn sun mark stands in.
 */
object StoreLogo {
    const val URL_LOGO = "https://www2.0zz0.com/2025/04/29/23/183916568.png"

    @Volatile var cached: ImageBitmap? = null
        private set
    @Volatile var bitmap: Bitmap? = null
        private set

    private fun file(context: Context) = File(context.filesDir, "store-logo.png")

    suspend fun get(context: Context): ImageBitmap? = withContext(Dispatchers.IO) {
        cached?.let { return@withContext it }
        val f = file(context)
        decode(f)?.let { return@withContext it }
        runCatching {
            val conn = (URL(URL_LOGO).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000; readTimeout = 8000; instanceFollowRedirects = true
            }
            try {
                if (conn.responseCode in 200..299) {
                    val tmp = File(f.parentFile, "store-logo.tmp")
                    conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                    if (BitmapFactory.decodeFile(tmp.path) != null) tmp.renameTo(f) else tmp.delete()
                }
            } finally { conn.disconnect() }
        }
        decode(f)
    }

    private fun decode(f: File): ImageBitmap? {
        if (!f.isFile) return null
        val bmp = BitmapFactory.decodeFile(f.path) ?: return null
        bitmap = bmp
        return bmp.asImageBitmap().also { cached = it }
    }
}
