package sa.alshorouk.calculator.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import sa.alshorouk.calculator.R
import sa.alshorouk.calculator.core.Language
import sa.alshorouk.calculator.core.Provider
import sa.alshorouk.calculator.platform.StoreLogo
import kotlin.math.cos
import kotlin.math.sin

/**
 * The store's mark in the bar: its round emblem filling a white disc (the writing under the emblem cannot be
 * read at this size, so it is left to the receipt and the launcher); the whole logo if it has no emblem to
 * find; the drawn sun until, or unless, the logo loads.
 */
@Composable
fun StoreLogoTile(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val logo by produceState<ImageBitmap?>(StoreLogo.cached, context) { value = StoreLogo.get(context) }
    Box(
        modifier.size(34.dp).clip(CircleShape).background(Color.White).border(0.5.dp, Color(0x24103C40), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        val whole = logo
        val emblem = if (whole != null) StoreLogo.emblem else null
        when {
            emblem != null -> Image(emblem, null, Modifier.size(31.dp).clip(CircleShape), contentScale = ContentScale.Fit)
            whole != null -> Image(whole, null, Modifier.size(26.dp), contentScale = ContentScale.Fit)
            else -> SunMark(Modifier.size(34.dp))
        }
    }
}

/** Small version of the store's mark (Scene.tsx SunMark). */
@Composable
fun SunMark(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val k = size.minDimension / 48f
        drawRect(Color(0xFF134448))
        for (i in 0 until 7) {
            val a = Math.toRadians((15 + i * 25).toDouble())
            val x1 = 24 + cos(a) * 12; val y1 = 31 - sin(a) * 12
            val x2 = 24 + cos(a) * 19; val y2 = 31 - sin(a) * 19
            drawLine(Color(0xFFE9A41C), Offset(x1.toFloat() * k, y1.toFloat() * k), Offset(x2.toFloat() * k, y2.toFloat() * k), 3f * k, StrokeCap.Round)
        }
        drawCircle(Color(0xFFE9A41C), 8.5f * k, Offset(24f * k, 31f * k))
        drawRect(Color(0xFF0D3337), Offset(0f, 31f * k), Size(48f * k, 17f * k))
    }
}

/** The providers' wordmarks, one per language, sized so the four weigh the same side by side (Extras.tsx). */
@Composable
fun ProviderMark(provider: Provider, lang: Language, tint: Color, modifier: Modifier = Modifier) {
    val (res, w, h) = when (provider) {
        Provider.Tabby -> if (lang == Language.Ar) Triple(R.drawable.tabby_ar, 51, 34) else Triple(R.drawable.tabby_en, 79, 22)
        Provider.Tamara -> if (lang == Language.Ar) Triple(R.drawable.tamara_ar, 77, 23) else Triple(R.drawable.tamara_en, 78, 15)
    }
    Image(
        painterResource(res), null,
        modifier.size(w.dp, h.dp),
        contentScale = ContentScale.Fit,
        colorFilter = ColorFilter.tint(tint, BlendMode.SrcIn),
    )
}
