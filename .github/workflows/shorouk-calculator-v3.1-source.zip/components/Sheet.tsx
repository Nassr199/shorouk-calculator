import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import type { CalculationResult, I18nData } from '../types';
import { Spring, VelocityTracker, clamp, rubberBand } from '../lib/motion';
import { getQuality, refractionSupported, setQuality, subscribeQuality } from '../lib/glass';
import { Glass } from './Glass';
import { LensSegmented } from './LensSegmented';
import { LiquidSwitch, LiquidSwitchHandle } from './LiquidSwitch';
import { Ledger } from './Ledger';
import { FeeGuide } from './Extras';
import { IconClose } from './Icons';

/*
 * The sheet that rises over the calculator with the calculation details and the fee guide.
 *
 * It rides one spring from start to finish: opening, following the finger when pulled down by its
 * handle, and either settling back or leaving with the speed of the throw. The page behind recedes
 * with the same value, so the two always move as one.
 */

type Tab = 'details' | 'guide';

interface SheetProps {
    t: I18nData;
    result: CalculationResult;
    open: boolean;
    onClose: () => void;
    /** 0 = closed, 1 = fully open; called on every frame of the movement. */
    onProgress?: (progress: number) => void;
}

const OPEN = { stiffness: 270, damping: 29, precision: 0.3 };
const CLOSE = { stiffness: 330, damping: 37, precision: 0.5 };
const DRAG_SLOP = 4;
const THROW_SPEED = 650;          // px/s downward that dismisses regardless of distance

/** Turns edge refraction on or off (it is the costly part of the glass on slow phones). */
function GlassSetting({ t }: { t: I18nData }) {
    const [on, setOn] = useState(() => getQuality() === 'full');
    const handle = useRef<LiquidSwitchHandle>(null);
    useEffect(() => subscribeQuality(() => setOn(getQuality() === 'full')), []);
    const change = (next: boolean) => setQuality(next ? 'full' : 'frost', 'user');

    return (
        <button
            type="button"
            role="switch"
            aria-checked={on}
            className="setting"
            onClick={() => {
                if (handle.current?.consumeDrag()) return;
                change(!on);
            }}
        >
            <span className="setting__text">
                <span className="setting__title">{t.ui.glassTitle}</span>
                <span className="setting__hint">{t.ui.glassHint}</span>
            </span>
            <LiquidSwitch ref={handle} checked={on} onDragToggle={change} />
        </button>
    );
}

export function Sheet({ t, result, open, onClose, onProgress }: SheetProps) {
    const { ui } = t;
    const panel = useRef<HTMLElement>(null);
    const scrim = useRef<HTMLDivElement>(null);
    const [tab, setTab] = useState<Tab>('details');
    const [shown, setShown] = useState(false);       // stays true until the closing movement has come to rest
    const [runs, setRuns] = useState(0);             // replays the staggered entrance each time it opens
    const [canRefract] = useState(() => refractionSupported() && getQuality() !== 'solid');
    const live = useRef({
        y: null as Spring | null, closedY: 900, pointer: -1, startClientY: 0, startValue: 0,
        dragging: false, tracker: new VelocityTracker(), returnTo: null as HTMLElement | null,
    });
    const progress = useRef(onProgress);
    progress.current = onProgress;
    const close = useRef(onClose);
    close.current = onClose;

    const paint = (y: number) => {
        const el = panel.current;
        if (!el) return;
        const p = clamp(1 - y / live.current.closedY, 0, 1);
        el.style.transform = `translate3d(0, ${y.toFixed(1)}px, 0)`;
        if (scrim.current) scrim.current.style.opacity = p.toFixed(3);
        progress.current?.(p);
    };

    useLayoutEffect(() => {
        const s = live.current;
        s.y = new Spring(s.closedY, OPEN, paint);
        paint(s.closedY);
        return () => { s.y?.dispose(); s.y = null; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useLayoutEffect(() => {
        const s = live.current;
        const el = panel.current;
        if (!s.y || !el) return;
        if (open) {
            s.returnTo = document.activeElement instanceof HTMLElement ? document.activeElement : null;
            const wasResting = !s.y.moving;
            s.closedY = el.offsetHeight + 48;
            if (wasResting) s.y.snap(s.closedY);                  // start from just below the screen
            setShown(true);
            setRuns((n) => n + 1);
            s.y.to(0, { config: OPEN });
        } else {
            s.y.to(s.closedY, { config: CLOSE, onRest: () => setShown(false) });
            const back = s.returnTo;
            s.returnTo = null;
            if (back?.isConnected) back.focus({ preventScroll: true });
        }
    }, [open]);

    // keyboard focus moves into the sheet; everything behind it is inert while it is open
    useEffect(() => {
        if (open && shown) panel.current?.focus({ preventScroll: true });
    }, [open, shown]);

    useEffect(() => {
        if (!open) return;
        const onKey = (e: KeyboardEvent) => {
            if (e.key !== 'Escape') return;
            e.preventDefault();
            close.current();
        };
        document.addEventListener('keydown', onKey);
        return () => document.removeEventListener('keydown', onKey);
    }, [open]);

    /* ---- pull down to dismiss (handle and header) ---- */

    const onPointerDown = (e: React.PointerEvent<HTMLElement>) => {
        const s = live.current;
        if (e.button !== 0 || !s.y || (e.target as Element).closest('button, .seg')) return;
        s.pointer = e.pointerId;
        s.startClientY = e.clientY;
        s.startValue = s.y.value;
        s.dragging = false;
        s.tracker.reset();
        s.tracker.add(e.clientY);
        e.currentTarget.setPointerCapture(e.pointerId);
    };

    const onPointerMove = (e: React.PointerEvent<HTMLElement>) => {
        const s = live.current;
        if (e.pointerId !== s.pointer || !s.y) return;
        s.tracker.add(e.clientY);
        const dy = e.clientY - s.startClientY;
        if (!s.dragging) {
            if (Math.abs(dy) < DRAG_SLOP) return;
            s.dragging = true;
        }
        let y = s.startValue + dy;
        if (y < 0) y = rubberBand(y, 220, 0.35);                  // pulled upward: it gives a little, then resists
        s.y.drag(y, s.tracker.get());
    };

    const onPointerEnd = (e: React.PointerEvent<HTMLElement>) => {
        const s = live.current;
        if (e.pointerId !== s.pointer || !s.y) return;
        s.pointer = -1;
        if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
        if (!s.dragging) return;
        s.dragging = false;
        const velocity = s.tracker.get();
        const dismiss = e.type !== 'pointercancel' && (velocity > THROW_SPEED || (s.y.value > s.closedY * 0.3 && velocity > -200));
        if (dismiss) close.current();                             // the closing spring inherits the throw
        else s.y.to(0, { velocity, config: OPEN });
    };

    const drag = { onPointerDown, onPointerMove, onPointerUp: onPointerEnd, onPointerCancel: onPointerEnd };
    const ready = result.P_input > 0;

    return (
        <div className="sheet-layer" data-open={open} style={{ visibility: open || shown ? 'visible' : 'hidden' }}>
            <div className="scrim" ref={scrim} onClick={onClose} />
            <Glass
                as="section"
                ref={panel}
                className="sheet"
                role="dialog"
                aria-modal="true"
                aria-label={ui.sheetTitle}
                tabIndex={-1}
                inert={!open}
                refract={false}
            >
                <div className="sheet__grab" {...drag} />
                <header className="sheet__head" {...drag}>
                    <LensSegmented<Tab>
                        className="sheet__tabs"
                        ariaLabel={ui.sheetTitle}
                        refract={false}
                        options={[
                            { value: 'details', label: ui.detailsShort },
                            { value: 'guide', label: ui.guideShort },
                        ]}
                        value={tab}
                        onChange={setTab}
                    />
                    <Glass
                        as="button"
                        type="button"
                        variant="clear"
                        className="sheet__close"
                        data-press=""
                        onClick={onClose}
                        aria-label={ui.close}
                        refract={false}
                    >
                        <IconClose size={18} />
                    </Glass>
                </header>

                <div className="sheet__body">
                    <div className="sheet__panel" key={`${tab}:${runs}`}>
                        {tab === 'details' && (
                            <>
                                <h2 className="sheet__title">{ui.detailsTitle}</h2>
                                {ready ? <Ledger t={t} result={result} /> : <p className="sheet__empty">{ui.detailsEmpty}</p>}
                            </>
                        )}
                        {tab === 'guide' && (
                            <>
                                <h2 className="sheet__title">{ui.guideTitle}</h2>
                                <FeeGuide t={t} />
                            </>
                        )}
                    </div>
                </div>

                {canRefract && <GlassSetting t={t} />}
            </Glass>
        </div>
    );
}
