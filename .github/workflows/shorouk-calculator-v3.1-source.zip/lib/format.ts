/** Money as the store reads it: Western digits, thousands separators, always two decimals. */
export const formatMoney = (n: number): string =>
    n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** "2,727.91" → { int: "2,727", dec: "91" } */
export const splitMoney = (n: number): { int: string; dec: string } => {
    const [int, dec = '00'] = formatMoney(n).split('.');
    return { int, dec };
};

export const formatPercent = (n: number): string =>
    n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** Replaces {KEY} placeholders in a UI string. */
export const fill = (template: string, values: Record<string, string>): string =>
    template.replace(/\{(\w+)\}/g, (match, key: string) => (key in values ? values[key] : match));
