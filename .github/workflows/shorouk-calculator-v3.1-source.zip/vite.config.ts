import path from 'path';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  // Relative asset URLs, so the build works from any path (GitHub Pages project site, a sub-folder, a custom domain).
  base: './',
  server: {
    port: 3000,
    host: '0.0.0.0',
  },
  preview: {
    host: '0.0.0.0',
  },
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, '.'),
    },
  },
});
