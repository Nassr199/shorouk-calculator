import type { I18nData, Theme } from '../types';
import { Glass } from './Glass';
import { StoreLogo } from './Extras';
import { IconCheck, IconCopy, IconPrinter, IconReceipt, IconSend, ThemeGlyph } from './Icons';

/* The floating layer: brand and view controls at the top, actions in the dock at the bottom. */

interface TopBarProps {
    t: I18nData;
    theme: Theme;
    onToggleTheme: (origin?: { x: number; y: number }) => void;
    onToggleLang: () => void;
}

export function TopBar({ t, theme, onToggleTheme, onToggleLang }: TopBarProps) {
    return (
        <header className="top">
            <Glass className="top__brand" variant="clear" bezel={14} depth={16} blur={3}>
                <StoreLogo alt={t.ui.logoAlt} />
                <h1 className="top__name">{t.ui.appName}</h1>
            </Glass>
            <Glass className="top__tools" variant="clear" bezel={14} depth={16} blur={3}>
                <button
                    type="button"
                    className="top__btn top__btn--text tap"
                    data-press=""
                    onClick={onToggleLang}
                    aria-label={t.ui.langButtonLabel}
                    lang={t.ui.langButton === 'EN' ? 'en' : 'ar'}
                >
                    <span aria-hidden="true">{t.ui.langButton}</span>
                </button>
                <button
                    type="button"
                    className="top__btn tap"
                    data-press=""
                    aria-label={theme === 'dark' ? t.ui.toLight : t.ui.toDark}
                    onClick={(e) => {
                        const r = e.currentTarget.getBoundingClientRect();
                        onToggleTheme({ x: r.left + r.width / 2, y: r.top + r.height / 2 });
                    }}
                >
                    <ThemeGlyph />
                </button>
            </Glass>
        </header>
    );
}

interface DockProps {
    t: I18nData;
    ready: boolean;
    copied: boolean;
    hidden: boolean;
    onCopy: () => void;
    onShare: () => void;
    onPrint: () => void;
    onDetails: () => void;
}

export function Dock({ t, ready, copied, hidden, onCopy, onShare, onPrint, onDetails }: DockProps) {
    const { ui } = t;
    return (
        <nav className="dock" aria-label={ui.actions} inert={hidden}>
            <Glass
                as="button"
                type="button"
                variant="tint"
                className="dock__copy"
                data-press=""
                data-done={copied}
                disabled={!ready}
                onClick={onCopy}
                bezel={18}
                depth={20}
                blur={8}
            >
                <span className="dock__sweep" aria-hidden="true" />
                <span className="dock__copy-icon" aria-hidden="true">
                    <IconCopy className="dock__icon-copy" size={20} />
                    <IconCheck className="dock__icon-check" size={20} strokeWidth={2.4} />
                </span>
                <span className="dock__copy-label">{copied ? ui.copied : ui.copyAmount}</span>
            </Glass>

            <Glass className="dock__group" bezel={18} depth={20} blur={10}>
                <button type="button" className="dock__item tap" data-press="" onClick={onShare} disabled={!ready}>
                    <IconSend size={21} className="flip-rtl" />
                    <span>{ui.share}</span>
                </button>
                <button type="button" className="dock__item tap" data-press="" onClick={onPrint} disabled={!ready}>
                    <IconPrinter size={21} />
                    <span>{ui.print}</span>
                </button>
                <button type="button" className="dock__item tap" data-press="" onClick={onDetails} aria-haspopup="dialog">
                    <IconReceipt size={21} />
                    <span>{ui.detailsShort}</span>
                </button>
            </Glass>
        </nav>
    );
}
