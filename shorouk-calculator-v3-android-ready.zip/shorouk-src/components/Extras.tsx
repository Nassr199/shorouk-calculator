import { useEffect, useState } from 'react';
import { flushSync } from 'react-dom';
import type { CalculationResult, I18nData, Language } from '../types';
import { formatMoney } from '../lib/format';
import { IconCheck } from './Icons';
import { SunMark } from './Scene';

export const LOGO_URL = 'https://www2.0zz0.com/2025/04/29/23/183916568.png';

/** The store's logo on a white tile (it stays legible in the dark theme); the sun mark if it fails to load. */
export function StoreLogo({ alt }: { alt: string }) {
    const [failed, setFailed] = useState(false);
    return (
        <span className="logo-tile">
            {failed
                ? <SunMark />
                : <img src={LOGO_URL} alt={alt} width={30} height={30} decoding="async" draggable={false} onError={() => setFailed(true)} />}
        </span>
    );
}

// The providers' own badge images, as the first version of the calculator loaded them.
export const PROVIDER_LOGOS = {
    tabby: 'https://cdn.salla.sa/BmwbV/Ea1Kx4SfpK2Vy3Lx3aVPvZKBMkSM5dio2eKveTwm.png',
    tamara: 'https://cdn.tamara.co/assets/png/tamara-logo-badge-en.png',
} as const;

/** A provider's badge; its name in text if the image cannot load (first visit offline). */
export function ProviderMark({ provider, name }: { provider: keyof typeof PROVIDER_LOGOS; name: string }) {
    const [failed, setFailed] = useState(false);
    if (failed) return <span className="mark mark--text">{name}</span>;
    return (
        <img
            className="mark"
            src={PROVIDER_LOGOS[provider]}
            alt=""
            height={26}
            decoding="async"
            draggable={false}
            onError={() => setFailed(true)}
        />
    );
}

export function FeeGuide({ t }: { t: I18nData }) {
    return (
        <div className="guide">
            {t.noteItems.map((note, i) => (
                <div className="guide__item" key={i}>
                    <h3 className="guide__q">{note.question.replace(/[:：]\s*$/, '')}</h3>
                    <div className="guide__a" dangerouslySetInnerHTML={{ __html: note.answer }} />
                </div>
            ))}
        </div>
    );
}

/** Visual only; App announces the same message through its own live region. */
export function Toast({ text, show, ok }: { text: string; show: boolean; ok: boolean }) {
    return (
        <div className="toast" aria-hidden="true" data-show={show}>
            {text && ok && <IconCheck size={18} strokeWidth={2.25} />}
            <span>{text}</span>
        </div>
    );
}

/** Printed instead of the screen (see @media print in styles.css). */
export function PrintReceipt({ t, result, lang }: { t: I18nData; result: CalculationResult; lang: Language }) {
    const [printedAt, setPrintedAt] = useState(() => new Date());
    useEffect(() => {
        // the browser lays out the printout right after this event, so the new time must be in the DOM now
        const stamp = () => flushSync(() => setPrintedAt(new Date()));
        window.addEventListener('beforeprint', stamp);
        return () => window.removeEventListener('beforeprint', stamp);
    }, []);

    const f = formatMoney;
    const cur = t.currencySuffix.trim();
    const L = t.labels;
    const locale = lang === 'ar' ? 'ar-SA-u-ca-gregory-nu-latn' : 'en-GB';
    const settleLabel = result.settlementType === 'bank_transfer' ? t.settlementFeeLabel_transfer : t.settlementFeeLabel_provider;
    const rows: [string, number][] = [
        [L[5], result.P_input],
        [L[0], result.baseFee],
        [L[1], result.vat],
        [L[2], result.totalServiceFee],
        [settleLabel, result.S_final],
    ];

    return (
        <section className="receipt" aria-hidden="true">
            <header className="receipt__head">
                <img src={LOGO_URL} alt="" />
                <div>
                    <div className="receipt__store">{t.ui.storeName}</div>
                    <div className="receipt__title">{t.ui.receiptTitle}</div>
                </div>
            </header>
            <p className="receipt__date">
                {t.ui.receiptDate}: {printedAt.toLocaleString(locale, { dateStyle: 'long', timeStyle: 'short' })}
            </p>
            <table className="receipt__rows">
                <tbody>
                    {rows.map(([label, value]) => (
                        <tr key={label}>
                            <td>{label}</td>
                            <td><span className="money">{f(value)}</span> {cur}</td>
                        </tr>
                    ))}
                    <tr className="is-total">
                        <td>{L[4]}</td>
                        <td><span className="money">{f(result.X)}</span> {cur}</td>
                    </tr>
                </tbody>
            </table>
            <p className="receipt__foot">{t.footerText.replace('{YEAR}', String(printedAt.getFullYear()))}</p>
        </section>
    );
}
