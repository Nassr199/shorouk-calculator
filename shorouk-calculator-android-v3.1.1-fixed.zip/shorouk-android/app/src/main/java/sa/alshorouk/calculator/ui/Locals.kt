package sa.alshorouk.calculator.ui

import androidx.compose.runtime.staticCompositionLocalOf
import sa.alshorouk.calculator.core.Strings
import sa.alshorouk.calculator.platform.Haptics
import sa.alshorouk.calculator.ui.theme.AppType
import sa.alshorouk.calculator.ui.theme.LightPalette
import sa.alshorouk.calculator.ui.theme.Palette

val LocalPalette = staticCompositionLocalOf<Palette> { LightPalette }
val LocalStrings = staticCompositionLocalOf<Strings> { Strings.AR }
val LocalType = staticCompositionLocalOf<AppType> { error("AppType not provided") }
/** false when the person removed animations in Android's accessibility settings: results appear at once. */
val LocalMotion = staticCompositionLocalOf { true }
val LocalHaptics = staticCompositionLocalOf<Haptics> { error("Haptics not provided") }
