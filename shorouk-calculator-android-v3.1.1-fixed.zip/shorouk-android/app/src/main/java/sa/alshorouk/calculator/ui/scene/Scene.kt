package sa.alshorouk.calculator.ui.scene

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import sa.alshorouk.calculator.ui.glass.Backdrop
import sa.alshorouk.calculator.ui.theme.Palette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

/*
 * The world behind the glass: the store's name, الشروق (sunrise), over a calm sea (components/Scene.tsx).
 *
 * With no amount the scene waits before dawn; enter an amount and the sun rises over the result pane, its
 * rays cross the sky, the thin clouds catch its colour and a road of light runs down the water toward you.
 *
 * Every part that changes with the sun is a GPU layer of its own and only its alpha / transform changes:
 * nothing is re-recorded while the sun rises. The geometry is the web scene's, in dp, around the centre of
 * the screen (the web drew a 1040 px wide scene centred on the page). The horizon follows the result pane.
 */

private const val W = 1040f
private const val CX = W / 2f
private const val SKY_H = 440f

private class Oval(val x: Float, val y: Float, val rx: Float, val ry: Float, val o: Float)

/** Deterministic random generator (mulberry32), so the scene is the same on every launch, as on the web. */
private fun seeded(seed: Int): () -> Float {
    var a = seed
    return {
        a += 0x6D2B79F5
        var t = a
        t = (t xor (t ushr 15)) * (t or 1)
        t = t xor (t + (t xor (t ushr 7)) * (t or 61))
        ((t xor (t ushr 14)).toUInt().toDouble() / 4294967296.0).toFloat()
    }
}

private fun cloud(x: Float, y: Float, w: Float, h: Float) = listOf(
    Oval(x + w / 2, y, w / 2, h / 2, 1f),
    Oval(x + w * 0.42f, y - h * 0.7f, w * 0.27f, h * 0.5f, 0.9f),
    Oval(x + w * 0.2f, y + h * 0.75f, w * 0.33f, h * 0.42f, 0.8f),
)

private val CLOUDS: List<Oval> = listOf(
    cloud(584f, 352f, 150f, 9f), cloud(302f, 316f, 124f, 8f), cloud(620f, 232f, 112f, 7f),
    cloud(310f, 196f, 96f, 7f), cloud(604f, 96f, 104f, 6f), cloud(326f, 62f, 86f, 6f),
    cloud(70f, 286f, 200f, 10f), cloud(800f, 300f, 190f, 10f), cloud(150f, 140f, 150f, 8f),
    cloud(850f, 150f, 150f, 8f), cloud(10f, 60f, 130f, 7f),
).flatten()

private fun rowY(i: Int) = 36f + i * 4.2f + i * i * 0.5f

private val RIPPLES: List<Oval> = run {
    val random = seeded(7)
    buildList {
        for (i in 0 until 25) {
            val y = rowY(i)
            val fade = max(0f, 1f - i / 27f)
            val count = 9 - floor(i / 6f).toInt()
            repeat(count) {
                val rx = (13 + random() * 34) * (1 + i * 0.06f)
                add(Oval(random() * (W + 80) - 40, y + (random() - 0.5f) * 3, rx, 0.75f + i * 0.07f, (0.25f + random() * 0.5f) * fade))
            }
        }
    }
}

private val GLITTER: List<Oval> = run {
    val random = seeded(23)
    buildList {
        for (i in 0 until 19) {
            val y = rowY(i) - 6
            val fade = max(0f, 1f - i / 20f).pow(1.2f)
            val rx = max(9f, (58 - i * 1.8f) * (0.5f + random() * 0.6f))
            val drift = (random() - 0.5f) * (10 + i * 5)
            add(Oval(CX + drift, y, rx, 1.15f + i * 0.1f, fade))
            val sides = if (i < 2) 0 else 1 + floor(random() * 2).toInt()
            repeat(sides) {
                val side = if (random() < 0.5f) -1 else 1
                add(Oval(CX + side * (44 + i * 4.2f + random() * 44), y + (random() - 0.5f) * 4, 5 + random() * 12, 0.9f + i * 0.08f, fade * (0.35f + random() * 0.35f)))
            }
        }
    }
}

/** 15 rays, long and short alternating like the mark in the store's logo; sun point at (0, 0). */
private fun rays(): List<List<Offset>> = List(15) { i ->
    val long = i % 2 == 0
    val deg = 6f + i * 12f
    val reach = if (long) 480f else 340f
    val spread = if (long) 21f else 12f
    val a = deg * PI.toFloat() / 180f
    val dx = cos(a); val dy = -sin(a)
    val nx = -dy; val ny = dx
    fun at(r: Float, w: Float, side: Float) = Offset(dx * r + nx * w * side, dy * r + ny * w * side)
    listOf(at(82f, 1.4f, 1f), at(reach, spread, 1f), at(reach, spread, -1f), at(82f, 1.4f, -1f))
}
private val RAYS = rays()

private val STARS = listOf(
    Triple(0.09f, 0.14f, 1.2f), Triple(0.21f, 0.41f, 1f), Triple(0.33f, 0.09f, 1.4f), Triple(0.44f, 0.30f, 0.9f),
    Triple(0.58f, 0.17f, 1.2f), Triple(0.67f, 0.44f, 1f), Triple(0.78f, 0.11f, 1.5f), Triple(0.88f, 0.33f, 1f),
    Triple(0.94f, 0.06f, 1.1f), Triple(0.14f, 0.62f, 0.9f), Triple(0.51f, 0.58f, 1f), Triple(0.83f, 0.66f, 0.9f),
    Triple(0.03f, 0.36f, 1.2f), Triple(0.72f, 0.26f, 1f),
)

/**
 * @param sun 0 = under the horizon, 1 = risen (a spring in the caller)
 * @param horizon y of the horizon in this scene, px
 * @param sunSize 1, or 0.74 on short screens (styles.css)
 */
@Composable
fun Scene(
    palette: Palette,
    sun: () -> Float,
    horizon: () -> Float,
    sunSize: Float,
    backdrop: Backdrop,
    modifier: Modifier = Modifier,
    /** How far the sun stands from the middle of the screen, px (the result pane is off-centre on a tablet). */
    sunX: () -> Float = { 0f },
) {
    val recording = rememberGraphicsLayer()
    SideEffect {
        backdrop.layer = recording
        backdrop.observe = { sun(); horizon(); sunX() }
    }
    val p = palette
    // the scene is a picture, not a layout: it never mirrors with Arabic
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier
                .fillMaxSize()
                .onGloballyPositioned { backdrop.coordinates = it; backdrop.onPlaced() }
                .drawWithContent {
                    recording.record { this@drawWithContent.drawContent() }
                    drawLayer(recording)
                },
        ) {
            // sky and sea
            Spacer(Modifier.fillMaxSize().drawBehind {
                val h = horizon()
                drawRect(Brush.verticalGradient(0f to p.sky0, 0.54f to p.sky1, 1f to p.sky2, startY = 0f, endY = h), size = Size(size.width, h))
                val d = density
                drawRect(
                    Brush.verticalGradient(0f to p.sea0, (170f / 520f) to p.sea1, 1f to p.sea2, startY = h, endY = h + 520f * d),
                    topLeft = Offset(0f, h), size = Size(size.width, (size.height - h).coerceAtLeast(0f)),
                )
            })
            if (p.stars) {
                Spacer(Modifier.fillMaxSize().layer { alpha = 0.9f - sun() * 0.6f }.drawBehind {
                    val h = horizon() * 0.84f
                    for ((fx, fy, r) in STARS) drawCircle(Color(0xFFEAF6F5), r * density * 0.9f, Offset(fx * size.width, fy * h))
                })
            }
            // first light
            Spacer(Modifier.fillMaxSize().layer { alpha = sun() }.drawBehind {
                val h = horizon()
                drawRect(Brush.verticalGradient(*p.dawnStops.toTypedArray(), startY = 0f, endY = h), size = Size(size.width, h))
            })
            // clouds: a cool set before dawn cross-fades to a set lit from below
            Spacer(Modifier.fillMaxSize().layer { alpha = 1f - sun(); translationY = horizon() - SKY_H * density }
                .drawBehind { drawOvals(CLOUDS, p.cloud.copy(alpha = p.cloudOpacity), soft = true) })
            Spacer(Modifier.fillMaxSize().layer { alpha = sun(); translationY = horizon() - SKY_H * density }
                .drawBehind { drawOvals(CLOUDS, p.cloudLit.copy(alpha = p.cloudOpacity), soft = true) })

            // the sun: a point on the horizon; the sky's lower edge hides what is below it
            Box(Modifier.fillMaxSize().drawWithContent {
                clipRect(bottom = horizon()) { this@drawWithContent.drawContent() }
            }) {
                Spacer(Modifier.fillMaxSize().layer { sunLayer(sun, horizon, sunX, sunSize, 1f); alpha = 0.36f + sun() * 0.64f }.drawBehind {
                    val r = 330f * density
                    val c = Offset(size.width / 2, 0f)
                    drawCircle(Brush.radialGradient(0f to p.glow0.copy(alpha = 0.9f), 0.42f to p.glow1.copy(alpha = 0.32f), 1f to Color.Transparent, center = c, radius = r), r, c)
                })
                Spacer(Modifier.fillMaxSize().layer {
                    val s = sun()
                    sunLayer(sun, horizon, sunX, sunSize, 0.62f + s * 0.38f)
                    rotationZ = (1f - s) * -14f
                    alpha = s
                }.drawBehind { drawRays(p) })
                Spacer(Modifier.fillMaxSize().layer { sunLayer(sun, horizon, sunX, sunSize, 1f) }.drawBehind {
                    val r = 58f * density
                    val c = Offset(size.width / 2, 0f)
                    drawCircle(Brush.verticalGradient(0f to p.disc0, 0.5f to p.disc1, 1f to p.disc2, startY = -r, endY = r), r, c)
                })
            }

            // the water
            Spacer(Modifier.fillMaxSize().layer { alpha = 0.1f + sun() * 0.9f; translationY = horizon(); translationX = sunX() }.drawBehind {
                val rx = size.width * 0.62f
                val ry = 210f * density
                val c = Offset(size.width / 2, 0f)
                withTransform({ scale(1f, ry / rx, c) }) {
                    drawCircle(Brush.radialGradient(0f to p.shine, 0.72f to Color.Transparent, center = c, radius = rx), rx, c)
                }
            })
            Spacer(Modifier.fillMaxSize().layer { alpha = 0.4f + sun() * 0.6f; translationY = horizon() }.drawBehind {
                drawRect(
                    Brush.horizontalGradient(0f to Color.Transparent, 0.22f to p.horizon, 0.78f to p.horizon, 1f to Color.Transparent),
                    size = Size(size.width, 1.5f * density),
                )
            })
            Spacer(Modifier.fillMaxSize().layer {
                val s = sun()
                alpha = s
                translationY = horizon()
                translationX = sunX()
                transformOrigin = TransformOrigin(0.5f, 0f)
                scaleX = sunSize; scaleY = sunSize * (0.3f + s * 0.7f)
            }.drawBehind {
                val w = 56f * density
                val h = 40f * density
                val cx = size.width / 2
                drawArc(
                    Brush.verticalGradient(listOf(p.mirror, p.mirrorEnd), 0f, h),
                    startAngle = 0f, sweepAngle = 180f, useCenter = true,
                    topLeft = Offset(cx - w, -h), size = Size(w * 2, h * 2),
                )
            })
            Spacer(Modifier.fillMaxSize().layer { translationY = horizon() }.drawBehind {
                drawOvals(RIPPLES, p.ripple.copy(alpha = p.rippleOpacity), soft = false, edgeFade = true)
            })
            Spacer(Modifier.fillMaxSize().layer {
                val s = sun()
                alpha = s
                translationY = horizon()
                translationX = sunX()
                transformOrigin = TransformOrigin(0.5f, 0f)
                scaleX = 0.5f + s * 0.5f; scaleY = 0.25f + s * 0.75f
            }.drawBehind { drawOvals(GLITTER, p.glitter, soft = false) })
        }
    }
}

/** A layer whose only per-frame work is alpha / transform, composited without an offscreen buffer. */
private fun Modifier.layer(block: GraphicsLayerScope.() -> Unit) = graphicsLayer {
    compositingStrategy = CompositingStrategy.ModulateAlpha
    block()
}

/** Places a layer drawn around (centre, 0) on the sun: (1 − s)·96 − 2 dp under the horizon, scaled around it. */
private fun GraphicsLayerScope.sunLayer(sun: () -> Float, horizon: () -> Float, sunX: () -> Float, sunSize: Float, scale: Float) {
    val s = sun()
    translationX = sunX()
    translationY = horizon() + ((1f - s) * 96f - 2f) * density
    transformOrigin = TransformOrigin(0.5f, 0f)
    scaleX = sunSize * scale; scaleY = sunSize * scale
}

private fun DrawScope.drawOvals(list: List<Oval>, color: Color, soft: Boolean, edgeFade: Boolean = false) {
    val d = density
    val ox = size.width / 2 - CX * d
    for (o in list) {
        val cx = ox + o.x * d
        val cy = o.y * d
        val rx = o.rx * d
        val ry = o.ry * d
        if (cx + rx < 0 || cx - rx > size.width) continue
        var a = o.o
        if (edgeFade) {
            val f = o.x / W
            a *= when { f < 0.18f -> (f / 0.18f).coerceIn(0f, 1f); f > 0.82f -> ((1 - f) / 0.18f).coerceIn(0f, 1f); else -> 1f }
        }
        val c = color.copy(alpha = color.alpha * a)
        if (soft) {
            val center = Offset(cx, cy)
            withTransform({ scale(1f, ry / rx, center) }) {
                drawCircle(Brush.radialGradient(0f to c, 0.55f to c, 1f to c.copy(alpha = 0f), center = center, radius = rx * 1.25f), rx * 1.25f, center)
            }
        } else {
            drawOval(c, topLeft = Offset(cx - rx, cy - ry), size = Size(rx * 2, ry * 2))
        }
    }
}

/** Shafts of light: each ray three times, narrower and stronger toward its core, so the edges are soft. */
private fun DrawScope.drawRays(p: Palette) {
    val d = density
    val c = Offset(size.width / 2, 0f)
    val brush = Brush.radialGradient(
        0.16f to p.ray.copy(alpha = p.ray0), 0.6f to p.ray.copy(alpha = p.ray1), 1f to p.ray.copy(alpha = 0f),
        center = c, radius = 480f * d,
    )
    val path = Path()
    for (k in 0 until 3) {
        val widen = 1.45f - k * 0.3f
        val alpha = 0.34f + k * 0.12f
        path.reset()
        for (ray in RAYS) {
            val tip = ray[1]; val tip2 = ray[2]
            val mid = Offset((tip.x + tip2.x) / 2, (tip.y + tip2.y) / 2)
            val a = c + ray[0] * d
            val b = c + (mid + (tip - mid) * widen) * d
            val e = c + (mid + (tip2 - mid) * widen) * d
            val f = c + ray[3] * d
            path.moveTo(a.x, a.y); path.lineTo(b.x, b.y); path.lineTo(e.x, e.y); path.lineTo(f.x, f.y); path.close()
        }
        drawPath(path, brush, alpha = alpha)
    }
}
