package sa.alshorouk.calculator.ui.motion

import android.content.Context
import android.provider.Settings
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring
import kotlin.math.abs
import kotlin.math.sqrt

/*
 * The springs of lib/motion.ts, expressed for Compose.
 * The web engine integrated (stiffness k, damping c, mass 1); Compose takes a damping ratio, which for the
 * same physics is c / (2·√k). Compose keeps the velocity of a running animation when its target changes,
 * which is exactly what the web engine was written for: a drag hands over to the settle without a seam.
 */
data class Phys(val stiffness: Float, val damping: Float, val threshold: Float = 0.01f) {
    val ratio: Float get() = damping / (2f * sqrt(stiffness))
    fun <T> spec(visibility: T? = null): SpringSpec<T> = spring(ratio, stiffness, visibility)
    val float: SpringSpec<Float> get() = spring(ratio, stiffness, threshold)
}

object Springs {
    // App.tsx: the sun
    val Sunrise = Phys(26f, 10.5f, 0.0015f)
    val Sunset = Phys(70f, 17f, 0.0015f)
    // Sheet.tsx
    val SheetOpen = Phys(270f, 29f, 0.3f)
    val SheetClose = Phys(330f, 37f, 0.5f)
    // the details sheet welling up out of its button: quick, and arriving without a bounce (the drop's
    // shape supplies the life); drawn back a touch faster
    val SheetMorphOpen = Phys(250f, 30f, 0.0004f)
    val SheetMorphClose = Phys(380f, 39f, 0.0004f)
    // LensSegmented.tsx
    val LensTravel = Phys(320f, 26f, 0.05f)
    val LensChase = Phys(900f, 54f, 0.05f)
    val LensLift = Phys(420f, 28f, 0.002f)
    // LiquidSwitch.tsx
    val Thumb = Phys(480f, 30f, 0.001f)
    val ThumbLift = Phys(460f, 26f, 0.002f)
    // RollingNumber.tsx
    val Roll = Phys(230f, 24f, 0.002f)
    // styles.css --spring (k=170 c=18), --spring-snappy (k=260 c=20), --spring-gentle (k=120 c=19)
    val Spring = Phys(170f, 18f, 0.001f)
    val Snappy = Phys(260f, 20f, 0.001f)
    val Gentle = Phys(120f, 19f, 0.001f)
    // things finding their place (a number re-centring, a size settling): quick, no bounce
    val Settle = Phys(400f, 38f, 0.01f)
    // press: swell 1.05, spring back
    val Press = Phys(260f, 20f, 0.0005f)
}

/** iOS-style resistance past a limit: the further you pull, the less it moves (lib/motion.ts). */
fun rubberBand(overshoot: Float, dimension: Float, coefficient: Float = 0.55f): Float {
    val sign = if (overshoot < 0) -1f else 1f
    val d = abs(overshoot)
    return sign * (d * dimension * coefficient) / (dimension + coefficient * d)
}

/** "Remove animations" in Android's accessibility settings sets the animator scale to 0. */
fun animationsDisabled(context: Context): Boolean =
    runCatching {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }.getOrDefault(false)
