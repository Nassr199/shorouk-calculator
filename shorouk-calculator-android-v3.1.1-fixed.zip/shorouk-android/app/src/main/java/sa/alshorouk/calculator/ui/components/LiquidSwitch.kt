package sa.alshorouk.calculator.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.horizontalDrag
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.launch
import sa.alshorouk.calculator.ui.LocalMotion
import sa.alshorouk.calculator.ui.LocalPalette
import sa.alshorouk.calculator.ui.motion.Springs
import sa.alshorouk.calculator.ui.motion.rubberBand
import kotlin.math.abs

/*
 * The switch of components/LiquidSwitch.tsx: 58 × 32, a 34 × 26 thumb.
 * Under the finger the thumb swells and turns into a drop of glass over the track; it can be dragged
 * and thrown, resists past the ends, and the colour of the track follows it continuously.
 * Taps are handled by the row that holds the switch (the whole row is the control).
 */
@Composable
fun LiquidSwitch(checked: Boolean, onDragToggle: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val motion = LocalMotion.current
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val progress = remember { Animatable(if (checked) 1f else 0f) }
    val lift = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val toggle by rememberUpdatedState(onDragToggle)
    val current by rememberUpdatedState(checked)
    val slop = LocalViewConfiguration.current.touchSlop

    LaunchedEffect(checked) {
        if (motion) progress.animateTo(if (checked) 1f else 0f, Springs.Thumb.float) else progress.snapTo(if (checked) 1f else 0f)
    }

    Canvas(
        modifier
            .size(58.dp, 32.dp)
            .pointerInput(rtl) {
                val travel = (58.dp - 6.dp - 34.dp).toPx()
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    scope.launch { lift.animateTo(1f, Springs.ThumbLift.float) }
                    val tracker = VelocityTracker()
                    tracker.addPosition(down.uptimeMillis, down.position)
                    val start = progress.value
                    var dx = 0f
                    var dragged = false
                    // wait for a horizontal move past the touch slop, otherwise it is a tap for the row
                    var pointer = down
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) { pointer = change; break }
                        dx += change.positionChange().x
                        if (abs(dx) > slop) { dragged = true; change.consume(); pointer = change; break }
                    }
                    if (dragged) {
                        horizontalDrag(pointer.id) { change ->
                            tracker.addPosition(change.uptimeMillis, change.position)
                            dx += change.positionChange().x
                            change.consume()
                            var next = start + dx / travel * (if (rtl) -1f else 1f)
                            if (next < 0f) next = rubberBand(next, 1f, 0.3f)
                            if (next > 1f) next = 1f + rubberBand(next - 1f, 1f, 0.3f)
                            scope.launch(start = CoroutineStart.UNDISPATCHED) { progress.snapTo(next) }
                        }
                        val v = tracker.calculateVelocity().x / travel * (if (rtl) -1f else 1f)
                        val on = if (abs(v) > 3f) v > 0 else progress.value > 0.5f
                        scope.launch { progress.animateTo(if (on) 1f else 0f, Springs.Thumb.float, initialVelocity = v) }
                        if (on != current) toggle(on)
                    }
                    scope.launch { lift.animateTo(0f, Springs.ThumbLift.float) }
                }
            },
    ) {
        drawSwitch(p.switchOff, progress.value, lift.value, abs(progress.velocity), rtl)
    }
}

private fun DrawScope.drawSwitch(off: Color, t: Float, lift: Float, speed: Float, rtl: Boolean) {
    val pad = 3.dp.toPx()
    val r = CornerRadius(size.height / 2)
    val pc = t.coerceIn(0f, 1f)
    // track, and the amber that floods it as the thumb travels
    drawRoundRect(off, cornerRadius = r)
    drawRoundRect(Color(0x2E0D3438), cornerRadius = r, style = Stroke(0.5.dp.toPx()))
    if (pc > 0.001f) drawRoundRect(Brush.verticalGradient(listOf(Color(0xFFF0AE2A), Color(0xFFE0931A))), cornerRadius = r, alpha = pc)

    val travel = size.width - pad * 2 - 34.dp.toPx()
    val stretch = (speed / 18f).coerceAtMost(0.18f)
    val w = 34.dp.toPx() * (1f + lift * 0.18f + stretch)
    val h = 26.dp.toPx() * (1f + lift * 0.16f - stretch * 0.2f)
    val along = pad + 17.dp.toPx() + t * travel
    val cx = if (rtl) size.width - along else along
    val cy = size.height / 2
    val tl = Offset(cx - w / 2, cy - h / 2)
    val thumb = Size(w, h)
    val tr = CornerRadius(h / 2)

    // the white thumb fades as it lifts into a lens
    val solid = 1f - lift * 0.94f
    if (solid > 0.01f) {
        drawRoundRect(Color(0x3D0D3438), tl + Offset(0f, 2.dp.toPx()), thumb, tr, alpha = solid)
        drawRoundRect(Color.White, tl, thumb, tr, alpha = solid)
    }
    val lens = (lift * 2f).coerceAtMost(1f)
    if (lens > 0.01f) {
        drawRoundRect(Color(0x660D3438), tl + Offset(0f, 4.dp.toPx()), thumb, tr, alpha = lens * 0.35f)
        drawRoundRect(Color.White.copy(alpha = 0.1f), tl, thumb, tr, alpha = lens)
        drawRoundRect(
            Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.6f), Color.Transparent),
                center = Offset(tl.x + w * 0.3f, tl.y + h * 0.1f), radius = w * 0.62f,
            ),
            tl, thumb, tr, alpha = lens,
        )
        drawRoundRect(Color.White.copy(alpha = 0.6f), tl, thumb, tr, style = Stroke(1.dp.toPx()), alpha = lens)
    }
}
