import { I18N, SERVICE_RATE, FIXED_FEE, VAT_RATE, SETTLEMENT_TABBY, SETTLEMENT_TAMARA, SETTLEMENT_THRESHOLD, TRANSFER_FEE_TOTAL } from '../constants';
import type { CalculationResult, Language, Provider } from '../types';

export interface CalcInput {
    price: string;
    provider: Provider;
    includeSettlement: boolean;
    lang: Language;
}

/**
 * The store's fee calculation, moved out of App.tsx without changing a single step,
 * so the UI can be redesigned freely and the maths can be tested on its own.
 */
export function calculateFees({ price, provider, includeSettlement, lang }: CalcInput): CalculationResult {
    const P_input = Math.max(0, Number(price) || 0);
    let X_calc = 0, baseFee_calc = 0, vat_calc = 0, totalServiceFee_calc = 0;
    let actualSettlementOrTransferFee = 0;
    let currentSettlementType: 'bank_transfer' | 'provider_settlement' | null = null;
    let providerName = null;
    let isSettlementFeeActive = false;

    const factorWithVat = 1 + VAT_RATE;
    const denominator = 1 - (SERVICE_RATE * factorWithVat);
    const fixedFeeComponent = FIXED_FEE * factorWithVat;

    let X_intermediate = 0;
    if (P_input > 0 && denominator > 0) {
        X_intermediate = (P_input + fixedFeeComponent) / denominator;
    } else {
        X_intermediate = P_input;
    }
    X_intermediate = Math.max(P_input, X_intermediate);

    if (X_intermediate >= SETTLEMENT_THRESHOLD) {
        actualSettlementOrTransferFee = TRANSFER_FEE_TOTAL;
        currentSettlementType = 'bank_transfer';
        providerName = lang === 'ar' ? 'تحويل بنكي' : 'Bank Transfer';
        isSettlementFeeActive = true;
    } else if (X_intermediate > 0) {
        const rawName = provider === 'tabby' ? I18N[lang].providerTabbyLabel : I18N[lang].providerTamaraLabel;
        providerName = rawName.split('(')[0].trim();

        if (includeSettlement) {
            actualSettlementOrTransferFee = provider === 'tabby' ? SETTLEMENT_TABBY : SETTLEMENT_TAMARA;
            currentSettlementType = 'provider_settlement';
            isSettlementFeeActive = true;
        } else {
            actualSettlementOrTransferFee = 0;
            currentSettlementType = 'provider_settlement';
            isSettlementFeeActive = false;
        }
    }

    if (P_input > 0 && denominator > 0) {
        X_calc = (P_input + fixedFeeComponent + actualSettlementOrTransferFee) / denominator;
        X_calc = Math.max(P_input, X_calc);

        if (X_calc >= 0.01) {
            baseFee_calc = (X_calc * SERVICE_RATE) + FIXED_FEE;
            vat_calc = baseFee_calc * VAT_RATE;
            totalServiceFee_calc = baseFee_calc + vat_calc;
        } else {
            X_calc = P_input;
            if (P_input === 0) {
                actualSettlementOrTransferFee = 0; isSettlementFeeActive = false; currentSettlementType = null;
            }
        }
    } else {
        X_calc = P_input;
    }

    return {
        P_input: P_input,
        X: Math.max(0, X_calc),
        baseFee: Math.max(0, baseFee_calc),
        vat: Math.max(0, vat_calc),
        totalServiceFee: Math.max(0, totalServiceFee_calc),
        S_final: Math.max(0, actualSettlementOrTransferFee),
        settlementType: currentSettlementType,
        providerForSettlement: providerName,
        settlementFeeActive: isSettlementFeeActive && actualSettlementOrTransferFee > 0
    };
}
