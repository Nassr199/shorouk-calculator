import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { flushSync } from 'react-dom';
import { I18N } from '../constants';
import type { Language, Theme } from '../types';

// same keys as the first version, so saved choices carry over
const THEME_KEY = 'calculatorThemeFluentV2';
const LANG_KEY = 'calculatorLangFluentV2';

// the browser / status bar takes the colour of the top of the sky
export const THEME_COLOR: Record<Theme, string> = { light: '#A9C8D3', dark: '#020A0D' };

const read = (key: string): string | null => {
    try { return localStorage.getItem(key); } catch { return null; }
};
const write = (key: string, value: string) => {
    try { localStorage.setItem(key, value); } catch { /* private mode: keep it for this visit only */ }
};

type ViewTransitionDoc = Document & {
    startViewTransition?: (update: () => void) => { ready: Promise<void>; finished: Promise<void> };
};

const prefersReducedMotion = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;

export function usePreferences() {
    const root = document.documentElement;
    const [theme, setTheme] = useState<Theme>(() => (root.dataset.theme === 'dark' ? 'dark' : 'light'));
    const [lang, setLang] = useState<Language>(() => (root.lang === 'en' ? 'en' : 'ar'));
    const themeChosen = useRef(read(THEME_KEY) !== null);
    // each toggle gets a number; only the latest one may remove its helper class when it finishes
    const themeRun = useRef(0);
    const langRun = useRef(0);

    useLayoutEffect(() => {
        root.dataset.theme = theme;
        document.querySelector('meta[name="theme-color"]')?.setAttribute('content', THEME_COLOR[theme]);
    }, [theme, root]);

    useLayoutEffect(() => {
        root.lang = lang;
        root.dir = lang === 'ar' ? 'rtl' : 'ltr';
        document.title = I18N[lang].pageTitle;
    }, [lang, root]);

    // Until the person picks a theme, follow the phone's light / dark setting.
    useEffect(() => {
        const mq = window.matchMedia?.('(prefers-color-scheme: dark)');
        if (!mq) return;
        const follow = () => { if (!themeChosen.current) setTheme(mq.matches ? 'dark' : 'light'); };
        mq.addEventListener?.('change', follow);
        return () => mq.removeEventListener?.('change', follow);
    }, []);

    /** Switches theme with a circular reveal that grows from the button that was pressed. */
    const toggleTheme = useCallback((origin?: { x: number; y: number }) => {
        const next: Theme = theme === 'dark' ? 'light' : 'dark';
        themeChosen.current = true;
        write(THEME_KEY, next);
        const commit = () => flushSync(() => setTheme(next));

        const doc = document as ViewTransitionDoc;
        if (!doc.startViewTransition || prefersReducedMotion()) { commit(); return; }

        const x = origin?.x ?? window.innerWidth / 2;
        const y = origin?.y ?? 0;
        const radius = Math.hypot(Math.max(x, window.innerWidth - x), Math.max(y, window.innerHeight - y));

        const run = ++themeRun.current;
        root.classList.add('theme-vt');
        const transition = doc.startViewTransition(commit);
        transition.ready.then(() => {
            root.animate(
                { clipPath: [`circle(0px at ${x}px ${y}px)`, `circle(${radius}px at ${x}px ${y}px)`] },
                { duration: 720, easing: 'cubic-bezier(0.65, 0, 0.35, 1)', pseudoElement: '::view-transition-new(root)' },
            );
        }).catch(() => { /* transition skipped */ });
        transition.finished.finally(() => {
            if (themeRun.current === run) root.classList.remove('theme-vt');
        });
    }, [theme, root]);

    /** Arabic ⇄ English with a short cross-fade, since the whole layout mirrors. */
    const toggleLang = useCallback(() => {
        const next: Language = lang === 'ar' ? 'en' : 'ar';
        write(LANG_KEY, next);
        // switch thumbs change sides with the layout; stop them sliding across while it mirrors
        const run = ++langRun.current;
        root.classList.add('lang-vt');
        const done = () => { if (langRun.current === run) root.classList.remove('lang-vt'); };
        const commit = () => flushSync(() => setLang(next));
        const doc = document as ViewTransitionDoc;
        if (!doc.startViewTransition || prefersReducedMotion()) {
            commit();
            requestAnimationFrame(() => requestAnimationFrame(done));
            return;
        }
        doc.startViewTransition(commit).finished.finally(done);
    }, [lang, root]);

    return { theme, lang, toggleTheme, toggleLang };
}
