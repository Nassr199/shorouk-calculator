import { Capacitor } from '@capacitor/core';
import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './styles.css';
import { initGlass } from './lib/glass';
import { initLight, initPress } from './lib/interaction';

// glass quality is decided before the first render; press feedback and the tilt-driven highlight are page-wide
initGlass();
initPress();
initLight();

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}

// PWA offline support (web only). Native Android bundles its built assets and must not be controlled by this service worker.
if (!Capacitor.isNativePlatform() && 'serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch((err) => {
      console.warn('Service worker registration failed:', err);
    });
  });
}
