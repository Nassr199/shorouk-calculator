package sa.alshorouk.calculator.core

import java.math.BigDecimal
import java.math.RoundingMode

/*
 * The store's fee calculation, ported line for line from lib/calc.ts (v3.1) and constants.ts.
 * Nothing here is "improved": the same steps, in the same order, with the same doubles,
 * so the Android app always charges exactly what the web app charges.
 * To change a rate or a fee, change it here only.
 */

object Fees {
    const val SERVICE_RATE = 0.0699
    const val FIXED_FEE = 1.5
    const val VAT_RATE = 0.15
    const val SETTLEMENT_TABBY = 28.75
    const val SETTLEMENT_TAMARA = 25.00
    const val TRANSFER_FEE_BASE = 6.00
    const val SETTLEMENT_THRESHOLD = 2500.0

    /** parseFloat((6 * 1.15).toFixed(2)) = 6.9 — the same rounding JavaScript applied. */
    val TRANSFER_FEE_TOTAL: Double = toFixed(TRANSFER_FEE_BASE * (1 + VAT_RATE), 2).toDouble()

    fun settlementFor(provider: Provider): Double =
        if (provider == Provider.Tabby) SETTLEMENT_TABBY else SETTLEMENT_TAMARA
}

enum class Provider { Tabby, Tamara }

enum class SettlementType { BankTransfer, ProviderSettlement }

data class CalculationResult(
    val pInput: Double,
    val x: Double,
    val baseFee: Double,
    val vat: Double,
    val totalServiceFee: Double,
    val sFinal: Double,
    val settlementType: SettlementType?,
    val providerForSettlement: String?,
    val settlementFeeActive: Boolean,
) {
    val hasAmount: Boolean get() = pInput > 0
    /** Everything that is not the store's: service fee + VAT + settlement / transfer. */
    val fees: Double get() = totalServiceFee + sFinal
    val feeShare: Double get() = if (x > 0) fees / x * 100 else 0.0

    companion object {
        val Empty = CalculationResult(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, null, null, false)
    }
}

/** JavaScript's Number("…") for the canonical strings the amount field produces ("", "12", "12.", ".5", "2500.50"). */
fun jsNumber(text: String): Double {
    val s = text.trim()
    if (s.isEmpty()) return 0.0
    if (s == ".") return Double.NaN
    return s.toDoubleOrNull() ?: Double.NaN
}

/**
 * calculateFees({ price, provider, includeSettlement, lang }) from lib/calc.ts.
 * [providerName] gives the localized provider name the original took from I18N (label up to the "(").
 */
fun calculateFees(
    price: String,
    provider: Provider,
    includeSettlement: Boolean,
    providerName: (Provider) -> String,
    bankTransferName: String,
): CalculationResult {
    val parsed = jsNumber(price)
    val pInput = maxOf(0.0, if (parsed.isNaN()) 0.0 else parsed)          // Math.max(0, Number(price) || 0)
    var xCalc = 0.0
    var baseFeeCalc = 0.0
    var vatCalc = 0.0
    var totalServiceFeeCalc = 0.0
    var actualSettlementOrTransferFee = 0.0
    var currentSettlementType: SettlementType? = null
    var name: String? = null
    var isSettlementFeeActive = false

    val factorWithVat = 1 + Fees.VAT_RATE
    val denominator = 1 - (Fees.SERVICE_RATE * factorWithVat)
    val fixedFeeComponent = Fees.FIXED_FEE * factorWithVat

    var xIntermediate = if (pInput > 0 && denominator > 0) (pInput + fixedFeeComponent) / denominator else pInput
    xIntermediate = maxOf(pInput, xIntermediate)

    if (xIntermediate >= Fees.SETTLEMENT_THRESHOLD) {
        actualSettlementOrTransferFee = Fees.TRANSFER_FEE_TOTAL
        currentSettlementType = SettlementType.BankTransfer
        name = bankTransferName
        isSettlementFeeActive = true
    } else if (xIntermediate > 0) {
        name = providerName(provider)
        currentSettlementType = SettlementType.ProviderSettlement
        if (includeSettlement) {
            actualSettlementOrTransferFee = Fees.settlementFor(provider)
            isSettlementFeeActive = true
        } else {
            actualSettlementOrTransferFee = 0.0
            isSettlementFeeActive = false
        }
    }

    if (pInput > 0 && denominator > 0) {
        xCalc = (pInput + fixedFeeComponent + actualSettlementOrTransferFee) / denominator
        xCalc = maxOf(pInput, xCalc)
        if (xCalc >= 0.01) {
            baseFeeCalc = (xCalc * Fees.SERVICE_RATE) + Fees.FIXED_FEE
            vatCalc = baseFeeCalc * Fees.VAT_RATE
            totalServiceFeeCalc = baseFeeCalc + vatCalc
        } else {
            xCalc = pInput
            if (pInput == 0.0) {
                actualSettlementOrTransferFee = 0.0; isSettlementFeeActive = false; currentSettlementType = null
            }
        }
    } else {
        xCalc = pInput
    }

    return CalculationResult(
        pInput = pInput,
        x = maxOf(0.0, xCalc),
        baseFee = maxOf(0.0, baseFeeCalc),
        vat = maxOf(0.0, vatCalc),
        totalServiceFee = maxOf(0.0, totalServiceFeeCalc),
        sFinal = maxOf(0.0, actualSettlementOrTransferFee),
        settlementType = currentSettlementType,
        providerForSettlement = name,
        settlementFeeActive = isSettlementFeeActive && actualSettlementOrTransferFee > 0,
    )
}

/**
 * Number.prototype.toFixed: rounds the exact binary value of the double, ties to the larger value.
 * (String.format would round its shortest decimal form instead and can differ by a cent.)
 */
fun toFixed(value: Double, digits: Int): String {
    if (value.isNaN()) return "NaN"
    val bd = BigDecimal(value).setScale(digits, if (value >= 0) RoundingMode.HALF_UP else RoundingMode.HALF_DOWN)
    return bd.toPlainString().let { if (it.startsWith("-") && bd.signum() == 0) it.substring(1) else it }
}
