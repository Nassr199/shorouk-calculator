package sa.alshorouk.calculator.ui.glass

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi

/*
 * Liquid glass, the optical part, as one AGSL shader (Android 13+).
 *
 * What makes the material read as glass rather than as frosted plastic (the same findings as the reference
 * implementations of the look — kube.io's "Liquid Glass in the browser", Kyant's Backdrop for Compose,
 * Haze's liquid glass):
 *  - the pane is nearly clear: a light blur only, so what is behind stays recognisable;
 *  - all bending happens in the bezel, the curved band along the edge; the face is flat and shows the
 *    backdrop straight through;
 *  - the bezel is a convex squircle, y = (1 − (1 − x)^4)^(1/4): it meets the face without a visible seam and
 *    keeps the bending close to the edge;
 *  - the bend follows Snell's law for a ray entering glass of index 1.5 through that slope, with a little
 *    dispersion (red bends less than blue);
 *  - the rim light and the tint are drawn on top by the pane, not here.
 *
 * The same program serves two shapes: a whole pane (the layer is the pane), and a lens that travels inside
 * a larger layer (a segmented control's selection): there it also magnifies about its centre and leaves
 * everything outside itself transparent.
 *
 * It runs per pixel on the GPU inside the platform's own renderer (HWUI → Skia, on Vulkan or OpenGL ES as
 * the device chooses → the driver: Adreno, Mali, Immortalis, PowerVR, Xclipse). Written for mobile GPUs:
 *  - every coordinate is `float` (32-bit). `half` is 16-bit on Mali and on many Adreno drivers and visibly
 *    stair-steps positions beyond ~2048 px. Only what is sampled is `half`;
 *  - no trigonometry (the refraction is solved with two square roots), no loops, no derivatives;
 *  - the flat face, most of the pixels, takes one sample and leaves early.
 */
@RequiresApi(Build.VERSION_CODES.TIRAMISU)
class Refraction {
    private val shader = RuntimeShader(AGSL)

    /**
     * The lens for a glass shape of [w]×[h] px whose top-left is at ([ox], [oy]) in its layer, applied after
     * [input] (the light blur and saturation lift), or null if the driver refuses it — the caller then keeps
     * the frosted look and the app carries on.
     * @param bezel width of the curved rim, px    @param depth thickness of the glass there, px
     * @param magnify 1 for a pane; above 1 a lens enlarges what is under it
     * @param cutout false: the layer is the pane; true: a lens inside a larger layer, transparent around it
     */
    fun lens(
        ox: Float, oy: Float, w: Float, h: Float, radius: Float, bezel: Float, depth: Float,
        dispersion: Float, magnify: Float, cutout: Boolean, input: RenderEffect?,
    ): RenderEffect? = try {
        shader.setFloatUniform("origin", ox, oy)
        shader.setFloatUniform("size", w, h)
        shader.setFloatUniform("radius", radius)
        shader.setFloatUniform("bezel", bezel)
        shader.setFloatUniform("depth", depth)
        shader.setFloatUniform("dispersion", dispersion)
        shader.setFloatUniform("magnify", magnify)
        shader.setFloatUniform("cutout", if (cutout) 1f else 0f)
        val bend = RenderEffect.createRuntimeShaderEffect(shader, "content")
        if (input == null) bend else RenderEffect.createChainEffect(bend, input)
    } catch (e: RuntimeException) {
        null
    }

    companion object {
        /** The light frost every pane has (Android 12+): blur, then the saturation lift that keeps colours alive. */
        @RequiresApi(Build.VERSION_CODES.S)
        fun frost(blurRadius: Float, saturation: Float): RenderEffect? {
            val blur = if (blurRadius >= 0.5f) RenderEffect.createBlurEffect(blurRadius, blurRadius, Shader.TileMode.CLAMP) else null
            if (saturation == 1f) return blur
            val filter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(saturation) })
            return if (blur == null) RenderEffect.createColorFilterEffect(filter)
            else RenderEffect.createColorFilterEffect(filter, blur)
        }

        /** CSS blur() takes a standard deviation; Android takes a radius (Skia: sigma = 0.57735·r + 0.5). */
        fun radiusForSigma(sigmaPx: Float): Float = ((sigmaPx - 0.5f) / 0.57735f).coerceAtLeast(0f)

        private const val AGSL = """
uniform shader content;
uniform float2 origin;
uniform float2 size;
uniform float radius;
uniform float bezel;
uniform float depth;
uniform float dispersion;
uniform float magnify;
uniform float cutout;

float sdRound(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + float2(r, r);
    return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0, 0.0))) - r;
}

half4 main(float2 coord) {
    float2 hs = size * 0.5;
    float2 p = coord - origin - hs;
    float r = min(radius, min(hs.x, hs.y));
    float inside = -sdRound(p, hs, r);
    if (inside <= 0.0) {
        if (cutout > 0.5) {
            return half4(0.0, 0.0, 0.0, 0.0);
        }
        return content.eval(coord);
    }

    // the flat face: seen straight through (a lens also enlarges about its centre)
    float2 base = origin + hs + p / magnify;
    float bz = max(min(bezel, min(hs.x, hs.y)), 1.0);
    float4 col = float4(0.0, 0.0, 0.0, 0.0);
    if (inside >= bz) {
        half4 s = content.eval(base);
        col = float4(s.r, s.g, s.b, s.a);
    } else {
        // outward normal of the rounded rectangle, from the distance field itself
        float e = 0.75;
        float2 g = float2(
            sdRound(p + float2(e, 0.0), hs, r) - sdRound(p - float2(e, 0.0), hs, r),
            sdRound(p + float2(0.0, e), hs, r) - sdRound(p - float2(0.0, e), hs, r));
        float2 n = g / max(length(g), 0.0001);

        // convex squircle bezel: u = 1 at the edge, 0 where the face begins; slope of its surface
        float u = 1.0 - inside / bz;
        float u2 = u * u;
        float q = sqrt(sqrt(max(1.0 - u2 * u2, 0.000001)));
        float slope = (u2 * u) / (q * q * q);
        // Snell's law into glass (n = 1.5), without trigonometry: tan(incidence - refraction)
        float c1 = 1.0 / sqrt(1.0 + slope * slope);
        float s1 = slope * c1;
        float s2 = s1 / 1.5;
        float c2 = sqrt(1.0 - s2 * s2);
        float bend = depth * (s1 * c2 - c1 * s2) / (c1 * c2 + s1 * s2);

        // dispersion: red bends a little less than green, blue a little more
        half4 cr = content.eval(base - n * (bend * (1.0 - dispersion)));
        half4 cg = content.eval(base - n * bend);
        half4 cb = content.eval(base - n * (bend * (1.0 + dispersion)));
        col = float4(cr.r, cg.g, cb.b, cg.a);
    }
    if (cutout > 0.5) {
        // a lens has an edge of its own: one pixel of anti-aliasing
        float a = clamp(inside, 0.0, 1.0);
        return half4(col.r * a, col.g * a, col.b * a, col.a * a);
    }
    return half4(col.r, col.g, col.b, col.a);
}
"""
    }
}
