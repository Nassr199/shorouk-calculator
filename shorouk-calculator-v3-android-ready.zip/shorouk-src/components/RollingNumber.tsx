import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Spring } from '../lib/motion';
import { splitMoney } from '../lib/format';

/*
 * Odometer money.
 *
 *  - Every digit is driven by its own spring, so a new value arriving mid-roll bends the motion
 *    instead of restarting it (type fast and watch: nothing stutters).
 *  - Digits take the shortest way round the wheel: 9 → 0 is one step forward, not nine back.
 *  - Columns are keyed by their distance from the decimal point. 999 → 1,000 rolls the three existing
 *    digits and slides a new column in; 1,000 → 999 slides it out again rather than cutting it.
 */

interface Cell {
    key: string;
    kind: 'digit' | 'sep';
    char: string;
    part: 'int' | 'dec';
    phase: 'live' | 'in' | 'out';
    rank: number;          // 0 = right-most digit of the whole number (moves first)
}

const EXIT_MS = 300;
const STAGGER_MS = 16;
const MAX_STAGGER_MS = 90;
const ROLL = { stiffness: 230, damping: 24, precision: 0.002 };

const wrap = (n: number) => ((n % 10) + 10) % 10;

function layout(value: number, decimals: boolean): Omit<Cell, 'phase'>[] {
    const { int, dec } = splitMoney(value);
    const cells: Omit<Cell, 'phase'>[] = [];
    const decDigits = decimals ? dec.length : 0;
    const intChars = int.split('');
    let digitsToRight = intChars.filter((c) => c !== ',').length;
    for (const ch of intChars) {
        if (ch === ',') {
            cells.push({ key: `c${digitsToRight}`, kind: 'sep', char: ',', part: 'int', rank: 0 });
        } else {
            digitsToRight--;
            cells.push({ key: `i${digitsToRight}`, kind: 'digit', char: ch, part: 'int', rank: digitsToRight + decDigits });
        }
    }
    if (decimals) {
        cells.push({ key: 'p', kind: 'sep', char: '.', part: 'dec', rank: 0 });
        dec.split('').forEach((ch, i) => {
            cells.push({ key: `d${i}`, kind: 'digit', char: ch, part: 'dec', rank: dec.length - 1 - i });
        });
    }
    return cells;
}

function Digit({ digit, rank, entering }: { digit: number; rank: number; entering: boolean }) {
    const top = useRef<HTMLSpanElement>(null);
    const bottom = useRef<HTMLSpanElement>(null);
    const spring = useRef<Spring | null>(null);

    // Two faces are enough for any roll: the digit leaving through the top and the one arriving below it.
    const paint = (position: number) => {
        const a = top.current;
        const b = bottom.current;
        if (!a || !b) return;
        const base = Math.floor(position);
        const fraction = position - base;
        const first = String(wrap(base));
        const second = String(wrap(base + 1));
        if (a.textContent !== first) a.textContent = first;
        if (b.textContent !== second) b.textContent = second;
        a.style.transform = `translate3d(0, ${(-fraction * 100).toFixed(2)}%, 0)`;
        b.style.transform = `translate3d(0, ${((1 - fraction) * 100).toFixed(2)}%, 0)`;
    };

    useLayoutEffect(() => {
        const start = entering ? digit - 1 : digit;       // a new column rolls its digit up into place
        const s = new Spring(start, ROLL, paint);
        spring.current = s;
        paint(start);
        if (entering) s.to(digit);
        return () => s.dispose();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        const s = spring.current;
        if (!s) return;
        const from = Math.round(s.target);
        if (wrap(from) === digit) return;
        const step = ((digit - wrap(from) + 15) % 10) - 5;        // shortest way round: −5 … +4
        s.to(from + step, { delay: Math.min(MAX_STAGGER_MS, rank * STAGGER_MS) });
    }, [digit, rank]);

    return (
        <>
            <span className="num__face" ref={top} />
            <span className="num__face" ref={bottom} />
        </>
    );
}

interface RollingNumberProps {
    value: number;
    /** Show the two decimals (default). */
    decimals?: boolean;
    className?: string;
}

export function RollingNumber({ value, decimals = true, className = '' }: RollingNumberProps) {
    const [cells, setCells] = useState<Cell[]>(() => layout(value, decimals).map((c) => ({ ...c, phase: 'live' as const })));
    const timers = useRef(new Map<string, number>());
    const signature = layout(value, decimals).map((c) => c.key + c.char).join('|');

    useEffect(() => {
        const wanted = layout(value, decimals);
        const wantedKeys = new Set(wanted.map((c) => c.key));
        setCells((previous) => {
            const known = new Map(previous.map((c) => [c.key, c]));
            const leaving = previous
                .filter((c) => !wantedKeys.has(c.key))
                .map((c) => ({ ...c, phase: 'out' as const }));
            const staying = wanted.map((c) => {
                const old = known.get(c.key);
                // a column that was on its way out and is needed again simply stays
                const phase: Cell['phase'] = !old ? 'in' : old.phase === 'out' ? 'live' : old.phase;
                return { ...c, phase };
            });
            return [...leaving.filter((c) => c.part === 'int'), ...staying];
        });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [signature]);

    // Columns marked "out" are removed once their exit has played.
    useEffect(() => {
        const pending = timers.current;
        const leaving = new Set(cells.filter((c) => c.phase === 'out').map((c) => c.key));
        pending.forEach((id, key) => {
            if (!leaving.has(key)) { clearTimeout(id); pending.delete(key); }
        });
        leaving.forEach((key) => {
            if (pending.has(key)) return;
            pending.set(key, window.setTimeout(() => {
                pending.delete(key);
                setCells((current) => current.filter((c) => !(c.key === key && c.phase === 'out')));
            }, EXIT_MS));
        });
    }, [cells]);

    useEffect(() => () => { timers.current.forEach((id) => clearTimeout(id)); }, []);

    const render = (cell: Cell) => (
        cell.kind === 'sep'
            ? <span key={cell.key} className="num__sep" data-phase={cell.phase}>{cell.char}</span>
            : (
                <span key={cell.key} className="num__col" data-phase={cell.phase}>
                    <Digit digit={Number(cell.char)} rank={cell.rank} entering={cell.phase === 'in'} />
                </span>
            )
    );

    return (
        <span className={`num ${className}`.trim()} aria-hidden="true">
            <span className="num__int">{cells.filter((c) => c.part === 'int').map(render)}</span>
            {decimals && <span className="num__dec">{cells.filter((c) => c.part === 'dec').map(render)}</span>}
        </span>
    );
}
