import { useRef } from 'react';
import type { CalculationResult, I18nData, Provider } from '../types';
import { SETTLEMENT_TABBY, SETTLEMENT_TAMARA, SETTLEMENT_THRESHOLD, TRANSFER_FEE_TOTAL } from '../constants';
import { fill } from '../lib/format';
import { Glass } from './Glass';
import { LiquidSwitch, LiquidSwitchHandle } from './LiquidSwitch';
import { RollingNumber } from './RollingNumber';
import { IconBank } from './Icons';

interface SettlementRowProps {
    t: I18nData;
    result: CalculationResult;
    includeSettlement: boolean;
    onChange: (next: boolean) => void;
    provider: Provider;
}

/**
 * Below 2,500 the store decides whether to add the provider's settlement fee, and the amount shown
 * follows the chosen provider. From 2,500 the calculation always applies the bank transfer fee, so
 * the switch gives way to a row that says so (a switch that does nothing would be a lie).
 */
export function SettlementRow({ t, result, includeSettlement, onChange, provider }: SettlementRowProps) {
    const { ui } = t;
    const currency = t.currencySuffix.trim();
    const isTransfer = result.settlementType === 'bank_transfer';
    const fee = provider === 'tabby' ? SETTLEMENT_TABBY : SETTLEMENT_TAMARA;
    const switchRef = useRef<LiquidSwitchHandle>(null);

    return (
        <Glass className="settle" data-mode={isTransfer ? 'transfer' : 'switch'} bezel={18} depth={22} blur={6}>
            <button
                type="button"
                role="switch"
                aria-checked={includeSettlement}
                aria-labelledby="settle-title"
                aria-describedby="settle-hint settle-fee"
                className="settle__face settle__face--switch"
                inert={isTransfer}
                onClick={() => {
                    if (switchRef.current?.consumeDrag()) return;        // the drag already decided
                    onChange(!includeSettlement);
                }}
            >
                <span className="settle__text">
                    <span className="settle__title" id="settle-title">{ui.settlementToggle}</span>
                    <span className="settle__hint" id="settle-hint">{ui.settlementShort}</span>
                </span>
                <span className="settle__fee" data-on={includeSettlement}>
                    <RollingNumber value={fee} />
                    <small aria-hidden="true">{currency}</small>
                    <span className="sr-only" id="settle-fee">{fee.toFixed(2)} {currency}</span>
                </span>
                <LiquidSwitch ref={switchRef} checked={includeSettlement} onDragToggle={onChange} />
            </button>

            <div className="settle__face settle__face--transfer" inert={!isTransfer}>
                <span className="settle__icon" aria-hidden="true"><IconBank size={21} /></span>
                <span className="settle__text">
                    <span className="settle__title">{ui.transferTitle}</span>
                    <span className="settle__hint">
                        {fill(ui.transferHint, { T: SETTLEMENT_THRESHOLD.toLocaleString('en-US') })}
                    </span>
                </span>
                <span className="settle__fee" data-on="true">
                    <span className="money">{TRANSFER_FEE_TOTAL.toFixed(2)}</span>
                    <small>{currency}</small>
                </span>
            </div>
        </Glass>
    );
}
