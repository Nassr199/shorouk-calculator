import React from 'react';
import type { CalculationResult, I18nData } from '../types';
import { fill, formatMoney, formatPercent, splitMoney } from '../lib/format';
import { emWidth } from '../lib/amount';
import { Glass } from './Glass';
import { RollingNumber } from './RollingNumber';

interface ResultSlabProps {
    t: I18nData;
    result: CalculationResult;
    onCopy: () => void;
    slabRef: React.Ref<HTMLElement>;
}

/**
 * What the customer pays, split into what reaches the store and what goes in fees.
 * The two boundaries are CSS percentages (--a, --b); the stylesheet slides the segments to them with
 * transforms, so nothing is laid out or repainted while the bar moves.
 */
function CompositionBar({ net, fee, settle, label }: { net: number; fee: number; settle: number; label: string }) {
    const total = net + fee + settle;
    const a = total > 0 ? (net / total) * 100 : 0;
    const b = total > 0 ? ((net + fee) / total) * 100 : 0;
    return (
        <div
            className="bar"
            role="img"
            aria-label={label}
            data-settle={settle > 0}
            style={{ '--a': `${a.toFixed(3)}%`, '--b': `${b.toFixed(3)}%` } as React.CSSProperties}
        >
            <span className="bar__seg bar__seg--net" />
            <span className="bar__seg bar__seg--fee"><span className="bar__fill" /></span>
            <span className="bar__seg bar__seg--settle" />
        </div>
    );
}

/**
 * The one large pane of glass. The sun rises behind it, so the amount is read through lit glass.
 * Tapping the amount copies it.
 */
export function ResultSlab({ t, result, onCopy, slabRef }: ResultSlabProps) {
    const { ui } = t;
    const currency = t.currencySuffix.trim();
    const ready = result.P_input > 0;
    const fees = result.totalServiceFee + result.S_final;
    const feeShare = result.X > 0 ? (fees / result.X) * 100 : 0;
    const { int } = splitMoney(result.X);
    const money = `${formatMoney(result.X)} ${currency}`;

    // integer digits + small decimals + currency, in em of the amount's font size
    const em = emWidth(int, 0.62, 0.3) + 1.9;

    return (
        <Glass
            as="section"
            ref={slabRef}
            className="slab"
            data-state={ready ? 'ready' : 'empty'}
            aria-labelledby="result-label"
            style={{ '--em': em } as React.CSSProperties}
            bezel={26}
            depth={30}
            blur={7}
            dispersion={0.045}
            saturate={1.4}
        >
            <span className="slab__sun" aria-hidden="true" />
            <h2 className="slab__label" id="result-label">{ui.resultLabel}</h2>

            <button
                type="button"
                className="slab__amount"
                data-press=""
                onClick={onCopy}
                disabled={!ready}
                aria-label={ready ? fill(ui.copyThis, { X: money }) : money}
            >
                <span className="slab__figure">
                    <RollingNumber value={result.X} />
                    <span className="slab__currency" aria-hidden="true">{currency}</span>
                </span>
            </button>

            <div className="slab__foot">
                <div className="slab__meta" inert={!ready}>
                    <div className="legend">
                        <div className="legend__item">
                            <span className="legend__label">
                                <span className="legend__swatch swatch-net" aria-hidden="true" />
                                {ui.netShort}
                            </span>
                            <span className="legend__value money">{formatMoney(result.P_input)}</span>
                        </div>
                        <div className="legend__item legend__item--end">
                            <span className="legend__label">
                                <span className="legend__swatch swatch-fee" aria-hidden="true" />
                                {ui.feesShort}
                                <span className="legend__share">{fill(ui.feeShare, { R: formatPercent(feeShare) })}</span>
                            </span>
                            <span className="legend__value money">{formatMoney(fees)}</span>
                        </div>
                    </div>
                    <CompositionBar
                        net={result.P_input}
                        fee={result.totalServiceFee}
                        settle={result.S_final}
                        label={fill(ui.breakdownLabel, {
                            X: money,
                            P: `${formatMoney(result.P_input)} ${currency}`,
                            F: `${formatMoney(fees)} ${currency}`,
                        })}
                    />
                </div>
                <p className="slab__empty" aria-hidden={ready}>{ui.resultEmpty}</p>
            </div>
        </Glass>
    );
}
