# بناء APK لحاسبة الشروق

تم تجهيز المشروع ليُغلّف كتطبيق Android باستخدام Capacitor 8، مع الإبقاء على كود React ومنطق الحساب والتصميم كما هي. التطبيق الناتج حزمة Android قابلة للتثبيت، ويعرض الواجهة داخل Android WebView؛ ليس إعادة كتابة كاملة للواجهة بلغة Kotlin.

## متطلبات البناء على جهازك

- Node.js 22 أو أحدث.
- Android Studio حديث يدعم Capacitor 8 (الإصدار 2025.2.1 أو أحدث).
- Android SDK، مع تثبيت Android API 36.
- JDK 21.

## إنشاء مشروع Android لأول مرة

من مجلد المشروع:

```bash
npm install
npm run build
npx cap add android
npm run android:assets
npx cap sync android
npx cap open android
```

بعد فتح Android Studio انتظر اكتمال Gradle Sync، ثم اختر:

`Build > Build Bundle(s) / APK(s) > Build APK(s)`

سيظهر APK التجريبي عادةً في:

`android/app/build/outputs/apk/debug/app-debug.apk`

## البناء بأمر واحد بعد التهيئة الأولى

بعد إنشاء مجلد `android` لأول مرة (باستخدام `npm run android:init` أو الأوامر أعلاه):

```bash
npm run android:apk
```

## استخراج APK تلقائيًا من GitHub

ارفع المشروع إلى مستودع GitHub، ثم افتح تبويب **Actions** واختر **Build Shorouk Android APK** واضغط **Run workflow**. ويمكن تشغيل البناء تلقائيًا عند الدفع إلى فرع `main` أو `master`.

بعد اكتمال المهمة، نزّل العنصر باسم `shorouk-calculator-v3-debug-apk` من قسم Artifacts. يحتوي على ملف `shorouk-calculator-v3-debug.apk`.

## نوع التوقيع

الـ APK الذي ينتجه هذا الإعداد هو **Debug APK موقّع بمفتاح debug تلقائي**، مناسب للتثبيت والاختبار والتوزيع الشخصي. ليس إصدار متجر Google Play ولا يحمل توقيعًا خاصًا باسم مالك التطبيق. للنشر الرسمي أو لإصدار تحديثات متوافقة مستقبلًا، يجب إنشاء Keystore خاص والاحتفاظ به بأمان ثم إعداد توقيع Release.

## ملاحظات

- تم تعطيل تسجيل Service Worker داخل غلاف Android؛ ملفات التطبيق الأساسية تكون مضمنة داخل APK، بينما يبقى Service Worker مفعّلًا في نسخة الويب/PWA.
- الخطوط وشعارات الجهات الخارجية التي يستدعيها المصدر من الإنترنت قد تحتاج اتصالًا عند أول تحميل، لأنها ليست ملفات محلية ضمن المصدر الحالي.
- معرّف التطبيق الحالي هو `sa.shorouk.calculator`. ثبّته قبل إصدار النسخة العامة؛ تغييره لاحقًا يجعل Android يتعامل مع الحزمة كتطبيق مختلف.
