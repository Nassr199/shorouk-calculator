import { prefersReducedMotion } from './motion';

/*
 * Two document-level behaviours shared by every glass control:
 *
 *  - Press: an element marked data-press lights up from the exact point it was touched and swells a
 *    little, then springs back (the CSS reads --px / --py and [data-pressed]).
 *  - Light: the bright arc on every glass rim turns with the phone's tilt (or the mouse on a desktop),
 *    the way a highlight slides around a real glass edge. CSS reads html[data-tilt].
 */

const MIN_PRESS_MS = 130;   // a quick tap still shows the press

export function initPress(): () => void {
    let current: HTMLElement | null = null;
    let downAt = 0;
    let timer = 0;

    const release = () => {
        const el = current;
        if (!el) return;
        current = null;
        const wait = Math.max(0, MIN_PRESS_MS - (performance.now() - downAt));
        timer = window.setTimeout(() => el.removeAttribute('data-pressed'), wait);
    };

    const onDown = (e: PointerEvent) => {
        if (e.button !== 0) return;
        const el = (e.target as Element | null)?.closest<HTMLElement>('[data-press]');
        if (!el || el.matches(':disabled, [aria-disabled="true"]')) return;
        clearTimeout(timer);
        current?.removeAttribute('data-pressed');
        const rect = el.getBoundingClientRect();
        el.style.setProperty('--px', `${(((e.clientX - rect.left) / rect.width) * 100).toFixed(1)}%`);
        el.style.setProperty('--py', `${(((e.clientY - rect.top) / rect.height) * 100).toFixed(1)}%`);
        el.setAttribute('data-pressed', 'true');
        current = el;
        downAt = performance.now();
    };

    document.addEventListener('pointerdown', onDown, { passive: true });
    document.addEventListener('pointerup', release, { passive: true });
    document.addEventListener('pointercancel', release, { passive: true });
    return () => {
        document.removeEventListener('pointerdown', onDown);
        document.removeEventListener('pointerup', release);
        document.removeEventListener('pointercancel', release);
        clearTimeout(timer);
    };
}

/*
 * Light. The highlight has five positions. A deliberate tilt of the phone (or a move of the mouse across a
 * desktop window) switches position, and CSS turns the rims there with a transition. A hand that is merely
 * unsteady changes nothing, so the page is not restyled and repainted while it is just being held.
 * (The first version followed the sensor continuously through a variable on <html>: every frame restyled
 * the whole document and repainted every pane. That was the single largest cost on a phone.)
 */
const STEP_DEG = 11;        // degrees of roll per highlight position
const HYSTERESIS = 3.5;     // extra degrees needed to leave the current position
const MAX_STEP = 2;

export function initLight(): () => void {
    if (prefersReducedMotion()) return () => {};
    const root = document.documentElement;
    let step = 0;
    let centre: number | null = null;       // the angle the phone is normally held at becomes "no tilt"

    const set = (next: number) => {
        if (next === step) return;
        step = next;
        if (step === 0) root.removeAttribute('data-tilt');
        else root.setAttribute('data-tilt', String(step));
    };
    const place = (degrees: number) => {
        const exact = degrees / STEP_DEG;
        if (Math.abs(degrees - step * STEP_DEG) < STEP_DEG / 2 + HYSTERESIS) return;
        set(Math.max(-MAX_STEP, Math.min(MAX_STEP, Math.round(exact))));
    };

    const onTilt = (e: DeviceOrientationEvent) => {
        if (e.gamma == null) return;
        if (centre === null) centre = e.gamma;
        centre += (e.gamma - centre) * 0.002;                      // drifts slowly toward how it is being held
        place(e.gamma - centre);
    };
    const onPointer = (e: PointerEvent) => {
        if (e.pointerType !== 'mouse') return;
        place(((e.clientX / window.innerWidth) * 2 - 1) * STEP_DEG * (MAX_STEP + 0.4));
    };

    window.addEventListener('deviceorientation', onTilt, { passive: true });
    window.addEventListener('pointermove', onPointer, { passive: true });
    return () => {
        window.removeEventListener('deviceorientation', onTilt);
        window.removeEventListener('pointermove', onPointer);
        root.removeAttribute('data-tilt');
    };
}

/** Light vibration on supported phones. */
export const haptic = (ms: number) => {
    try { navigator.vibrate?.(ms); } catch { /* not supported */ }
};
