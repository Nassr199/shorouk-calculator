package sa.alshorouk.calculator.platform

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/*
 * The store's logo, from the same address the web app uses (components/Extras.tsx).
 * Downloaded once, kept in the app's private files, so it is there offline and in printed receipts.
 * Until then — or if it can never be fetched — the drawn sun mark stands in.
 */
object StoreLogo {
    const val URL_LOGO = "https://www2.0zz0.com/2025/04/29/23/183916568.png"

    @Volatile var cached: ImageBitmap? = null
        private set
    @Volatile var bitmap: Bitmap? = null
        private set
    /** The round emblem alone, for small places; null if the logo is not built that way. */
    @Volatile var emblem: ImageBitmap? = null
        private set

    private fun file(context: Context) = File(context.filesDir, "store-logo.png")

    suspend fun get(context: Context): ImageBitmap? = withContext(Dispatchers.IO) {
        cached?.let { return@withContext it }
        val f = file(context)
        decode(f)?.let { return@withContext it }
        runCatching {
            val conn = (URL(URL_LOGO).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000; readTimeout = 8000; instanceFollowRedirects = true
            }
            try {
                if (conn.responseCode in 200..299) {
                    val tmp = File(f.parentFile, "store-logo.tmp")
                    conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                    if (BitmapFactory.decodeFile(tmp.path) != null) tmp.renameTo(f) else tmp.delete()
                }
            } finally { conn.disconnect() }
        }
        decode(f)
    }

    private fun decode(f: File): ImageBitmap? {
        if (!f.isFile) return null
        val bmp = BitmapFactory.decodeFile(f.path) ?: return null
        bitmap = bmp
        emblem = runCatching { findEmblem(bmp)?.asImageBitmap() }.getOrNull()
        return bmp.asImageBitmap().also { cached = it }
    }

    /*
     * The logo is a round emblem with the store's name written under it. At the size of a button the writing
     * is a smudge, so the bar shows the emblem alone, filling its circle. It is found, not assumed: the first
     * block of rows that carry ink, down to the first clear gap; if what is found is not roughly square (a
     * different logo one day), there is no emblem and the whole logo is shown as before.
     */
    private fun findEmblem(src: Bitmap): Bitmap? {
        val w = src.width
        val h = src.height
        if (w < 24 || h < 24 || src.config == Bitmap.Config.HARDWARE) return null
        val step = maxOf(1, maxOf(w, h) / 240)
        fun ink(x: Int, y: Int): Boolean {
            val c = src.getPixel(x, y)
            if ((c ushr 24) < 48) return false
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            return !(r > 236 && g > 236 && b > 236)
        }
        fun rowHasInk(y: Int): Boolean {
            var x = 0
            while (x < w) { if (ink(x, y)) return true; x += step }
            return false
        }
        var top = -1
        var y = 0
        while (y < h) { if (rowHasInk(y)) { top = y; break }; y += step }
        if (top < 0) return null
        val gapNeeded = maxOf(2 * step, h / 60)
        var bottom = top
        var gap = 0
        var parted = false
        y = top
        while (y < h) {
            if (rowHasInk(y)) { bottom = y; gap = 0 } else { gap += step; if (gap >= gapNeeded && bottom - top > h / 8) { parted = true; break } }
            y += step
        }
        // nothing written under it, nothing to separate: show the logo whole
        if (!parted) return null
        var left = w
        var right = -1
        y = top
        while (y <= bottom) {
            var x = 0
            while (x < w) {
                if (ink(x, y)) { if (x < left) left = x; if (x > right) right = x }
                x += step
            }
            y += step
        }
        if (right <= left) return null
        val bw = right - left + step
        val bh = bottom - top + step
        val ratio = bw.toFloat() / bh
        if (ratio < 0.8f || ratio > 1.25f || bh < h / 6) return null
        // a square around it, with a breath of margin, kept inside the picture
        var side = (maxOf(bw, bh) * 1.05f).toInt()
        side = minOf(side, w, h)
        val cx = (left + right) / 2
        val cy = (top + bottom) / 2
        val l = (cx - side / 2).coerceIn(0, w - side)
        val t = (cy - side / 2).coerceIn(0, h - side)
        var out = Bitmap.createBitmap(src, l, t, side, side)
        // brought down in halves: a clean small picture instead of a shimmering one
        while (out.width >= 2 * EMBLEM_PX) out = Bitmap.createScaledBitmap(out, out.width / 2, out.height / 2, true)
        if (out.width > EMBLEM_PX) out = Bitmap.createScaledBitmap(out, EMBLEM_PX, EMBLEM_PX, true)
        return out
    }

    private const val EMBLEM_PX = 192
}
