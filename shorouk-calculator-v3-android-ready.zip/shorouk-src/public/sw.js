/*
 * Service worker — حاسبة رسوم الشروق
 *
 * Strategy
 *  - Page navigations ........ network-first, falls back to the cached index.html
 *  - /assets/* (Vite hashes) .. cache-first, old hashes are pruned once a new version is fully cached
 *  - other same-origin files .. stale-while-revalidate (manifest, icons)
 *  - cross-origin files ....... stale-while-revalidate (Google Fonts, store logo, Tabby / Tamara badges)
 *
 * A new version only replaces the cached one after every file it needs from this site is in the
 * cache, so a connection that drops halfway through an update never leaves a blank offline page.
 * The font (Arabic + Latin subsets), the store logo and the two provider badges are cached on the first visit as well.
 * Bump CACHE_VERSION to force every device to drop its old cache.
 */
const CACHE_VERSION = 'v3';
const CACHE_PREFIX = 'shorouk-fees-';
const CACHE = CACHE_PREFIX + CACHE_VERSION;

const SCOPE = self.registration.scope; // e.g. https://example.netlify.app/
const INDEX_URL = new URL('./index.html', SCOPE).href;
const EXTRA_URLS = [
  './manifest.webmanifest',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png',
  './icons/icon.svg',
].map((p) => new URL(p, SCOPE).href);
// store logo and provider badges (the same URLs the JS bundle uses, see components/Extras.tsx)
const CROSS_ORIGIN_EXTRAS = [
  'https://www2.0zz0.com/2025/04/29/23/183916568.png',
  'https://cdn.salla.sa/BmwbV/Ea1Kx4SfpK2Vy3Lx3aVPvZKBMkSM5dio2eKveTwm.png',
  'https://cdn.tamara.co/assets/png/tamara-logo-badge-en.png',
];
const NAV_TIMEOUT_MS = 4000;

const isSameOrigin = (url) => new URL(url).origin === self.location.origin;
const isCacheable = (res) => res && (res.ok || res.type === 'opaque');

/** Lists the scripts, stylesheets and icons that an HTML document pulls in. */
function assetsFromHtml(html, baseUrl) {
  const urls = new Set();
  for (const tag of html.match(/<(?:script|link)\b[^>]*>/gi) || []) {
    const attr = (name) => (tag.match(new RegExp('\\s' + name + '\\s*=\\s*["\']([^"\']*)["\']', 'i')) || [])[1];
    const rel = (attr('rel') || '').toLowerCase();
    const ref = attr('src') || (/(stylesheet|modulepreload|icon|manifest)/.test(rel) ? attr('href') : null);
    if (!ref) continue;
    try {
      const u = new URL(ref, baseUrl);
      if (u.protocol === 'http:' || u.protocol === 'https:') urls.add(u.href);
    } catch (_) { /* ignore malformed URLs */ }
  }
  return [...urls];
}

/** Same-origin files must arrive intact (throws otherwise); cross-origin ones are stored as they come. */
async function fetchAndStore(cache, url) {
  const same = isSameOrigin(url);
  const req = new Request(url, same ? {} : { mode: 'no-cors' });
  const res = await fetch(req);
  if (same && !res.ok) throw new Error(`${url} → ${res.status}`);
  if (isCacheable(res)) await cache.put(req, res);
}

/**
 * Cross-origin file: a readable copy when the host allows it (Google Fonts does), an opaque one otherwise.
 * For a stylesheet, the Arabic and Latin font files it lists are cached too, so text keeps its font offline.
 */
async function cacheCrossOrigin(cache, url) {
  let res = null;
  try { res = await fetch(url, { mode: 'cors' }); } catch (_) { /* host doesn't allow CORS */ }
  if (!res || !res.ok) { await fetchAndStore(cache, url); return; }
  if (!(res.headers.get('content-type') || '').includes('text/css')) { await cache.put(url, res); return; }
  const css = await res.clone().text();
  await cache.put(url, res);
  const files = css.split('@font-face').slice(1)
    .filter((block) => /unicode-range:[^;]*U\+(0600|0000)/i.test(block))
    .map((block) => (block.match(/url\((['"]?)([^'")]+)\1\)/) || [])[2])
    .filter(Boolean);
  await Promise.all(files.map(async (file) => {
    if (await cache.match(file)) return;
    const font = await fetch(file, { mode: 'cors' });
    if (font.ok) await cache.put(file, font);
  }));
}

/**
 * Brings the cache up to the version described by `html`:
 * 1. every same-origin file it references is cached (any failure aborts and keeps the old version),
 * 2. then its index.html becomes the cached page,
 * 3. fonts and logo are added (best effort),
 * 4. hashed files the new page no longer uses are deleted.
 */
async function syncShell(cache, html, indexResponse) {
  const assets = assetsFromHtml(html, INDEX_URL);
  const required = assets.filter(isSameOrigin);

  for (const url of required) {
    if (!(await cache.match(url))) await fetchAndStore(cache, url);
  }
  if (indexResponse) await cache.put(INDEX_URL, indexResponse);

  await Promise.all(EXTRA_URLS.map(async (url) => {
    try { if (!(await cache.match(url))) await fetchAndStore(cache, url); } catch (_) { /* retried on a later visit */ }
  }));
  const crossOrigin = [...assets.filter((u) => !isSameOrigin(u)), ...CROSS_ORIGIN_EXTRAS];
  await Promise.all(crossOrigin.map(async (url) => {
    try { if (!(await cache.match(url))) await cacheCrossOrigin(cache, url); } catch (_) { /* runtime caching picks it up later */ }
  }));

  const keep = new Set(required);
  for (const key of await cache.keys()) {
    const u = new URL(key.url);
    if (u.origin === self.location.origin && u.pathname.includes('/assets/') && !keep.has(u.href)) {
      await cache.delete(key);
    }
  }
}

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    const res = await fetch(INDEX_URL, { cache: 'reload' });
    if (!res.ok) throw new Error('index.html unavailable: ' + res.status);
    const html = await res.clone().text();
    await syncShell(cache, html, res);   // throws if the app's own files can't be fetched: install retries later
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    for (const name of await caches.keys()) {
      if (name.startsWith(CACHE_PREFIX) && name !== CACHE) await caches.delete(name);
    }
    await self.clients.claim();
  })());
});

// 'no-cache' = always revalidate with the server (cheap 304 when unchanged). Hosts such as GitHub Pages
// send max-age=600, which would otherwise keep a freshly deployed version hidden for up to 10 minutes.
function fetchIndex(timeoutMs) {
  if (!timeoutMs) return fetch(INDEX_URL, { cache: 'no-cache' });
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  return fetch(INDEX_URL, { cache: 'no-cache', signal: ctrl.signal }).finally(() => clearTimeout(timer));
}

// Single-page app: every navigation inside the scope is answered with index.html.
async function handleNavigation(event) {
  const cache = await caches.open(CACHE);
  const cached = await cache.match(INDEX_URL);
  try {
    // with a cached copy to fall back on, don't wait long on a bad connection; without one, wait it out
    const res = await fetchIndex(cached ? NAV_TIMEOUT_MS : 0);
    if (!res.ok) return cached || res;   // a host error page never replaces the app
    const forCache = res.clone();
    const forParse = res.clone();
    event.waitUntil(forParse.text().then((html) => syncShell(cache, html, forCache)).catch(() => {}));
    return res;
  } catch (_) {
    return cached || Response.error();
  }
}

async function cacheFirst(request) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(request);
  if (hit) return hit;
  const res = await fetch(request);
  if (isCacheable(res)) cache.put(request, res.clone());
  return res;
}

async function staleWhileRevalidate(event) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(event.request);
  const refresh = fetch(event.request)
    .then((res) => {
      // keep a readable font stylesheet rather than overwriting it with an opaque copy
      if (isCacheable(res) && !(hit && hit.type === 'cors' && res.type === 'opaque')) cache.put(event.request, res.clone());
      return res;
    })
    .catch(() => null);
  if (hit) { event.waitUntil(refresh); return hit; }
  return (await refresh) || Response.error();
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return;

  if (request.mode === 'navigate') {
    if (url.origin === self.location.origin) event.respondWith(handleNavigation(event));
    return;
  }
  if (url.origin === self.location.origin && url.pathname.includes('/assets/')) {
    event.respondWith(cacheFirst(request));
    return;
  }
  event.respondWith(staleWhileRevalidate(event));
});
