import React, { useLayoutEffect, useRef } from 'react';
import {
    caretAfterSignificant, emWidth, extractAmount, hasAmountChars, normalizeDigits,
    significantBefore, toCanonical, toDisplay,
} from '../lib/amount';
import { IconClose } from './Icons';
import { Glass } from './Glass';

interface AmountFieldProps {
    value: string;                 // canonical number string used by the calculation
    onChange: (next: string) => void;
    label: string;
    hint: string;
    currency: string;
    clearLabel: string;
}

export function AmountField({ value, onChange, label, hint, currency, clearLabel }: AmountFieldProps) {
    const inputRef = useRef<HTMLInputElement>(null);
    const pendingCaret = useRef<number | null>(null);
    const display = toDisplay(value);

    useLayoutEffect(() => {
        const el = inputRef.current;
        if (el && pendingCaret.current !== null && document.activeElement === el) {
            el.setSelectionRange(pendingCaret.current, pendingCaret.current);
        }
        pendingCaret.current = null;
    });

    /** Puts the old text and caret back (the edit is refused). */
    const restore = (el: HTMLInputElement, caret: number, rawLength: number) => {
        const keep = Math.max(0, Math.min(display.length, caret - (rawLength - display.length)));
        el.value = display;
        el.setSelectionRange(keep, keep);
    };

    /** Runs edited field text through the formatter and keeps the caret beside what was typed. */
    const apply = (el: HTMLInputElement, rawText: string, rawCaret: number, inputType: string) => {
        let raw = rawText;
        let caret = rawCaret;
        let next = toCanonical(raw);

        // Backspace / delete on a thousands separator removes the digit beside it instead.
        if (next !== null && next === value && raw.length < display.length) {
            if (inputType === 'deleteContentBackward' && caret > 0) {
                raw = raw.slice(0, caret - 1) + raw.slice(caret);
                caret -= 1;
                next = toCanonical(raw);
            } else if (inputType === 'deleteContentForward') {
                raw = raw.slice(0, caret) + raw.slice(caret + 1);
                next = toCanonical(raw);
            }
        }

        // Refused edit (a second decimal point, too many digits, nothing changed): keep the old text and caret.
        if (next === null || toDisplay(next) === display) {
            restore(el, caret, raw.length);
            return;
        }

        // Count digits before the caret, minus leading zeros the formatter drops ("05" → "5"),
        // plus the zero it adds in front of a bare decimal point (".5" → "0.5").
        let significant = significantBefore(raw, caret);
        const intPart = normalizeDigits(raw).replace(/[^0-9.]/g, '').split('.')[0];
        const droppedZeros = (intPart.match(/^0+(?=\d)/) || [''])[0].length;
        significant -= Math.min(droppedZeros, significant);
        if (next.startsWith('0.') && !/\d/.test(intPart)) significant += 1;

        pendingCaret.current = caretAfterSignificant(toDisplay(next), significant);
        onChange(next);
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const el = e.target;
        const native = e.nativeEvent as InputEvent;
        const inputType = native.inputType ?? '';
        const caret = el.selectionStart ?? el.value.length;
        // letters or symbols typed (even over a selection) never wipe the amount
        if (inputType.startsWith('insert') && native.data != null && !hasAmountChars(native.data)) {
            restore(el, caret, el.value.length);
            return;
        }
        apply(el, el.value, caret, inputType);
    };

    // Pasting "1,500.00 ر.س" or "SAR 2,727.91" takes the amount out of the text.
    const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
        e.preventDefault();
        const el = e.currentTarget;
        const amount = extractAmount(e.clipboardData.getData('text'));
        if (!amount) return;
        const start = el.selectionStart ?? display.length;
        const end = el.selectionEnd ?? display.length;
        apply(el, display.slice(0, start) + amount + display.slice(end), start + amount.length, 'insertFromPaste');
    };

    /** A press anywhere in the field (the number itself is narrow) puts the caret at the end of the amount. */
    const focusAtEnd = (target: EventTarget): boolean => {
        const el = inputRef.current;
        if (!el || target === el || (target as HTMLElement).closest('button')) return false;
        el.focus();
        const end = el.value.length;
        el.setSelectionRange(end, end);
        return true;
    };
    // Mouse: on press, before the browser moves focus away. Touch: on the tap itself, because a phone only
    // opens its keyboard for focus that happens inside a completed tap.
    const onFieldPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
        if (e.pointerType === 'mouse' && focusAtEnd(e.target)) e.preventDefault();
    };
    const onFieldClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (document.activeElement !== inputRef.current) focusAtEnd(e.target);
    };

    const clear = () => {
        onChange('');
        inputRef.current?.focus();
    };

    return (
        <section className="amount">
            <label className="amount__label" htmlFor="amount-input">{label}</label>
            <div
                className="amount__field"
                style={{ '--em': emWidth(display || '0') + 0.1 } as React.CSSProperties}
                onPointerDown={onFieldPointerDown}
                onClick={onFieldClick}
            >
                <span className="amount__value">
                    <span className="amount__mirror" aria-hidden="true">{display || '0'}</span>
                    <input
                        ref={inputRef}
                        id="amount-input"
                        className="amount__input"
                        type="text"
                        inputMode="decimal"
                        enterKeyHint="done"
                        autoComplete="off"
                        autoCorrect="off"
                        spellCheck={false}
                        dir="ltr"
                        placeholder="0"
                        value={display}
                        onChange={handleChange}
                        onPaste={handlePaste}
                        onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }}
                        aria-describedby="amount-hint"
                    />
                </span>
                <span className="amount__currency" aria-hidden="true">{currency}</span>
                <Glass
                    as="button"
                    type="button"
                    variant="clear"
                    className="amount__clear"
                    data-press=""
                    data-show={display !== ''}
                    onClick={clear}
                    aria-label={clearLabel}
                    inert={display === ''}
                    bezel={12}
                    depth={10}
                    blur={2}
                >
                    <IconClose size={15} />
                </Glass>
            </div>
            <p className="amount__hint" id="amount-hint">{hint}</p>
        </section>
    );
}
