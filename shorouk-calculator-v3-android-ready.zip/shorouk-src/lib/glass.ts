import { RefObject, useLayoutEffect } from 'react';

/*
 * Liquid Glass material.
 *
 * Frosted "glassmorphism" only blurs what is behind it. Real glass bends light: at the rounded rim the
 * background is pulled inward and compressed, like looking through the edge of a thick lens. That is done
 * here with an SVG displacement map used as a backdrop filter:
 *
 *   1. For every pixel of the shape, compute its distance to the rounded-rect edge and the edge normal.
 *   2. Inside the bezel, the surface is a convex squircle; Snell's law (n = 1.5) gives how far a ray that
 *      enters there is bent. That distance, along the inward normal, is written into the red / green
 *      channels of the map.
 *   3. feDisplacementMap samples the backdrop through that map, once per colour channel with slightly
 *      different strengths, so the rim splits light into a faint colour fringe like real glass does.
 *   4. The face of the pane is then frosted (blurred) for legibility while the rim stays polished: the
 *      blue channel of the same map says how far inside the rim a pixel is.
 *
 * Chromium (Chrome, Edge, Android WebView) supports SVG filters in backdrop-filter. Elsewhere, or if the
 * device is too slow, the same elements fall back to a plain frosted blur ("frost"), and to opaque
 * surfaces when the system asks for reduced transparency ("solid").
 */

export type GlassQuality = 'full' | 'frost' | 'solid';

const STORAGE_KEY = 'shoroukGlass';
const SVG_NS = 'http://www.w3.org/2000/svg';
const GLASS_IOR = 1.5;

/* ---------- quality ---------- */

let quality: GlassQuality = 'frost';
const listeners = new Set<() => void>();

const readSaved = (): string | null => {
    try { return localStorage.getItem(STORAGE_KEY); } catch { return null; }
};

export function refractionSupported(): boolean {
    if (typeof CSS === 'undefined' || !CSS.supports) return false;
    const ua = navigator.userAgent;
    const chromium = /Chrome\/\d+/.test(ua) && !/CriOS|FxiOS|EdgiOS/.test(ua);
    return chromium && CSS.supports('backdrop-filter', 'url(#a)');
}

function detectQuality(): GlassQuality {
    if (window.matchMedia?.('(prefers-reduced-transparency: reduce)').matches) return 'solid';
    const saved = readSaved();
    if (saved === 'frost' || saved === 'frost-auto') return 'frost';
    return refractionSupported() ? 'full' : 'frost';
}

export function initGlass() {
    quality = detectQuality();
    document.documentElement.dataset.glass = quality;
}

export const getQuality = (): GlassQuality => quality;

/** `by` records who chose: a person's choice is never overridden by the automatic speed check. */
export function setQuality(next: GlassQuality, by: 'user' | 'auto') {
    try {
        if (next === 'frost') localStorage.setItem(STORAGE_KEY, by === 'auto' ? 'frost-auto' : 'frost');
        else if (by === 'user') localStorage.setItem(STORAGE_KEY, 'full');
    } catch { /* private mode */ }
    if (next === 'full' && !refractionSupported()) next = 'frost';
    if (next === quality) return;
    quality = next;
    document.documentElement.dataset.glass = quality;
    listeners.forEach((fn) => fn());
}

export function subscribeQuality(fn: () => void): () => void {
    listeners.add(fn);
    return () => { listeners.delete(fn); };
}

export const qualityChosenByUser = (): boolean => {
    const saved = readSaved();
    return saved === 'full' || saved === 'frost';
};

/* ---------- displacement map ---------- */

/** How far (relative units) a vertical ray is displaced at depth `t` into the bezel: 1 = edge, 0 = flat interior. */
function bend(t: number): number {
    const x = Math.max(0.035, 1 - t);                            // clamp: the very edge would be a vertical wall
    const slope = Math.pow(1 - x, 3) / Math.pow(1 - Math.pow(1 - x, 4), 0.75);   // d/dx of the squircle (1-(1-x)^4)^(1/4)
    const incidence = Math.atan(slope);
    const refraction = Math.asin(Math.min(1, Math.sin(incidence) / GLASS_IOR));
    return Math.tan(incidence - refraction);
}
const BEND_MAX = bend(1);

const smoothstep = (a: number, b: number, v: number): number => {
    const t = Math.max(0, Math.min(1, (v - a) / (b - a)));
    return t * t * (3 - 2 * t);
};

export interface LensSpec {
    width: number;
    height: number;
    radius: number;
    /** Width of the curved rim in px. */
    bezel: number;
    /** Largest displacement in px (at the very edge). */
    depth: number;
    /** Magnification of the whole lens, e.g. 1.06. */
    zoom?: number;
    /** Blur (px) of the face of the pane; the rim stays sharp. 0 = clear glass. */
    frost?: number;
    /** Colour fringing at the rim: relative difference in bending between red and blue. */
    dispersion?: number;
}

/** Red / green carry the displacement, blue says how far inside the rim a pixel is (0 at the rim, 1 on the face). */
function buildMap({ width: w, height: h, radius, bezel, depth, zoom = 1 }: LensSpec): { url: string; scale: number } {
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return { url: '', scale: 0 };
    const image = ctx.createImageData(w, h);
    const data = image.data;
    const hw = w / 2;
    const hh = h / 2;
    const r = Math.min(radius, hw, hh);
    const rim = Math.max(1, Math.min(bezel, r));
    const magnify = zoom > 1 ? 1 - 1 / zoom : 0;
    const maxZoomShift = magnify * Math.max(hw, hh);
    const scale = depth + maxZoomShift;                          // px represented by a channel value of ±1

    for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
            const px = x + 0.5 - hw;
            const py = y + 0.5 - hh;
            // signed distance to the rounded rectangle (negative inside)
            const qx = Math.abs(px) - (hw - r);
            const qy = Math.abs(py) - (hh - r);
            const ox = Math.max(qx, 0);
            const oy = Math.max(qy, 0);
            const outer = Math.hypot(ox, oy);
            const inside = -(outer + Math.min(Math.max(qx, qy), 0) - r);

            let dx = 0;
            let dy = 0;
            if (inside >= 0 && inside < rim) {
                let nx: number;
                let ny: number;
                if (qx > 0 && qy > 0) { nx = (ox / outer) * Math.sign(px); ny = (oy / outer) * Math.sign(py); }
                else if (qx > qy) { nx = Math.sign(px); ny = 0; }
                else { nx = 0; ny = Math.sign(py); }
                const amount = (bend(1 - inside / rim) / BEND_MAX) * depth;
                dx = -nx * amount;                                 // rays bend toward the centre of the glass
                dy = -ny * amount;
            }
            if (magnify) { dx -= px * magnify; dy -= py * magnify; }

            const i = (y * w + x) * 4;
            data[i] = 128 + Math.max(-1, Math.min(1, dx / scale)) * 127;
            data[i + 1] = 128 + Math.max(-1, Math.min(1, dy / scale)) * 127;
            data[i + 2] = smoothstep(rim * 0.3, rim * 1.05, inside) * 255;
            data[i + 3] = 255;
        }
    }
    ctx.putImageData(image, 0, 0);
    return { url: canvas.toDataURL('image/png'), scale };
}

/* ---------- filter registry ---------- */

let defs: SVGDefsElement | null = null;
let sequence = 0;

function getDefs(): SVGDefsElement {
    if (defs && defs.isConnected) return defs;
    const svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('width', '0');
    svg.setAttribute('height', '0');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    svg.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden;pointer-events:none';
    defs = document.createElementNS(SVG_NS, 'defs');
    svg.appendChild(defs);
    document.body.appendChild(svg);
    return defs;
}

interface FilterEntry {
    id: string;
    node: SVGFilterElement;
    /** One displacement per colour channel (or a single one without dispersion), with its share of the strength. */
    passes: { node: SVGFEDisplacementMapElement; factor: number }[];
    scale: number;
    refs: number;
}
const shared = new Map<string, FilterEntry>();

const specKey = (s: LensSpec) =>
    `${s.width}x${s.height}r${Math.round(s.radius)}b${s.bezel}d${s.depth}z${s.zoom ?? 1}f${s.frost ?? 0}c${s.dispersion ?? 0}`;

function make<K extends keyof SVGElementTagNameMap>(tag: K, attrs: Record<string, string | number>): SVGElementTagNameMap[K] {
    const node = document.createElementNS(SVG_NS, tag);
    for (const name in attrs) node.setAttribute(name, String(attrs[name]));
    return node;
}

// keep one colour channel (and full opacity) of an image
const CHANNEL = {
    r: '1 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0',
    g: '0 0 0 0 0  0 1 0 0 0  0 0 0 0 0  0 0 0 1 0',
    b: '0 0 0 0 0  0 0 0 0 0  0 0 1 0 0  0 0 0 1 0',
};
// blue channel of the map → alpha
const FACE_ALPHA = '0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 1 0 0';

function createFilter(spec: LensSpec): FilterEntry {
    const { url, scale } = buildMap(spec);
    const { width, height, frost = 0, dispersion = 0 } = spec;
    const id = `lg${++sequence}`;
    const node = make('filter', {
        id, x: 0, y: 0, width, height,
        filterUnits: 'userSpaceOnUse',
        primitiveUnits: 'userSpaceOnUse',
        'color-interpolation-filters': 'sRGB',                    // the map is data, not colour: no gamma
    });
    node.appendChild(make('feImage', { href: url, x: 0, y: 0, width, height, preserveAspectRatio: 'none', result: 'map' }));

    const passes: FilterEntry['passes'] = [];
    const displace = (factor: number, result: string) => {
        const pass = make('feDisplacementMap', {
            in: 'SourceGraphic', in2: 'map', scale: scale * 2 * factor,
            xChannelSelector: 'R', yChannelSelector: 'G', result,
        });
        passes.push({ node: pass, factor });
        node.appendChild(pass);
    };

    if (dispersion > 0) {
        // red bends least, blue most: three displaced copies, one channel kept from each, added back together
        (['r', 'g', 'b'] as const).forEach((channel, i) => {
            displace(1 + (i - 1) * dispersion, `d${channel}`);
            node.appendChild(make('feColorMatrix', { in: `d${channel}`, type: 'matrix', values: CHANNEL[channel], result: channel }));
        });
        node.appendChild(make('feComposite', { in: 'r', in2: 'g', operator: 'arithmetic', k1: 0, k2: 1, k3: 1, k4: 0, result: 'rg' }));
        node.appendChild(make('feComposite', { in: 'rg', in2: 'b', operator: 'arithmetic', k1: 0, k2: 1, k3: 1, k4: 0, result: 'sharp' }));
    } else {
        displace(1, 'sharp');
    }

    if (frost > 0) {
        node.appendChild(make('feGaussianBlur', { in: 'sharp', stdDeviation: frost, result: 'soft' }));
        node.appendChild(make('feColorMatrix', { in: 'map', type: 'matrix', values: FACE_ALPHA, result: 'face' }));
        node.appendChild(make('feComposite', { in: 'soft', in2: 'face', operator: 'in', result: 'frost' }));
        const merge = make('feMerge', {});
        merge.appendChild(make('feMergeNode', { in: 'sharp' }));
        merge.appendChild(make('feMergeNode', { in: 'frost' }));
        node.appendChild(merge);
    }

    getDefs().appendChild(node);
    return { id, node, passes, scale, refs: 0 };
}

function acquire(spec: LensSpec): { key: string; id: string } {
    const key = specKey(spec);
    let entry = shared.get(key);
    if (!entry) { entry = createFilter(spec); shared.set(key, entry); }
    entry.refs++;
    return { key, id: entry.id };
}

function release(key: string) {
    const entry = shared.get(key);
    if (!entry) return;
    entry.refs--;
    if (entry.refs <= 0) { entry.node.remove(); shared.delete(key); }
}

/** A private filter whose strength can be animated (segmented-control lens, switch thumb). */
export interface Lens { id: string; setStrength(k: number): void; dispose(): void }

export function createLens(spec: LensSpec): Lens {
    const entry = createFilter(spec);
    let last = 1;
    return {
        id: entry.id,
        setStrength(k: number) {
            if (Math.abs(k - last) < 0.01) return;
            last = k;
            for (const pass of entry.passes) pass.node.setAttribute('scale', (entry.scale * 2 * k * pass.factor).toFixed(2));
        },
        dispose() { entry.node.remove(); },
    };
}

/* ---------- React hook ---------- */

export interface GlassOptions {
    bezel?: number;
    depth?: number;
    /** Frost of the face in px (the rim stays polished). */
    blur?: number;
    saturate?: number;
    /** Colour fringing at the rim (0 = none). */
    dispersion?: number;
    /** Set false for large moving surfaces (the sheet): frosted only. */
    refract?: boolean;
}

/** Applies the refracting backdrop to an element and keeps it in sync with its size and the quality setting. */
export function useGlass(ref: RefObject<HTMLElement | null>, options: GlassOptions = {}) {
    const { bezel = 16, depth = 20, blur = 6, saturate = 1.5, dispersion = 0.045, refract = true } = options;

    useLayoutEffect(() => {
        const el = ref.current;
        if (!el) return;
        let currentKey: string | null = null;

        const apply = () => {
            const w = Math.round(el.offsetWidth);
            const h = Math.round(el.offsetHeight);
            if (!refract || getQuality() !== 'full' || w < 8 || h < 8) {
                if (currentKey) { release(currentKey); currentKey = null; }
                el.style.removeProperty('backdrop-filter');
                return;
            }
            const radius = Math.min(parseFloat(getComputedStyle(el).borderTopLeftRadius) || 0, w / 2, h / 2);
            const spec: LensSpec = { width: w, height: h, radius, bezel, depth, frost: blur, dispersion };
            const key = specKey(spec);
            if (key === currentKey) return;
            const next = acquire(spec);
            if (currentKey) release(currentKey);
            currentKey = next.key;
            el.style.setProperty('backdrop-filter', `url(#${next.id}) saturate(${saturate})`);
        };

        apply();
        const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(apply) : null;
        observer?.observe(el);
        const unsubscribe = subscribeQuality(apply);
        return () => {
            observer?.disconnect();
            unsubscribe();
            if (currentKey) release(currentKey);
            el.style.removeProperty('backdrop-filter');
        };
    }, [ref, bezel, depth, blur, saturate, dispersion, refract]);
}
