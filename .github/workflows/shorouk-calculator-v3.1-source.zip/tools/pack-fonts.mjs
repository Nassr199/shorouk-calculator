// Packs the Thmanyah font files into one compressed bundle that ships inside the app.
//
//   node tools/pack-fonts.mjs <Regular.otf> <Bold.otf>
//
// The licence of خط ثمانية allows embedding in a web app only as part of a packaged product, and forbids
// offering the font files themselves for download or modifying them. So the files are not served as
// .otf / .woff: they travel, byte for byte unchanged, inside public/type/thmanyah.pack and are unpacked
// in memory by lib/arabicType.ts. Download the fonts from https://font.thmanyah.com to rebuild the pack.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const [regular, bold] = process.argv.slice(2);
if (!regular || !bold) {
  console.error('usage: node tools/pack-fonts.mjs <Regular.otf> <Bold.otf>');
  process.exit(1);
}
const fonts = [[400, readFileSync(regular)], [700, readFileSync(bold)]];

// "SHF1" · count · (weight uint16, length uint32) per font · the font files one after another
const header = Buffer.alloc(5 + fonts.length * 6);
header.write('SHF1', 0, 'latin1');
header.writeUInt8(fonts.length, 4);
fonts.forEach(([weight, bytes], i) => {
  header.writeUInt16LE(weight, 5 + i * 6);
  header.writeUInt32LE(bytes.length, 7 + i * 6);
});
const out = resolve(dirname(fileURLToPath(import.meta.url)), '../public/type/thmanyah.pack');
mkdirSync(dirname(out), { recursive: true });
const packed = gzipSync(Buffer.concat([header, ...fonts.map(([, bytes]) => bytes)]), { level: 9 });
writeFileSync(out, packed);
console.log(`${out}: ${(packed.length / 1024).toFixed(0)} KB`);
