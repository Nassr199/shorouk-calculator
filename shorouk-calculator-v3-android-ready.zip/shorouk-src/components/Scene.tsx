/*
 * The world behind the glass: the store's name, الشروق (sunrise), over a calm sea.
 *
 * With no amount the scene waits before dawn: the sun is under the horizon and only a faint glow
 * shows. Enter an amount and it rises over the result panel; its rays cross the sky, the thin clouds
 * catch its colour and a road of light runs down the water toward you.
 *
 * Glass needs something to bend. The rays, the clouds, the horizon and above all the ripples on the
 * water are what every pane refracts at its rim.
 *
 * Driven by two CSS variables set on .app: --hz (horizon position in px) and --sun (0 → 1).
 */

const W = 1040;
const CX = W / 2;

/** Small deterministic random generator, so the scene is the same on every visit. */
function seeded(seed: number): () => number {
    let a = seed >>> 0;
    return () => {
        a = (a + 0x6D2B79F5) >>> 0;
        let t = a;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

/* ---------- sun ---------- */

const SUN_H = 620;
const SUN_Y = 520;        // the sun's centre in the svg; the sky's bottom edge is the horizon

function ray(deg: number, reach: number, spread: number): string {
    const a = (deg * Math.PI) / 180;
    const dx = Math.cos(a);
    const dy = -Math.sin(a);
    const nx = -dy;
    const ny = dx;
    const from = 82;
    const at = (r: number, w: number, side: number) =>
        `${(CX + dx * r + nx * w * side).toFixed(1)} ${(SUN_Y + dy * r + ny * w * side).toFixed(1)}`;
    return `M${at(from, 1.4, 1)}L${at(reach, spread, 1)}L${at(reach, spread, -1)}L${at(from, 1.4, -1)}Z`;
}

// long and short rays alternate, like the mark in the store's logo
const RAYS = Array.from({ length: 15 }, (_, i) => {
    const long = i % 2 === 0;
    return ray(6 + i * 12, long ? 480 : 340, long ? 21 : 12);
});

/* ---------- clouds: long, soft bands of early cloud ---------- */

const SKY_H = 440;
interface Oval { x: number; y: number; rx: number; ry: number; o: number }

function cloud(x: number, y: number, w: number, h: number): Oval[] {
    return [
        { x: x + w / 2, y, rx: w / 2, ry: h / 2, o: 1 },
        { x: x + w * 0.42, y: y - h * 0.7, rx: w * 0.27, ry: h * 0.5, o: 0.9 },
        { x: x + w * 0.2, y: y + h * 0.75, rx: w * 0.33, ry: h * 0.42, o: 0.8 },
    ];
}

// placed for a phone (the middle 360–412 px), kept clear of the amount in the centre; the rest fill a wide screen
const CLOUDS: Oval[] = [
    ...cloud(584, 352, 150, 9),
    ...cloud(302, 316, 124, 8),
    ...cloud(620, 232, 112, 7),
    ...cloud(310, 196, 96, 7),
    ...cloud(604, 96, 104, 6),
    ...cloud(326, 62, 86, 6),
    ...cloud(70, 286, 200, 10),
    ...cloud(800, 300, 190, 10),
    ...cloud(150, 140, 150, 8),
    ...cloud(850, 150, 150, 8),
    ...cloud(10, 60, 130, 7),
];

/* ---------- sea: ripples everywhere, and the sun's road of light down the middle ---------- */

const SEA_H = 600;
// The water just under the horizon is far away and smooth. Ripples start where the result pane's rim ends,
// so the rim mirrors the sun's soft reflection rather than a row of thin lines.
const rowY = (i: number) => 36 + i * 4.2 + i * i * 0.5;

function ripples(): Oval[] {
    const random = seeded(7);
    const out: Oval[] = [];
    for (let i = 0; i < 25; i++) {
        const y = rowY(i);
        const fade = Math.max(0, 1 - i / 27);
        const count = 9 - Math.floor(i / 6);
        for (let k = 0; k < count; k++) {
            const rx = (13 + random() * 34) * (1 + i * 0.06);
            out.push({
                x: random() * (W + 80) - 40,
                y: y + (random() - 0.5) * 3,
                rx,
                ry: 0.75 + i * 0.07,
                o: (0.25 + random() * 0.5) * fade,
            });
        }
    }
    return out;
}

function glitter(): Oval[] {
    const random = seeded(23);
    const out: Oval[] = [];
    for (let i = 0; i < 19; i++) {
        const y = rowY(i) - 6;
        const fade = Math.pow(Math.max(0, 1 - i / 20), 1.2);
        // the road: widest under the sun, breaking up as it nears you
        const rx = Math.max(9, (58 - i * 1.8) * (0.5 + random() * 0.6));
        const drift = (random() - 0.5) * (10 + i * 5);
        out.push({ x: CX + drift, y, rx, ry: 1.15 + i * 0.1, o: fade });
        // glints beside the road
        const sides = i < 2 ? 0 : 1 + Math.floor(random() * 2);
        for (let k = 0; k < sides; k++) {
            const side = random() < 0.5 ? -1 : 1;
            out.push({
                x: CX + side * (44 + i * 4.2 + random() * 44),
                y: y + (random() - 0.5) * 4,
                rx: 5 + random() * 12,
                ry: 0.9 + i * 0.08,
                o: fade * (0.35 + random() * 0.35),
            });
        }
    }
    return out;
}

const RIPPLES = ripples();
const GLITTER = glitter();

const ovals = (list: Oval[]) => list.map((s, i) => (
    <ellipse key={i} cx={s.x.toFixed(1)} cy={s.y.toFixed(1)} rx={s.rx.toFixed(1)} ry={s.ry.toFixed(2)} opacity={s.o.toFixed(2)} />
));

export function Scene() {
    return (
        <div className="scene" aria-hidden="true">
            <div className="scene__sky">
                <div className="scene__stars" />
                <div className="scene__dawn" />
                <svg className="scene__clouds" viewBox={`0 0 ${W} ${SKY_H}`} width={W} height={SKY_H} focusable="false">
                    {ovals(CLOUDS)}
                </svg>
                <svg className="scene__sun" viewBox={`0 0 ${W} ${SUN_H}`} width={W} height={SUN_H} focusable="false">
                    <defs>
                        <radialGradient id="scene-glow" cx={CX} cy={SUN_Y} r="330" gradientUnits="userSpaceOnUse">
                            <stop offset="0" className="scene-glow-0" />
                            <stop offset="0.42" className="scene-glow-1" />
                            <stop offset="1" className="scene-glow-2" />
                        </radialGradient>
                        <radialGradient id="scene-ray" cx={CX} cy={SUN_Y} r="480" gradientUnits="userSpaceOnUse">
                            <stop offset="0.16" className="scene-ray-0" />
                            <stop offset="0.6" className="scene-ray-1" />
                            <stop offset="1" className="scene-ray-2" />
                        </radialGradient>
                        <linearGradient id="scene-disc" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0" className="scene-disc-0" />
                            <stop offset="0.5" className="scene-disc-1" />
                            <stop offset="1" className="scene-disc-2" />
                        </linearGradient>
                    </defs>
                    <circle cx={CX} cy={SUN_Y} r="330" fill="url(#scene-glow)" />
                    <g className="scene__rays" fill="url(#scene-ray)">
                        {RAYS.map((d) => <path key={d} d={d} />)}
                    </g>
                    <circle cx={CX} cy={SUN_Y} r="58" fill="url(#scene-disc)" />
                </svg>
            </div>
            <div className="scene__sea">
                <div className="scene__shine" />
                <div className="scene__mirror" />
                <svg className="scene__ripples" viewBox={`0 0 ${W} ${SEA_H}`} width={W} height={SEA_H} focusable="false">
                    {ovals(RIPPLES)}
                </svg>
                <svg className="scene__glitter" viewBox={`0 0 ${W} ${SEA_H}`} width={W} height={SEA_H} focusable="false">
                    {ovals(GLITTER)}
                </svg>
            </div>
            <div className="scene__grain" />
        </div>
    );
}

/** Small version of the store's mark, used if the logo image cannot load. */
export function SunMark() {
    const rays = Array.from({ length: 7 }, (_, i) => 15 + i * 25).map((deg) => {
        const a = (deg * Math.PI) / 180;
        const x1 = 24 + Math.cos(a) * 12;
        const y1 = 31 - Math.sin(a) * 12;
        const x2 = 24 + Math.cos(a) * 19;
        const y2 = 31 - Math.sin(a) * 19;
        return `M${x1.toFixed(1)} ${y1.toFixed(1)}L${x2.toFixed(1)} ${y2.toFixed(1)}`;
    });
    return (
        <svg viewBox="0 0 48 48" aria-hidden="true" focusable="false">
            <rect width="48" height="48" fill="#134448" />
            <path d={rays.join('')} stroke="#E9A41C" strokeWidth="3" strokeLinecap="round" />
            <circle cx="24" cy="31" r="8.5" fill="#E9A41C" />
            <rect y="31" width="48" height="17" fill="#0D3337" />
        </svg>
    );
}
