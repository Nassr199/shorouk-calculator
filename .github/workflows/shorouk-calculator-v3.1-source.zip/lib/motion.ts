/*
 * Spring physics for everything the finger touches.
 *
 * A CSS transition restarts from rest every time its target changes. A spring keeps its velocity,
 * so a drag hands over to the settle without a seam, and typing fast never makes a digit stutter.
 * All springs share one requestAnimationFrame loop and write straight to the DOM (no React render).
 */

export interface SpringConfig {
    stiffness: number;
    damping: number;
    mass?: number;
    /** Distance from the target at which the spring is considered at rest. */
    precision?: number;
}

export interface SpringMove {
    velocity?: number;
    delay?: number;
    config?: Partial<SpringConfig>;
    onRest?: () => void;
}

type Update = (value: number, velocity: number) => void;

const STEP = 1 / 240;            // fixed physics step: stable for stiff springs on any refresh rate
const running = new Set<Spring>();
let frame = 0;
let lastTime = 0;

export const prefersReducedMotion = (): boolean =>
    typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

/* Frame-rate watchdog: while springs run, frame times are sampled; a slow median reports once. */
const SAMPLE_FRAMES = 45;
const SLOW_FRAME_MS = 30;          // median slower than ~33 fps
let slowHandler: (() => void) | null = null;
let frameTimes: number[] = [];

/** Calls `onSlow` once if animations run at a poor frame rate on this device. Returns a cancel function. */
export function watchFrameRate(onSlow: () => void): () => void {
    slowHandler = onSlow;
    frameTimes = [];
    return () => { if (slowHandler === onSlow) slowHandler = null; };
}

function sample(delta: number) {
    if (!slowHandler || delta > 250) return;                      // a long gap is a hidden tab, not a slow frame
    frameTimes.push(delta);
    if (frameTimes.length < SAMPLE_FRAMES) return;
    const median = frameTimes.sort((a, b) => a - b)[SAMPLE_FRAMES >> 1];
    frameTimes = [];
    if (median > SLOW_FRAME_MS) {
        const report = slowHandler;
        slowHandler = null;
        report();
    }
}

function loop(now: number) {
    sample(now - lastTime);
    const elapsed = Math.min(0.05, (now - lastTime) / 1000);
    lastTime = now;
    running.forEach((spring) => spring.advance(elapsed, now));
    frame = running.size ? requestAnimationFrame(loop) : 0;
}

function start(spring: Spring) {
    running.add(spring);
    if (!frame) {
        lastTime = performance.now();
        frame = requestAnimationFrame(loop);
    }
}

export class Spring {
    value: number;
    velocity = 0;
    target: number;
    private config: SpringConfig;
    private startAt = 0;
    private onRest?: () => void;

    constructor(initial: number, config: SpringConfig, private onUpdate: Update) {
        this.value = initial;
        this.target = initial;
        this.config = config;
    }

    /** Animate to a target, keeping the current velocity unless one is given. */
    to(target: number, move: SpringMove = {}) {
        this.target = target;
        if (move.config) this.config = { ...this.config, ...move.config };
        if (move.velocity !== undefined) this.velocity = move.velocity;
        this.onRest = move.onRest;
        if (prefersReducedMotion()) { this.snap(target); return; }
        // a delay only holds back a spring at rest; one already in flight just bends toward the new target
        if (!running.has(this)) this.startAt = move.delay ? performance.now() + move.delay : 0;
        start(this);
    }

    /** Jump to a value with no animation. */
    snap(value: number) {
        running.delete(this);
        this.value = value;
        this.target = value;
        this.velocity = 0;
        this.startAt = 0;
        this.onUpdate(value, 0);
        const done = this.onRest;
        this.onRest = undefined;
        done?.();
    }

    /** Follow the finger: the value is set directly and the velocity is remembered for the release. */
    drag(value: number, velocity = 0) {
        running.delete(this);
        this.onRest = undefined;
        this.value = value;
        this.target = value;
        this.velocity = velocity;
        this.onUpdate(value, velocity);
    }

    advance(elapsed: number, now: number) {
        if (this.startAt) {
            if (now < this.startAt) return;
            this.startAt = 0;
        }
        const { stiffness, damping, mass = 1, precision = 0.001 } = this.config;
        let remaining = elapsed;
        while (remaining > 1e-6) {
            const h = Math.min(STEP, remaining);
            remaining -= h;
            const acceleration = (-stiffness * (this.value - this.target) - damping * this.velocity) / mass;
            this.velocity += acceleration * h;
            this.value += this.velocity * h;
        }
        if (Math.abs(this.velocity) < precision * 20 && Math.abs(this.value - this.target) < precision) {
            this.snap(this.target);
        } else {
            this.onUpdate(this.value, this.velocity);
        }
    }

    get moving(): boolean { return running.has(this); }

    dispose() {
        running.delete(this);
        this.onRest = undefined;
    }
}

/** Pointer velocity over the last ~100 ms, in px per second. */
export class VelocityTracker {
    private samples: { t: number; x: number }[] = [];

    add(x: number, t = performance.now()) {
        this.samples.push({ t, x });
        while (this.samples.length > 2 && t - this.samples[0].t > 100) this.samples.shift();
    }

    get(): number {
        const n = this.samples.length;
        if (n < 2) return 0;
        const first = this.samples[0];
        const last = this.samples[n - 1];
        const dt = last.t - first.t;
        if (dt <= 0 || performance.now() - last.t > 120) return 0;   // finger paused before lifting
        return ((last.x - first.x) / dt) * 1000;
    }

    reset() { this.samples = []; }
}

/** iOS-style resistance when dragging past a limit: the further you pull, the less it moves. */
export function rubberBand(overshoot: number, dimension: number, coefficient = 0.55): number {
    const sign = overshoot < 0 ? -1 : 1;
    const d = Math.abs(overshoot);
    return sign * (d * dimension * coefficient) / (dimension + coefficient * d);
}

export const clamp = (v: number, lo: number, hi: number): number => Math.min(hi, Math.max(lo, v));
