package sa.alshorouk.calculator.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import sa.alshorouk.calculator.core.Language
import sa.alshorouk.calculator.core.Provider
import sa.alshorouk.calculator.core.Strings
import sa.alshorouk.calculator.core.calculate
import sa.alshorouk.calculator.core.clipboardValue
import sa.alshorouk.calculator.core.fill
import sa.alshorouk.calculator.core.formatMoney
import sa.alshorouk.calculator.core.shareMessage
import sa.alshorouk.calculator.platform.Actions
import sa.alshorouk.calculator.platform.Haptics
import sa.alshorouk.calculator.platform.Prefs
import sa.alshorouk.calculator.platform.ReceiptPrinter
import sa.alshorouk.calculator.ui.components.AmountField
import sa.alshorouk.calculator.ui.components.DetailsSheet
import sa.alshorouk.calculator.ui.components.Dock
import sa.alshorouk.calculator.ui.components.LensSegmented
import sa.alshorouk.calculator.ui.components.ProviderMark
import sa.alshorouk.calculator.ui.components.ResultSlab
import sa.alshorouk.calculator.ui.components.SettlementRow
import sa.alshorouk.calculator.ui.components.SheetMotion
import sa.alshorouk.calculator.ui.components.Toast
import sa.alshorouk.calculator.ui.components.TopBar
import sa.alshorouk.calculator.ui.glass.Backdrop
import sa.alshorouk.calculator.ui.glass.GlassEnv
import sa.alshorouk.calculator.ui.glass.GlassQuality
import sa.alshorouk.calculator.ui.glass.GlassSettings
import sa.alshorouk.calculator.ui.glass.LocalGlass
import sa.alshorouk.calculator.ui.glass.rememberTiltLight
import sa.alshorouk.calculator.ui.motion.Springs
import sa.alshorouk.calculator.ui.motion.animationsDisabled
import sa.alshorouk.calculator.ui.scene.Scene
import sa.alshorouk.calculator.ui.theme.AppType
import sa.alshorouk.calculator.ui.theme.ArabicType
import sa.alshorouk.calculator.ui.theme.DarkPalette
import sa.alshorouk.calculator.ui.theme.LightPalette
import java.util.Calendar
import kotlin.math.hypot
import kotlin.math.max

/** The horizon runs just inside the top edge of the result pane: the sun rises over it (App.tsx). */
private val HORIZON_INSET = 6.dp

@Immutable
private data class Transition(val image: ImageBitmap, val origin: Offset?, val circle: Boolean)

@Composable
fun CalculatorApp(glass: GlassSettings, onDarkChanged: (Boolean) -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    val prefs = remember { Prefs(context) }
    val scope = rememberCoroutineScope()
    val motion = remember { !animationsDisabled(context) }
    val haptics = remember(view) { Haptics(view) }

    // ---- preferences: until a theme is chosen, follow the phone ----
    val systemDark = isSystemInDarkTheme()
    var themeChoice by remember { mutableStateOf(prefs.theme) }
    var lang by remember { mutableStateOf(if (prefs.lang == "en") Language.En else Language.Ar) }
    val dark = when (themeChoice) { "dark" -> true; "light" -> false; else -> systemDark }
    LaunchedEffect(dark) { onDarkChanged(dark) }
    val palette = if (dark) DarkPalette else LightPalette
    val s = Strings.of(lang)

    val arabicFamily by produceState<FontFamily?>(null) { value = ArabicType.load(context) }
    val type = remember(lang, arabicFamily) {
        val arabic = lang == Language.Ar && arabicFamily != null
        AppType(if (arabic) arabicFamily!! else FontFamily.Default, FontFamily.Default, arabic)
    }

    // ---- state (as in the first version) ----
    var price by rememberSaveable { mutableStateOf("") }
    var providerName by rememberSaveable { mutableStateOf(Provider.Tabby.name) }
    val provider = Provider.valueOf(providerName)
    var include by rememberSaveable { mutableStateOf(false) }
    val result = remember(price, provider, include, lang) { calculate(price, provider, include, s) }
    val hasAmount = result.hasAmount

    // ---- the scene: horizon behind the result pane, sun up while there is an amount ----
    val backdrop = remember { Backdrop() }
    val sun = remember { Animatable(0f) }
    LaunchedEffect(hasAmount) {
        val target = if (hasAmount) 1f else 0f
        if (motion) sun.animateTo(target, if (hasAmount) Springs.Sunrise.float else Springs.Sunset.float) else sun.snapTo(target)
    }
    var horizon by remember { mutableFloatStateOf(0f) }
    var sunX by remember { mutableFloatStateOf(0f) }        // the sun rises behind the result pane, wherever that is
    val density = LocalDensity.current
    val slabAt = remember { arrayOfNulls<LayoutCoordinates>(1) }
    val measureHorizon = {
        val scene = backdrop.coordinates
        val slab = slabAt[0]
        if (scene != null && slab != null && scene.isAttached && slab.isAttached) {
            val y = scene.localPositionOf(slab, Offset.Zero).y + with(density) { HORIZON_INSET.toPx() }
            if (kotlin.math.abs(y - horizon) > 0.5f) horizon = y
            val x = scene.localPositionOf(slab, Offset(slab.size.width / 2f, 0f)).x - scene.size.width / 2f
            if (kotlin.math.abs(x - sunX) > 0.5f) sunX = x
        }
    }
    backdrop.onPlaced = measureHorizon
    val placeHorizon: (LayoutCoordinates) -> Unit = { slabAt[0] = it; measureHorizon() }

    val tilt = rememberTiltLight(enabled = motion && glass.quality != GlassQuality.Solid)
    val env = remember(glass, backdrop, tilt, palette) { GlassEnv(glass, backdrop, tilt, palette) }

    // ---- copy, toast, announcements ----
    var copied by remember { mutableStateOf(false) }
    var toastText by remember { mutableStateOf("") }
    var toastShow by remember { mutableStateOf(false) }
    var toastOk by remember { mutableStateOf(true) }
    var announcement by remember { mutableStateOf("") }
    var timers by remember { mutableStateOf<Job?>(null) }
    LaunchedEffect(result.x) { copied = false }
    LaunchedEffect(result.x, hasAmount, lang) {
        if (!hasAmount) { announcement = ""; return@LaunchedEffect }
        delay(900)       // screen readers hear the result once typing pauses, not on every keystroke
        announcement = "${s.resultLabel}: ${formatMoney(result.x)} ${s.currency}"
    }
    val copyAmount = {
        if (hasAmount) {
            val ok = Actions.copy(context, clipboardValue(result), s.copyAmount)
            val message = if (ok) fill(s.copiedToast, mapOf("X" to "${formatMoney(result.x)} ${s.currency}")) else s.copyFailed
            if (ok) haptics.confirm() else haptics.reject()
            timers?.cancel()
            copied = ok
            toastText = message; toastOk = ok; toastShow = true
            announcement = message
            timers = scope.launch {
                launch { delay(1800); copied = false }
                delay(2200); toastShow = false
                delay(500); toastText = ""
            }
        }
    }

    // ---- details sheet ----
    var sheetOpen by rememberSaveable { mutableStateOf(false) }
    val sheet = remember { SheetMotion() }

    // ---- theme and language transitions: the old frame is held over the new one and taken away ----
    val rootLayer = rememberGraphicsLayer()
    var transition by remember { mutableStateOf<Transition?>(null) }
    val reveal = remember { Animatable(0f) }
    fun runTransition(origin: Offset?, circle: Boolean, commit: () -> Unit) {
        if (!motion || transition != null) { commit(); return }
        scope.launch {
            val shot = runCatching { rootLayer.toImageBitmap() }.getOrNull()
            if (shot == null) { commit(); return@launch }
            transition = Transition(shot, origin, circle)
            reveal.snapTo(0f)
            commit()
            if (circle) reveal.animateTo(1f, tween(720, easing = CubicBezierEasing(0.65f, 0f, 0.35f, 1f)))
            else reveal.animateTo(1f, tween(320))
            transition = null
        }
    }
    val toggleTheme: (Offset) -> Unit = { origin ->
        runTransition(origin, circle = true) {
            val next = if (dark) "light" else "dark"
            prefs.theme = next
            themeChoice = next
        }
    }
    val toggleLang: () -> Unit = {
        runTransition(null, circle = false) {
            val next = if (lang == Language.Ar) Language.En else Language.Ar
            prefs.lang = if (next == Language.En) "en" else "ar"
            lang = next
        }
    }

    CompositionLocalProvider(
        LocalPalette provides palette,
        LocalStrings provides s,
        LocalType provides type,
        LocalMotion provides motion,
        LocalHaptics provides haptics,
        LocalGlass provides env,
        LocalLayoutDirection provides if (lang == Language.Ar) LayoutDirection.Rtl else LayoutDirection.Ltr,
    ) {
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .background(palette.sea2)
                .drawWithContent {
                    rootLayer.record { this@drawWithContent.drawContent() }
                    drawLayer(rootLayer)
                },
        ) {
            // ---- which shape of window is this? ----
            // wide: a tablet or foldable held sideways, a desktop window, a phone on its side
            val wide = maxWidth >= 700.dp && maxWidth > maxHeight
            val short = maxHeight < 640.dp
            val narrow = maxWidth < 350.dp
            val screenH = maxHeight
            val column = if (wide) 1000.dp else if (maxWidth >= 600.dp) 520.dp else 460.dp
            val rail = 84.dp + 16.dp + 12.dp          // the action rail and the air around it

            val amountField: @Composable (Modifier) -> Unit = { m ->
                AmountField(
                    value = price, onChange = { price = it },
                    label = s.amountLabel, hint = s.amountHint, showHint = !short,
                    currency = s.currency, clearLabel = s.clear,
                    minHeight = if (short) 60.dp else 66.dp,
                    topPadding = if (short) 10.dp else 18.dp,
                    modifier = m,
                )
            }
            val slab: @Composable (Modifier) -> Unit = { m ->
                ResultSlab(result = result, sun = { sun.value }, onCopy = copyAmount, onPlaced = { }, compact = short, modifier = m)
            }
            val providers: @Composable (Modifier) -> Unit = { m ->
                LensSegmented(
                    options = Provider.entries.toList(),
                    selected = provider,
                    onSelect = { providerName = it.name },
                    label = { if (it == Provider.Tabby) s.tabby else s.tamara },
                    modifier = m.semantics { contentDescription = s.providerLabel },
                ) { option, _ -> ProviderMark(option, lang, palette.ink) }
            }
            val settlement: @Composable (Modifier) -> Unit = { m ->
                SettlementRow(result = result, include = include, provider = provider, onChange = { include = it; haptics.toggle(it) }, modifier = m)
            }
            val slabGap = if (short) (if (wide) 34.dp else 46.dp) else (screenH * 0.094f).coerceIn(60.dp, 94.dp)

            // ---- the page: it recedes behind the sheet ----
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val p = sheet.progress()
                        val k = 1f - p * 0.055f
                        scaleX = k; scaleY = k
                        transformOrigin = TransformOrigin(0.5f, 0.42f)
                        clip = p > 0.002f
                        shape = RoundedCornerShape(34.dp)
                        // While it recedes the page is one finished picture that the GPU only scales:
                        // none of its text or glass is drawn again for the frames of the sheet's movement.
                        compositingStrategy = if (p > 0.002f) CompositingStrategy.Offscreen else CompositingStrategy.Auto
                    }
                    .then(if (sheetOpen) Modifier.clearAndSetSemantics { } else Modifier),
            ) {
                Scene(
                    palette = palette,
                    sun = { sun.value },
                    horizon = { horizon },
                    sunSize = if (short) 0.74f else 1f,
                    backdrop = backdrop,
                    modifier = Modifier.introFade(motion),
                    sunX = { sunX },
                )

                Column(
                    Modifier
                        .fillMaxSize()
                        .imePadding()
                        .verticalScroll(rememberScrollState())
                        .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal))
                        .padding(top = if (short) 8.dp else 12.dp, bottom = if (wide) 20.dp else 100.dp)
                        .windowInsetsPadding(WindowInsets.navigationBars.only(WindowInsetsSides.Bottom))
                        .align(Alignment.TopCenter),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Column(
                        Modifier
                            .widthIn(max = column)
                            .fillMaxWidth()
                            .padding(
                                start = if (wide) 20.dp else if (narrow) 12.dp else 16.dp,
                                end = if (wide) rail + 8.dp else if (narrow) 12.dp else 16.dp,
                            ),
                    ) {
                        TopBar(
                            dark = dark,
                            compactName = narrow,
                            onToggleTheme = toggleTheme,
                            onToggleLang = toggleLang,
                            modifier = Modifier.intro(motion, 0, drop = true),
                        )

                        if (wide) {
                            // two columns: the amount and what to charge on one side, the choices beside the result
                            Spacer(Modifier.height(if (short) 0.dp else ((screenH - 560.dp) / 2).coerceIn(0.dp, 80.dp)))
                            Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.Bottom) {
                                Column(Modifier.weight(1.12f)) {
                                    amountField(Modifier.intro(motion, 2))
                                    Spacer(Modifier.height(slabGap))
                                    slab(Modifier.onGloballyPositioned(placeHorizon).intro(motion, 3))
                                }
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    providers(Modifier.intro(motion, 4))
                                    settlement(Modifier.intro(motion, 5))
                                }
                            }
                        } else {
                            // the stack sits a little lower on tall screens (.stack::before, at most 96 dp)
                            Spacer(Modifier.height(((screenH - 720.dp) / 2).coerceIn(0.dp, 96.dp)))
                            amountField(Modifier.intro(motion, 2))
                            Spacer(Modifier.height(slabGap))
                            slab(Modifier.onGloballyPositioned(placeHorizon).intro(motion, 3))
                            Spacer(Modifier.height(12.dp))
                            providers(Modifier.intro(motion, 4))
                            Spacer(Modifier.height(12.dp))
                            settlement(Modifier.intro(motion, 5))
                        }

                        if (!short) {
                            BasicText(
                                s.footer(Calendar.getInstance().get(Calendar.YEAR)),
                                style = type.tiny.copy(color = palette.ink2, textAlign = TextAlign.Center),
                                modifier = Modifier.fillMaxWidth().padding(top = 28.dp).intro(motion, 6),
                            )
                        }
                    }
                }
            }

            // ---- the floating layer ----
            Toast(
                text = toastText, show = toastShow, ok = toastOk,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .windowInsetsPadding(WindowInsets.navigationBars.union(WindowInsets.ime))
                    .padding(bottom = if (wide) 24.dp else 92.dp),
            )
            // the actions: a bar along the bottom on a phone, a rail on the trailing edge when the window is wide
            Dock(
                ready = hasAmount,
                copied = copied,
                hidden = sheetOpen,
                vertical = wide,
                onCopy = copyAmount,
                onShare = { Actions.shareWhatsApp(context, shareMessage(s, result)) },
                onPrint = { ReceiptPrinter.print(context, s, result) },
                onDetails = { bounds -> sheet.origin = bounds; sheetOpen = true },
                modifier = if (wide) Modifier
                    .align(Alignment.CenterEnd)
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(end = 16.dp, top = 8.dp, bottom = 8.dp)
                    .intro(motion, 6, dock = true)
                else Modifier
                    .align(Alignment.BottomCenter)
                    .windowInsetsPadding(WindowInsets.navigationBars.union(WindowInsets.ime))
                    .padding(bottom = 12.dp)
                    .widthIn(max = column)
                    .intro(motion, 6, dock = true),
            )
            DetailsSheet(open = sheetOpen, motion = sheet, result = result, glass = glass, onClose = { sheetOpen = false }, side = wide)

            // what screen readers hear (the toast and the result, once typing pauses)
            Box(
                Modifier
                    .size(1.dp)
                    .semantics {
                        liveRegion = LiveRegionMode.Polite
                        contentDescription = announcement
                    },
            )

            // the frame from before a theme / language switch, taken away by a growing circle or a fade
            transition?.let { t ->
                Canvas(Modifier.fillMaxSize()) {
                    val r = reveal.value
                    if (t.circle) {
                        val o = t.origin ?: Offset(size.width / 2, 0f)
                        val far = hypot(max(o.x, size.width - o.x), max(o.y, size.height - o.y))
                        val hole = Path().apply { addOval(androidx.compose.ui.geometry.Rect(o, far * r)) }
                        clipPath(hole, ClipOp.Difference) { drawImage(t.image) }
                    } else {
                        drawImage(t.image, alpha = 1f - r)
                    }
                }
            }
        }
    }
}

/* ---- the entrance: plays once when the app opens (styles.css, :root[data-intro]) ---- */

@Composable
private fun Modifier.intro(motion: Boolean, order: Int, drop: Boolean = false, dock: Boolean = false): Modifier {
    val move = remember { Animatable(if (motion) 0f else 1f) }
    val fade = remember { Animatable(if (motion) 0f else 1f) }
    val backdrop = LocalGlass.current.backdrop
    LaunchedEffect(Unit) {
        if (move.value >= 1f) return@LaunchedEffect
        delay(if (order == 2) 200L else order * 70L + 60L)
        launch { fade.animateTo(1f, tween(if (dock) 1 else 460)) }
        // A pane carried by this transform must be shown what is behind it where it is now, frame by frame,
        // so its rim and frost stay registered with the scene all the way to rest.
        move.animateTo(1f, if (dock) Springs.Gentle.float else Springs.Spring.float) { backdrop.epoch++ }
        backdrop.epoch++
    }
    return this.graphicsLayer {
        val t = move.value
        val dy = when { dock -> 120f; drop -> -26f; else -> 30f }
        translationY = (1f - t) * dy * density
        if (!dock) { val k = 0.94f + 0.06f * t; scaleX = k; scaleY = k }
        alpha = fade.value.coerceIn(0f, 1f)
    }
}

@Composable
private fun Modifier.introFade(motion: Boolean): Modifier {
    val fade = remember { Animatable(if (motion) 0f else 1f) }
    LaunchedEffect(Unit) { if (fade.value < 1f) fade.animateTo(1f, tween(900)) }
    return this.graphicsLayer { alpha = fade.value }
}
