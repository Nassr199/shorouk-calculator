import React, { forwardRef, useEffect, useImperativeHandle, useLayoutEffect, useRef } from 'react';
import { Spring, VelocityTracker, clamp } from '../lib/motion';
import { Lens, createLens, getQuality, subscribeQuality } from '../lib/glass';

/*
 * The visual part of a switch (the control that owns role="switch" wraps it).
 *
 * At rest the thumb is a solid white pill. Under the finger it swells into a drop of clear glass that
 * magnifies the track beneath it, can be dragged across, and settles on a spring. The track colour
 * follows the thumb's position continuously, so a half-way drag shows a half-way colour.
 */

export interface LiquidSwitchHandle {
    /** True if the last pointer gesture was a drag (the wrapper should ignore the click that follows). */
    consumeDrag(): boolean;
}

interface LiquidSwitchProps {
    checked: boolean;
    /** Called when a drag ends on the other side. Taps are left to the wrapper's click. */
    onDragToggle: (next: boolean) => void;
}

const THUMB = { stiffness: 480, damping: 30, precision: 0.001 };
const LIFT = { stiffness: 460, damping: 26, precision: 0.002 };
const DRAG_SLOP = 3;

export const LiquidSwitch = forwardRef<LiquidSwitchHandle, LiquidSwitchProps>(function LiquidSwitch({ checked, onDragToggle }, ref) {
    const root = useRef<HTMLSpanElement>(null);
    const thumb = useRef<HTMLSpanElement>(null);
    const lensEl = useRef<HTMLSpanElement>(null);
    const live = useRef({
        pos: null as Spring | null, lift: null as Spring | null, lens: null as Lens | null,
        travel: 18, pointer: -1, startX: 0, startPos: 0, dragging: false, draggedAt: -1e9,
        tracker: new VelocityTracker(), checked,
    });
    live.current.checked = checked;
    const callback = useRef(onDragToggle);
    callback.current = onDragToggle;

    useImperativeHandle(ref, () => ({
        consumeDrag() {
            const recent = performance.now() - live.current.draggedAt < 500;
            live.current.draggedAt = -1e9;
            return recent;
        },
    }), []);

    const paint = () => {
        const s = live.current;
        const el = root.current;
        const t = thumb.current;
        const l = lensEl.current;
        if (!el || !t || !l || !s.pos || !s.lift) return;
        const dir = document.documentElement.dir === 'rtl' ? -1 : 1;
        const p = s.pos.value;
        const lift = s.lift.value;
        const stretch = Math.min(Math.abs(s.pos.velocity) * 0.045, 0.28);
        const sx = 1 + stretch + lift * 0.28;
        const sy = 1 - stretch * 0.2 + lift * 0.34;
        const transform = `translate3d(${(p * s.travel * dir).toFixed(2)}px, 0, 0) scale(${sx.toFixed(4)}, ${sy.toFixed(4)})`;
        t.style.transform = transform;
        l.style.transform = transform;
        el.style.setProperty('--p', clamp(p, 0, 1).toFixed(3));
        el.style.setProperty('--lift', lift.toFixed(3));
        s.lens?.setStrength(0.4 + lift * 1.4);
    };

    useLayoutEffect(() => {
        const s = live.current;
        const el = root.current;
        const t = thumb.current;
        if (!el || !t) return;
        const pad = parseFloat(getComputedStyle(el).getPropertyValue('--pad')) || 3;
        s.travel = el.offsetWidth - t.offsetWidth - 2 * pad;
        s.pos = new Spring(s.checked ? 1 : 0, THUMB, paint);
        s.lift = new Spring(0, LIFT, paint);

        const buildLens = () => {
            s.lens?.dispose();
            s.lens = null;
            const node = lensEl.current;
            if (!node) return;
            if (getQuality() !== 'full') { node.style.removeProperty('backdrop-filter'); return; }
            const w = t.offsetWidth;
            const h = t.offsetHeight;
            s.lens = createLens({ width: w, height: h, radius: h / 2, bezel: h / 2, depth: 7, zoom: 1.12, dispersion: 0.07 });
            node.style.setProperty('backdrop-filter', `url(#${s.lens.id})`);
        };
        buildLens();
        paint();
        const unsubscribe = subscribeQuality(buildLens);
        // the page direction flips the travel direction
        const observer = new MutationObserver(paint);
        observer.observe(document.documentElement, { attributes: true, attributeFilter: ['dir'] });
        return () => { unsubscribe(); observer.disconnect(); s.pos?.dispose(); s.lift?.dispose(); s.lens?.dispose(); s.lens = null; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        const s = live.current;
        if (!s.pos || s.dragging) return;
        const target = checked ? 1 : 0;
        if (s.pos.target !== target) s.pos.to(target);
    }, [checked]);

    const onPointerDown = (e: React.PointerEvent<HTMLSpanElement>) => {
        const s = live.current;
        if (e.button !== 0 || !s.pos || !s.lift) return;
        s.pointer = e.pointerId;
        s.startX = e.clientX;
        s.startPos = s.pos.value;
        s.dragging = false;
        s.draggedAt = -1e9;
        s.tracker.reset();
        s.tracker.add(e.clientX);
        e.currentTarget.setPointerCapture(e.pointerId);
        s.lift.to(1);
    };

    const onPointerMove = (e: React.PointerEvent<HTMLSpanElement>) => {
        const s = live.current;
        if (e.pointerId !== s.pointer || !s.pos) return;
        s.tracker.add(e.clientX);
        const dx = e.clientX - s.startX;
        if (!s.dragging) {
            if (Math.abs(dx) < DRAG_SLOP) return;
            s.dragging = true;
        }
        const dir = document.documentElement.dir === 'rtl' ? -1 : 1;
        const raw = s.startPos + (dx * dir) / s.travel;
        // a little give past either end
        const p = raw < 0 ? raw * 0.25 : raw > 1 ? 1 + (raw - 1) * 0.25 : raw;
        s.pos.drag(clamp(p, -0.25, 1.25), (s.tracker.get() * dir) / s.travel);
    };

    const finish = (e: React.PointerEvent<HTMLSpanElement>, cancelled: boolean) => {
        const s = live.current;
        if (e.pointerId !== s.pointer || !s.pos || !s.lift) return;
        s.pointer = -1;
        if (e.currentTarget.hasPointerCapture(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
        s.lift.to(0);
        if (!s.dragging) return;                                  // a tap: the wrapper's click toggles
        s.dragging = false;
        if (!cancelled) s.draggedAt = performance.now();          // the click that follows this release is not a tap
        const dir = document.documentElement.dir === 'rtl' ? -1 : 1;
        const velocity = (s.tracker.get() * dir) / s.travel;
        const next = cancelled ? s.checked : s.pos.value + velocity * 0.08 > 0.5;
        s.pos.to(next ? 1 : 0, { velocity });
        if (next !== s.checked) callback.current(next);
    };

    return (
        <span
            ref={root}
            className="switch"
            aria-hidden="true"
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={(e) => finish(e, false)}
            onPointerCancel={(e) => finish(e, true)}
        >
            <span className="switch__track"><span className="switch__on" /></span>
            <span className="switch__thumb" ref={thumb} />
            <span className="switch__lens" ref={lensEl} />
        </span>
    );
});
