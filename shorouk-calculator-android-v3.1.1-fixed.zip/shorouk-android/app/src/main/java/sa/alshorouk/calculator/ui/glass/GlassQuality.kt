package sa.alshorouk.calculator.ui.glass

import android.app.Activity
import android.content.Context
import android.os.Build
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/*
 * Three grades of the same material (lib/glass.ts):
 *  Full  — frosted face + refracting rim with colour dispersion (Android 13+, AGSL)
 *  Frost — frosted face only (Android 12+, RenderEffect blur)
 *  Solid — opaque surfaces: Android 8–11, or when chosen
 *
 * The grade is the best the Android version can draw, always: nothing lowers it behind the person's back
 * (no frame-rate watchdog, no battery-saver or low-RAM step down). Only the switch in the details sheet does.
 */
enum class GlassQuality { Full, Frost, Solid }

@Stable
class GlassSettings(context: Context) {
    private val prefs = context.getSharedPreferences("glass", Context.MODE_PRIVATE)
    val canRefract: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
    val canBlur: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    var chosenByUser: Boolean = prefs.getBoolean(KEY_USER, false)
        private set

    var quality: GlassQuality by mutableStateOf(initial(context))
        private set

    private fun initial(context: Context): GlassQuality {
        val best = when {
            canRefract -> GlassQuality.Full
            canBlur -> GlassQuality.Frost
            else -> GlassQuality.Solid
        }
        if (chosenByUser) {
            val saved = runCatching { GlassQuality.valueOf(prefs.getString(KEY_Q, best.name)!!) }.getOrDefault(best)
            return clampTo(saved, best)
        }
        return best
    }

    private fun clampTo(q: GlassQuality, best: GlassQuality) = if (q.ordinal < best.ordinal) best else q

    fun set(q: GlassQuality, byUser: Boolean) {
        val best = if (canRefract) GlassQuality.Full else if (canBlur) GlassQuality.Frost else GlassQuality.Solid
        quality = clampTo(q, best)
        if (byUser) {
            chosenByUser = true
            prefs.edit().putBoolean(KEY_USER, true).putString(KEY_Q, quality.name).apply()
        }
    }

    private companion object {
        const val KEY_USER = "chosen"
        const val KEY_Q = "quality"
    }
}

fun Activity.displayRefreshRate(): Float =
    runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display?.refreshRate ?: 60f
        else @Suppress("DEPRECATION") windowManager.defaultDisplay.refreshRate
    }.getOrDefault(60f)
