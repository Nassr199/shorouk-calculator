package sa.alshorouk.calculator.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import sa.alshorouk.calculator.ui.LocalPalette
import sa.alshorouk.calculator.ui.LocalStrings
import sa.alshorouk.calculator.ui.LocalType
import sa.alshorouk.calculator.ui.glass.GlassSpec
import sa.alshorouk.calculator.ui.glass.GlassSurface
import sa.alshorouk.calculator.ui.glass.GlassVariant
import sa.alshorouk.calculator.ui.glass.PressFx
import sa.alshorouk.calculator.ui.glass.rememberPressFx
import sa.alshorouk.calculator.ui.motion.Springs

/* The floating layer (components/Chrome.tsx): brand and view controls at the top, actions in the dock. */

@Composable
fun TopBar(
    dark: Boolean,
    compactName: Boolean,
    onToggleTheme: (Offset) -> Unit,
    /** Receives the centre of the language control in the root: the new language spreads out from there. */
    onToggleLang: (Offset) -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val s = LocalStrings.current
    val type = LocalType.current
    val pageDirection = LocalLayoutDirection.current
    // The caller's own spacing (the side the action rail is on, the screen's margins) belongs to the page
    // and is resolved in the page's direction — so it is applied here, outside the bar's fixed arrangement.
    Box(modifier.fillMaxWidth()) {
        // The bar keeps one arrangement in both languages (the store's mark on the right, the controls on the
        // left): switching language changes what the page says, it must not make the bar jump across the screen.
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                GlassSurface(
                    Modifier.weight(1f, fill = false).height(46.dp),
                    radius = 23.dp, variant = GlassVariant.Clear,
                    spec = GlassSpec(bezel = 15.dp, depth = 15.dp, blur = 2.dp),
                ) {
                    // Inside its pill the name reads the way its language does: the mark first, then the
                    // name — on the right in Arabic, on the left in English.
                    CompositionLocalProvider(LocalLayoutDirection provides pageDirection) {
                        Row(Modifier.fillMaxHeight().padding(start = 6.dp, end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            StoreLogoTile()
                            Spacer(Modifier.width(9.dp))
                            BrandName(
                                full = s.appName, short = s.appNameShort,
                                style = type.brand.copy(color = p.ink).let { if (compactName) it.copy(fontSize = it.fontSize * 0.93f) else it },
                                modifier = Modifier.semantics { heading(); contentDescription = s.appName },
                            )
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                GlassSurface(
                    Modifier.height(46.dp),
                    radius = 23.dp, variant = GlassVariant.Clear,
                    spec = GlassSpec(bezel = 15.dp, depth = 15.dp, blur = 2.dp),
                ) {
                    Row(Modifier.fillMaxHeight().padding(4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        LanguageLens(lang = s.lang, onToggle = onToggleLang, modifier = Modifier.semantics { contentDescription = s.langButtonLabel })
                        DayNightSwitch(dark = dark, label = if (dark) s.toLight else s.toDark, onToggle = onToggleTheme)
                    }
                }
            }
        }
    }
}

/**
 * The app's name, never cut off: whole if there is room, a touch smaller if that is what it takes, and on
 * the narrowest bars the store's name alone ("Al-Shorouq") rather than "Al-Shorouq Calcu…".
 */
@Composable
private fun BrandName(full: String, short: String, style: TextStyle, modifier: Modifier = Modifier) {
    val measurer = rememberTextMeasurer(cacheSize = 6)
    BoxWithConstraints(modifier) {
        val room = constraints.maxWidth
        val smaller = remember(style) { style.copy(fontSize = style.fontSize * 0.9f) }
        val fitted = remember(full, short, style, room) {
            val whole = measurer.measure(full, style, maxLines = 1, softWrap = false).size.width
            if (whole <= room) full to style
            else if (measurer.measure(full, smaller, maxLines = 1, softWrap = false).size.width <= room) full to smaller
            else short to style
        }
        BasicText(fitted.first, maxLines = 1, overflow = TextOverflow.Ellipsis, style = fitted.second)
    }
}

/** A button inside a glass group: it lights up from the touch and its content dips (.tap in the CSS). */
@Composable
fun TapButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    minWidth: androidx.compose.ui.unit.Dp = 38.dp,
    height: androidx.compose.ui.unit.Dp = 38.dp,
    content: @Composable () -> Unit,
) {
    val p = LocalPalette.current
    val source = remember { MutableInteractionSource() }
    val fx = rememberPressFx(source)
    Box(
        modifier
            .defaultMinSize(minWidth, height)
            .height(height)
            .drawBehind { pressGlow(fx, p.rim, p.press) }
            .clickable(source, null, enabled = enabled, role = Role.Button, onClickLabel = label, onClick = onClick)
            .semantics { contentDescription = label }
            .padding(horizontal = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.graphicsLayer { val k = 1f - 0.12f * fx.swell.value; scaleX = k; scaleY = k }) { content() }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.pressGlow(fx: PressFx, rim: Color, strength: Float) {
    val g = fx.glow.value
    if (g < 0.001f) return
    val at = if (fx.at == Offset.Unspecified) center else fx.at
    val r = 130.dp.toPx()
    val rr = androidx.compose.ui.geometry.CornerRadius(size.height / 2)
    drawRoundRect(
        Brush.radialGradient(listOf(rim.copy(alpha = strength * g), rim.copy(alpha = 0f)), at, r * 0.72f),
        cornerRadius = rr,
    )
}

/**
 * The actions: one capsule of glass with four keys in it, all of one shape — a sign over its name. The one
 * that matters most, Copy, sits on a pill of amber glass inside the capsule, the way the chosen option sits
 * on its pill in the Tabby / Tamara control. On a phone the capsule floats along the bottom; in a wide
 * window ([vertical]) it stands on the trailing edge, where the thumb of the hand holding the device is.
 *
 * With no amount there is nothing to copy, send or print: the amber clears out of the pill and those keys
 * dim — the glass itself stays whole (it is the signs that fade, never the pane and its shadow).
 */
@Composable
fun Dock(
    ready: Boolean,
    copied: Boolean,
    hidden: Boolean,
    vertical: Boolean,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onPrint: () -> Unit,
    /** The Details key, whenever it is laid out: the sheet wells up out of it and is drawn back into it. */
    onDetailsPlaced: (LayoutCoordinates) -> Unit,
    onDetails: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val s = LocalStrings.current
    val away by animateFloatAsState(if (hidden) 1f else 0f, Springs.Settle.float, label = "dock")
    val readiness by animateFloatAsState(if (ready) 1f else 0f, tween(280), label = "dock-ready")
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val spec = GlassSpec(bezel = 22.dp, depth = 24.dp, blur = 4.dp)
    val keyHeight = if (vertical) 60.dp else 56.dp
    // It steps back while the sheet is open. Each piece fades by itself — no buffer around the capsule,
    // so the shadow round the glass is never cut off into a box.
    val leave = Modifier.graphicsLayer {
        val k = 1f - 0.06f * away
        scaleX = k; scaleY = k
        alpha = (1f - away * 1.5f).coerceIn(0f, 1f)
        compositingStrategy = CompositingStrategy.ModulateAlpha
    }

    val copy: @Composable (Modifier) -> Unit = { m ->
        CopyKey(ready && !hidden, copied, { readiness }, rtl, onCopy, m)
    }
    val share: @Composable (Modifier) -> Unit = { m ->
        DockKey(Icons.Send, s.share, ready && !hidden, { 0.38f + 0.62f * readiness }, keyHeight, mirror = rtl, modifier = m, onClick = onShare)
    }
    val print: @Composable (Modifier) -> Unit = { m ->
        DockKey(Icons.Printer, s.print, ready && !hidden, { 0.38f + 0.62f * readiness }, keyHeight, modifier = m, onClick = onPrint)
    }
    val details: @Composable (Modifier) -> Unit = { m ->
        DockKey(Icons.Receipt, s.detailsShort, !hidden, { 1f }, keyHeight, modifier = m.onGloballyPositioned(onDetailsPlaced), onClick = onDetails)
    }

    if (vertical) {
        GlassSurface(modifier.then(leave).width(78.dp), radius = 39.dp, variant = GlassVariant.Dock, spec = spec) {
            Column(Modifier.padding(6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                copy(Modifier.fillMaxWidth().height(66.dp))
                share(Modifier.fillMaxWidth())
                print(Modifier.fillMaxWidth())
                details(Modifier.fillMaxWidth())
            }
        }
    } else {
        Box(modifier.fillMaxWidth().then(leave).padding(horizontal = 12.dp)) {
            GlassSurface(Modifier.fillMaxWidth().height(68.dp), radius = 34.dp, variant = GlassVariant.Dock, spec = spec) {
                Row(
                    Modifier.fillMaxWidth().padding(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    copy(Modifier.weight(1.3f).height(56.dp))
                    share(Modifier.weight(1f))
                    print(Modifier.weight(1f))
                    details(Modifier.weight(1f))
                }
            }
        }
    }
}

/**
 * The one primary action, on tinted glass. A band of light crosses it when the amount is copied and its sign
 * turns into a tick. [readiness] 0 … 1: with no amount the amber is all but gone and the key is plain glass.
 */
@Composable
private fun CopyKey(enabled: Boolean, copied: Boolean, readiness: () -> Float, rtl: Boolean, onCopy: () -> Unit, modifier: Modifier) {
    val p = LocalPalette.current
    val s = LocalStrings.current
    val type = LocalType.current
    val done by animateFloatAsState(if (copied) 1f else 0f, Springs.Snappy.float, label = "copied")
    val check by animateFloatAsState(if (copied) 1f else 0f, tween(380, delayMillis = 60, easing = FastOutSlowInEasing), label = "check")
    val sweep = remember { Animatable(0f) }
    LaunchedEffect(copied) {
        if (copied) { sweep.snapTo(0f); sweep.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
    }
    val source = remember { MutableInteractionSource() }
    val fx = rememberPressFx(source)
    // the ink follows the glass: dark on amber, the page's own ink on clear glass
    val ink = lerp(p.ink2, p.onTint, readiness())
    GlassSurface(
        modifier.clickable(source, null, enabled = enabled, role = Role.Button, onClickLabel = s.copyAmount, onClick = onCopy),
        radius = 28.dp, variant = GlassVariant.Tint,
        spec = GlassSpec(bezel = 18.dp, depth = 18.dp, blur = 3.dp),
        press = fx, swell = 0.04f, shadow = false,
        bodyStrength = { 0.16f + 0.84f * readiness() },
    ) {
        Spacer(Modifier.matchParentSize().drawBehind {
            val t = sweep.value
            if (t <= 0f || t >= 1f) return@drawBehind
            val a = if (t < 0.18f) t / 0.18f else 1f - (t - 0.18f) / 0.82f
            val ltr = size.width * (1.3f - 1.6f * t)
            val x = if (rtl) size.width - ltr else ltr
            val band = size.width * 0.5f
            drawRect(Brush.linearGradient(
                listOf(Color.Transparent, Color.White.copy(alpha = 0.75f * a), Color.Transparent),
                start = Offset(x - band / 2, 0f), end = Offset(x + band / 2, size.height * 0.27f),
            ))
        })
        Column(
            Modifier.matchParentSize().padding(horizontal = 4.dp).graphicsLayer { alpha = 0.5f + 0.5f * readiness() },
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.size(22.dp)) {
                Icon(Icons.Copy, ink, Modifier.graphicsLayer {
                    alpha = 1f - done; val k = 1f - 0.6f * done; scaleX = k; scaleY = k; rotationZ = 30f * done
                }, size = 22.dp)
                AnimatedCheck({ check }, ink, Modifier.graphicsLayer {
                    alpha = done; val k = 0.4f + 0.6f * done; scaleX = k; scaleY = k; rotationZ = -30f * (1f - done)
                }, size = 22.dp)
            }
            Spacer(Modifier.height(2.dp))
            BasicText(if (copied) s.copied else s.copy, maxLines = 1, overflow = TextOverflow.Ellipsis, style = type.dockItem.copy(color = ink, fontWeight = FontWeight.SemiBold))
        }
    }
}

/** One key of the dock: a sign over its name. It lights up from the touch and its content dips. */
@Composable
private fun DockKey(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    enabled: Boolean,
    strength: () -> Float,
    height: Dp,
    mirror: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val p = LocalPalette.current
    val type = LocalType.current
    TapButton(
        label = label, onClick = onClick, enabled = enabled,
        minWidth = 48.dp, height = height,
        modifier = modifier.graphicsLayer { alpha = strength() },
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Icon(icon, p.ink, Modifier.graphicsLayer { scaleX = if (mirror) -1f else 1f }, size = 22.dp)
            BasicText(label, maxLines = 1, overflow = TextOverflow.Ellipsis, style = type.dockItem.copy(color = p.ink2))
        }
    }
}
