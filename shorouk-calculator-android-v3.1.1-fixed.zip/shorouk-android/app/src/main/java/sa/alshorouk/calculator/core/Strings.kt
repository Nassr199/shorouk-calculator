package sa.alshorouk.calculator.core

import sa.alshorouk.calculator.core.Fees.FIXED_FEE
import sa.alshorouk.calculator.core.Fees.SERVICE_RATE
import sa.alshorouk.calculator.core.Fees.SETTLEMENT_TABBY
import sa.alshorouk.calculator.core.Fees.SETTLEMENT_TAMARA
import sa.alshorouk.calculator.core.Fees.TRANSFER_FEE_BASE
import sa.alshorouk.calculator.core.Fees.TRANSFER_FEE_TOTAL

/*
 * Every word of the interface in Arabic and English, carried over from constants.ts (v3.1).
 * Rich text keeps the original's tiny markup (<strong>, <code>, <li>), rendered by ui/RichText.kt.
 */

enum class Language { Ar, En }

private val THRESHOLD = "2500"
private fun f2(n: Double) = toFixed(n, 2)
private fun f1(n: Double) = toFixed(n, 1)

class Strings(
    val lang: Language,
    val appName: String,
    val appNameShort: String,
    val appTagline: String,
    val amountLabel: String,
    val amountHint: String,
    val clear: String,
    val resultLabel: String,
    val resultEmpty: String,
    val copy: String,
    val copied: String,
    val copiedToast: String,
    val copyFailed: String,
    val netShort: String,
    val feesShort: String,
    val feeShare: String,
    val breakdownLabel: String,
    val share: String,
    val print: String,
    val settlementToggle: String,
    val settlementShort: String,
    val providerLabel: String,
    val tabby: String,
    val tamara: String,
    val transferTitle: String,
    val transferHint: String,
    val detailsTitle: String,
    val guideTitle: String,
    val toDark: String,
    val toLight: String,
    val langButton: String,
    val langButtonLabel: String,
    val receiptTitle: String,
    val receiptDate: String,
    val logoAlt: String,
    val storeName: String,
    val copyAmount: String,
    val copyThis: String,
    val detailsShort: String,
    val guideShort: String,
    val close: String,
    val sheetTitle: String,
    val detailsEmpty: String,
    val glassTitle: String,
    val glassHint: String,
    val glassUnsupported: String,
    val pageTitle: String,
    val currency: String,
    val bankTransfer: String,
    val providerTabbyLabel: String,
    val providerTamaraLabel: String,
    val settlementFeeLabelProvider: String,
    val settlementFeeLabelTransfer: String,
    /** baseFee, vat, totalServiceFee, settlement, totalAmountDue, netProfit — the order of constants.ts */
    val labels: List<String>,
    val notes: List<Pair<String, String>>,
    val shareMessageTemplate: String,
    val footerText: String,
    private val settlementNote: (SettlementType?, String?, String, Boolean, Double) -> String,
) {
    val isRtl get() = lang == Language.Ar

    fun providerName(p: Provider): String =
        (if (p == Provider.Tabby) providerTabbyLabel else providerTamaraLabel).substringBefore('(').trim()

    fun settlementFeeNote(r: CalculationResult): String =
        settlementNote(r.settlementType, r.providerForSettlement, formatMoney(r.sFinal), r.settlementFeeActive, r.x)

    fun footer(year: Int) = footerText.replace("{YEAR}", year.toString())

    companion object {
        fun of(lang: Language) = if (lang == Language.Ar) AR else EN

        val AR = Strings(
            lang = Language.Ar,
            appName = "حاسبة الشروق",
            appNameShort = "الشروق",
            appTagline = "رسوم تابي وتمارا",
            amountLabel = "مبلغ الفاتورة",
            amountHint = "الصافي الذي تريد أن يصل للمتجر بعد خصم الرسوم",
            clear = "مسح المبلغ",
            resultLabel = "المطلوب من العميل",
            resultEmpty = "أدخل مبلغ الفاتورة لحساب ما تطلبه من العميل",
            copy = "نسخ",
            copied = "تم النسخ",
            copiedToast = "تم نسخ المبلغ {X}",
            copyFailed = "تعذّر النسخ، انسخ المبلغ يدويًا",
            netShort = "يصل للمتجر",
            feesShort = "الرسوم",
            feeShare = "{R}% من المبلغ",
            breakdownLabel = "من أصل {X}: يصل للمتجر {P}، والرسوم {F}",
            share = "واتساب",
            print = "طباعة",
            settlementToggle = "إضافة رسوم التسوية",
            settlementShort = "تُخصم مرة واحدة في كل دورة تسوية",
            providerLabel = "مقدم الخدمة",
            tabby = "تابي",
            tamara = "تمارا",
            transferTitle = "رسوم التحويل البنكي",
            transferHint = "تُطبَّق تلقائيًا على المبالغ من {T} ر.س فأكثر",
            detailsTitle = "تفاصيل الحساب",
            guideTitle = "دليل الرسوم والتسويات",
            toDark = "التبديل إلى الوضع الليلي",
            toLight = "التبديل إلى الوضع النهاري",
            langButton = "EN",
            langButtonLabel = "Switch to English",
            receiptTitle = "إيصال احتساب رسوم الدفع الآجل",
            receiptDate = "التاريخ",
            logoAlt = "شعار الشروق لمواد البناء",
            storeName = "الشروق لمواد البناء",
            copyAmount = "نسخ المبلغ",
            copyThis = "نسخ المبلغ {X}",
            detailsShort = "التفاصيل",
            guideShort = "الدليل",
            close = "إغلاق",
            sheetTitle = "تفاصيل الحساب ودليل الرسوم",
            detailsEmpty = "أدخل مبلغ الفاتورة لعرض تفاصيل الحساب",
            glassTitle = "انكسار الزجاج",
            glassHint = "حافة مصقولة ترسم ما خلفها حادًّا ومنكسرًا. أوقفه إذا شعرت ببطء",
            glassUnsupported = "كرت الشاشة في هذا الجهاز لم يقبل تأثير الحافة، فالزجاج يبقى مُصنفرًا",
            pageTitle = "الشروق لمواد البناء - حاسبة رسوم المتجر",
            currency = "ر.س",
            bankTransfer = "تحويل بنكي",
            providerTabbyLabel = "تابي (${f2(SETTLEMENT_TABBY)} ر.س)",
            providerTamaraLabel = "تمارا (${f2(SETTLEMENT_TAMARA)} ر.س)",
            settlementFeeLabelProvider = "رسوم التسوية (اختياري)",
            settlementFeeLabelTransfer = "رسوم التحويل البنكي (${f2(TRANSFER_FEE_TOTAL)} ر.س)",
            labels = listOf(
                "رسوم الخدمة (${f2(SERVICE_RATE * 100)}% + ${f1(FIXED_FEE)} ر.س)",
                "ضريبة القيمة المضافة (15%)",
                "إجمالي رسوم الخدمة",
                "رسوم التسوية/التحويل",
                "المبلغ المطلوب من العميل",
                "صافي ربح المتجر",
            ),
            notes = listOf(
                "رسوم التسوية (للمبالغ الأقل من $THRESHOLD ريال)" to
                    "<li>تابي: <strong>${f2(SETTLEMENT_TABBY)} ر.س</strong></li>" +
                    "<li>تمارا: <strong>${f2(SETTLEMENT_TAMARA)} ر.س</strong></li>" +
                    "<li>هذه الرسوم تُخصم <strong>مرة واحدة</strong> على إجمالي مبلغ التسوية لكل دورة. يمكنك تفعيل خيار \"إضافة رسوم التسوية\" إذا كانت هذه أول عملية في دورة التسوية الحالية، أو إذا كنت ترغب في تضمينها في حساب المبلغ المطلوب من العميل.</li>",
                "رسوم التسوية (للمبالغ $THRESHOLD ريال فأكثر)" to
                    "<li>يتم تطبيق رسوم تحويل بنكي ثابتة قدرها <strong>${f2(TRANSFER_FEE_BASE)} ر.س</strong> بالإضافة إلى ضريبة القيمة المضافة (15%)، ليصبح الإجمالي <strong>${f2(TRANSFER_FEE_TOTAL)} ر.س</strong>. هذه الرسوم إلزامية لهذه الفئة من المبالغ.</li>",
                "مواعيد معالجة التسويات الأسبوعية" to
                    "<li><strong>تمارا:</strong> تتم معالجة التسويات الأسبوعية صباح كل يوم <strong>سبت</strong>.</li>" +
                    "<li><strong>تابي:</strong> تتم معالجة التسويات الأسبوعية صباح كل يوم <strong>ثلاثاء</strong>.</li>",
            ),
            shareMessageTemplate = "حاسبة الشروق:\n- صافي ربح المتجر: {P} {C}\n- المبلغ المطلوب من العميل (مع الرسوم): {X} {C}",
            footerText = "© {YEAR} الشروق لمواد البناء. جميع الحقوق محفوظة.",
            settlementNote = { type, name, fee, active, x ->
                when (type) {
                    SettlementType.BankTransfer -> "رسوم تحويل بنكي (لأن المبلغ ${formatMoney(x)} ريال أو أكثر): <code>$fee</code> ر.س (شاملة ضريبة القيمة المضافة)."
                    SettlementType.ProviderSettlement ->
                        if (active) "رسوم تسوية $name (لأن المبلغ أقل من $THRESHOLD ريال): <code>$fee</code> ر.س"
                        else "رسوم تسوية $name غير مضافة (المبلغ أقل من $THRESHOLD ريال)."
                    null -> "لا توجد رسوم تسوية/تحويل مطبقة."
                }
            },
        )

        val EN = Strings(
            lang = Language.En,
            appName = "Al-Shorouq Calculator",
            appNameShort = "Al-Shorouq",
            appTagline = "Tabby & Tamara fees",
            amountLabel = "Invoice amount",
            amountHint = "What the store should receive after fees",
            clear = "Clear amount",
            resultLabel = "Charge the customer",
            resultEmpty = "Enter the invoice amount to see what to charge",
            copy = "Copy",
            copied = "Copied",
            copiedToast = "Copied {X}",
            copyFailed = "Couldn't copy. Copy the amount by hand.",
            netShort = "Store receives",
            feesShort = "Fees",
            feeShare = "{R}% of the total",
            breakdownLabel = "Of {X}: the store receives {P}, fees are {F}",
            share = "WhatsApp",
            print = "Print",
            settlementToggle = "Include settlement fee",
            settlementShort = "Charged once per settlement cycle",
            providerLabel = "Provider",
            tabby = "Tabby",
            tamara = "Tamara",
            transferTitle = "Bank transfer fee",
            transferHint = "Applied automatically from {T} SAR",
            detailsTitle = "Calculation details",
            guideTitle = "Fees & settlement guide",
            toDark = "Switch to dark mode",
            toLight = "Switch to light mode",
            langButton = "ع",
            langButtonLabel = "التبديل إلى العربية",
            receiptTitle = "Deferred payment fee receipt",
            receiptDate = "Date",
            logoAlt = "Al-Shorouq Building Materials logo",
            storeName = "Al-Shorouq Building Materials",
            copyAmount = "Copy amount",
            copyThis = "Copy {X}",
            detailsShort = "Details",
            guideShort = "Guide",
            close = "Close",
            sheetTitle = "Calculation details and fee guide",
            detailsEmpty = "Enter the invoice amount to see the calculation",
            glassTitle = "Glass refraction",
            glassHint = "A polished rim that shows what is behind it sharp and bent. Turn it off if motion feels slow",
            glassUnsupported = "This device's GPU did not accept the rim effect, so the glass stays frosted",
            pageTitle = "Al-Shorouq Building Materials - Merchant Fee Calculator",
            currency = "SAR",
            bankTransfer = "Bank Transfer",
            providerTabbyLabel = "Tabby (${f2(SETTLEMENT_TABBY)} SAR)",
            providerTamaraLabel = "Tamara (${f2(SETTLEMENT_TAMARA)} SAR)",
            settlementFeeLabelProvider = "Settlement Fee (Optional)",
            settlementFeeLabelTransfer = "Bank Transfer Fee (${f2(TRANSFER_FEE_TOTAL)} SAR)",
            labels = listOf(
                "Service Fee (${f2(SERVICE_RATE * 100)}% + ${f1(FIXED_FEE)} SAR)",
                "VAT (15%)",
                "Total Service Fees",
                "Settlement/Transfer Fee",
                "Amount Customer Pays",
                "Net Merchant Profit",
            ),
            notes = listOf(
                "Settlement Fees (for amounts less than $THRESHOLD SAR)" to
                    "<li>Tabby: <strong>${f2(SETTLEMENT_TABBY)} SAR</strong></li>" +
                    "<li>Tamara: <strong>${f2(SETTLEMENT_TAMARA)} SAR</strong></li>" +
                    "<li>These fees are charged <strong>once</strong> per total settlement amount for each cycle. You can enable the \"Include Settlement Fee\" option if this is the first transaction in the current settlement cycle, or if you wish to include it in the customer's payable amount.</li>",
                "Settlement Fees (for amounts $THRESHOLD SAR and above)" to
                    "<li>A fixed bank transfer fee of <strong>${f2(TRANSFER_FEE_BASE)} SAR</strong> + VAT (15%) applies, totaling <strong>${f2(TRANSFER_FEE_TOTAL)} SAR</strong>. This fee is mandatory for this amount range.</li>",
                "When are weekly settlements processed by providers?" to
                    "<li><strong>Tamara:</strong> Weekly settlements are processed every <strong>Saturday</strong>.</li>" +
                    "<li><strong>Tabby:</strong> Weekly settlements are processed every <strong>Tuesday</strong>.</li>",
            ),
            shareMessageTemplate = "Al-Shorouq Calculator:\n- Store Net Profit: {P} {C}\n- Customer Pays (w/ Fees): {X} {C}",
            footerText = "© {YEAR} Al-Shorouq Building Materials. All rights reserved.",
            settlementNote = { type, name, fee, active, x ->
                when (type) {
                    SettlementType.BankTransfer -> "Bank transfer fee (because amount ${formatMoney(x)} SAR or more): <code>$fee</code> SAR (VAT inclusive)."
                    SettlementType.ProviderSettlement ->
                        if (active) "$name settlement fee (because amount is less than $THRESHOLD SAR): <code>$fee</code> SAR"
                        else "$name settlement fee not included (amount is less than $THRESHOLD SAR)."
                    null -> "No settlement/transfer fee applied."
                }
            },
        )
    }
}

/** The WhatsApp message, built exactly as App.tsx built it (toFixed(2), no separators). */
fun shareMessage(s: Strings, r: CalculationResult): String =
    s.shareMessageTemplate
        .replace("{P}", toFixed(r.pInput, 2))
        .replace("{X}", toFixed(r.x, 2))
        .replace("{C}", s.currency)

/** What lands on the clipboard: plain "2727.91", ready to paste into the Tabby / Tamara app. */
fun clipboardValue(r: CalculationResult): String = toFixed(r.x, 2)

fun calculate(price: String, provider: Provider, includeSettlement: Boolean, s: Strings): CalculationResult =
    calculateFees(price, provider, includeSettlement, s::providerName, s.bankTransfer)
