import { useEffect, useLayoutEffect, useRef } from 'react';
import { Spring, prefersReducedMotion } from '../lib/motion';
import { splitMoney } from '../lib/format';

/*
 * Odometer money.
 *
 *  - Every digit is driven by its own spring, so a new value arriving mid-roll bends the motion
 *    instead of restarting it (type fast and watch: nothing stutters).
 *  - Digits take the shortest way round the wheel: 9 → 0 is one step forward, not nine back.
 *  - Columns are keyed by their distance from the decimal point. 999 → 1,000 rolls the three existing
 *    digits, slides them aside and brings a new column in.
 */

interface Cell {
    key: string;
    kind: 'digit' | 'sep';
    char: string;
    part: 'int' | 'dec';
    phase: 'live' | 'in';
    rank: number;          // 0 = right-most digit of the whole number (moves first)
}

const SEAT_MS = 520;
// the same damped spring as --spring in styles.css
const SEAT_EASE = 'linear(0, 0.0303, 0.1069, 0.2114, 0.3293, 0.4498, 0.5652, 0.6705, 0.7627, 0.8405, 0.9038, 0.9534, 0.9907, 1.0171, 1.0346, 1.0448, 1.0493, 1.0496, 1.047, 1.0425, 1.037, 1.031, 1.025, 1.0194, 1.0144, 1.0101, 1.0066, 1.0037, 1.0015, 0.9999, 0.9987, 0.998, 0.9976, 0.9975, 0.9976, 0.9977, 1)';
const STAGGER_MS = 16;
const MAX_STAGGER_MS = 90;
const ROLL = { stiffness: 230, damping: 24, precision: 0.002 };

const wrap = (n: number) => ((n % 10) + 10) % 10;

function layout(value: number, decimals: boolean): Omit<Cell, 'phase'>[] {
    const { int, dec } = splitMoney(value);
    const cells: Omit<Cell, 'phase'>[] = [];
    const decDigits = decimals ? dec.length : 0;
    const intChars = int.split('');
    let digitsToRight = intChars.filter((c) => c !== ',').length;
    for (const ch of intChars) {
        if (ch === ',') {
            cells.push({ key: `c${digitsToRight}`, kind: 'sep', char: ',', part: 'int', rank: 0 });
        } else {
            digitsToRight--;
            cells.push({ key: `i${digitsToRight}`, kind: 'digit', char: ch, part: 'int', rank: digitsToRight + decDigits });
        }
    }
    if (decimals) {
        cells.push({ key: 'p', kind: 'sep', char: '.', part: 'dec', rank: 0 });
        dec.split('').forEach((ch, i) => {
            cells.push({ key: `d${i}`, kind: 'digit', char: ch, part: 'dec', rank: dec.length - 1 - i });
        });
    }
    return cells;
}

// One reel per column: the ten digits and a second 0, so 9 rolls on into 0 and −1 back into 9.
const REEL = '0\n1\n2\n3\n4\n5\n6\n7\n8\n9\n0';
const REEL_STEP = 100 / 11;      // one digit, as a share of the reel's height

function Digit({ digit, rank, entering }: { digit: number; rank: number; entering: boolean }) {
    const reel = useRef<HTMLSpanElement>(null);
    const spring = useRef<Spring | null>(null);

    // The text never changes: rolling is one transform on a finished picture, so there is nothing to lay out.
    const paint = (position: number) => {
        const el = reel.current;
        if (!el) return;
        const turn = ((position % 10) + 10) % 10;
        el.style.transform = `translate3d(0, ${(-turn * REEL_STEP).toFixed(3)}%, 0)`;
    };

    useLayoutEffect(() => {
        const start = entering ? digit - 1 : digit;       // a new column rolls its digit up into place
        const s = new Spring(start, ROLL, paint);
        spring.current = s;
        paint(start);
        if (entering) s.to(digit);
        return () => s.dispose();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        const s = spring.current;
        if (!s) return;
        const from = Math.round(s.target);
        if (wrap(from) === digit) return;
        const step = ((digit - wrap(from) + 15) % 10) - 5;        // shortest way round: −5 … +4
        s.to(from + step, { delay: Math.min(MAX_STAGGER_MS, rank * STAGGER_MS) });
    }, [digit, rank]);

    return <span className="num__reel" ref={reel}>{REEL}</span>;
}

interface RollingNumberProps {
    value: number;
    /** Show the two decimals (default). */
    decimals?: boolean;
    className?: string;
}

/** How far a cell is currently displaced by a seat animation that is still running. */
function flying(node: HTMLElement): number {
    const value = getComputedStyle(node).translate;
    return value && value !== 'none' ? parseFloat(value) || 0 : 0;
}

export function RollingNumber({ value, decimals = true, className = '' }: RollingNumberProps) {
    const root = useRef<HTMLSpanElement>(null);
    const cells = layout(value, decimals);

    // A cell keeps the phase it was born with: "in" if it appeared after the first render.
    const born = useRef<Map<string, Cell['phase']> | null>(null);
    const first = born.current === null;
    const phases = born.current ?? (born.current = new Map());
    const wanted = new Set(cells.map((c) => c.key));
    phases.forEach((_phase, key) => { if (!wanted.has(key)) phases.delete(key); });
    cells.forEach((c) => { if (!phases.has(c.key)) phases.set(c.key, first ? 'live' : 'in'); });

    /*
     * When a column is added or removed, the others have new places. They are already there (layout is
     * done once, by the browser); each is shifted back to where it was and released, so it slides to its
     * new seat on the compositor. No width is animated, so nothing is laid out again frame after frame.
     */
    const seats = useRef(new Map<string, number>());
    const signature = cells.map((c) => c.key).join('|');
    useLayoutEffect(() => {
        const el = root.current;
        if (!el) return;
        const frame = (el.closest('.g') ?? el.parentElement ?? el).getBoundingClientRect();
        const still = prefersReducedMotion();
        const next = new Map<string, number>();
        el.querySelectorAll<HTMLElement>('[data-cell]').forEach((node) => {
            const key = node.dataset.cell as string;
            const offset = flying(node);
            const seat = node.getBoundingClientRect().left - frame.left - offset;
            next.set(key, seat);
            const before = seats.current.get(key);
            if (before === undefined || still || typeof node.animate !== 'function') return;
            const from = before + offset - seat;
            if (Math.abs(from) < 0.5) return;
            node.getAnimations().forEach((running) => { if (running.id === 'seat') running.cancel(); });
            let slide: Animation;
            try {
                slide = node.animate([{ translate: `${from.toFixed(2)}px 0` }, { translate: '0 0' }], { duration: SEAT_MS, easing: SEAT_EASE });
            } catch {
                slide = node.animate([{ translate: `${from.toFixed(2)}px 0` }, { translate: '0 0' }], { duration: SEAT_MS, easing: 'cubic-bezier(0.22, 1, 0.36, 1)' });
            }
            slide.id = 'seat';
        });
        seats.current = next;
    }, [signature]);

    const render = (cell: Omit<Cell, 'phase'>) => {
        const phase = phases.get(cell.key) ?? 'live';
        return cell.kind === 'sep'
            ? <span key={cell.key} className="num__sep" data-cell={cell.key} data-phase={phase}>{cell.char}</span>
            : (
                <span key={cell.key} className="num__col" data-cell={cell.key} data-phase={phase}>
                    <Digit digit={Number(cell.char)} rank={cell.rank} entering={phase === 'in'} />
                </span>
            );
    };

    return (
        <span className={`num ${className}`.trim()} aria-hidden="true" ref={root}>
            <span className="num__int">{cells.filter((c) => c.part === 'int').map(render)}</span>
            {decimals && <span className="num__dec">{cells.filter((c) => c.part === 'dec').map(render)}</span>}
        </span>
    );
}
