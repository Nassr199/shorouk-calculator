package sa.alshorouk.calculator.ui.components

import androidx.activity.compose.PredictiveBackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.paneTitle
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.launch
import sa.alshorouk.calculator.core.CalculationResult
import sa.alshorouk.calculator.core.Fees
import sa.alshorouk.calculator.core.SettlementType
import sa.alshorouk.calculator.core.formatMoney
import sa.alshorouk.calculator.core.pct
import sa.alshorouk.calculator.core.toFixed
import sa.alshorouk.calculator.ui.LocalMotion
import sa.alshorouk.calculator.ui.LocalPalette
import sa.alshorouk.calculator.ui.LocalStrings
import sa.alshorouk.calculator.ui.LocalType
import sa.alshorouk.calculator.ui.glass.GlassQuality
import sa.alshorouk.calculator.ui.glass.GlassSettings
import sa.alshorouk.calculator.ui.glass.GlassSpec
import sa.alshorouk.calculator.ui.glass.GlassSurface
import sa.alshorouk.calculator.ui.glass.GlassVariant
import sa.alshorouk.calculator.ui.glass.rememberPressFx
import sa.alshorouk.calculator.ui.motion.Springs
import sa.alshorouk.calculator.ui.motion.rubberBand
import kotlin.math.sqrt

/*
 * The sheet with the calculation details and the fee guide (components/Sheet.tsx).
 *
 * It does not slide in from an edge: it wells up out of the Details key that was pressed, like a drop of
 * glass, and is drawn back into it. From the first frame to the last, three things move as one:
 *
 *  - the drop — an outline that starts as the key's own shape and becomes the sheet's, a little rounder in
 *    mid-flight than at either end. It carries the rim of light and the shadow on every frame, at rest too:
 *    there is one whole, crisp frame on screen at all times, and it is the same frame throughout;
 *  - the glass — the sheet's own pane, lying where it will rest, seen through the drop. A growing piece of
 *    glass shows what is behind it wherever it has reached, which is exactly this;
 *  - the content — one finished picture of the sheet, growing with the drop from its top corner and
 *    clearing as it grows.
 *
 * While they move, the pane and the content are each a single texture that the GPU places — nothing in them
 * is drawn again per frame, whatever the size of the sheet (a tall phone has twice the glass of a side
 * panel; it now costs the same). The sheet is also composed ahead of time, parked out of sight and out of
 * reach, so the first frame of the first opening is not spent building it.
 *
 * Pulled by its handle the sheet follows the finger directly; let go, it settles back or — from wherever
 * the finger left it — is drawn back into the key. Android's predictive back gesture drives the same value.
 */
@Stable
class SheetMotion {
    /** 0 = folded into the Details key, 1 = open. */
    val open = Animatable(0f)
    /** How far the finger has pulled it toward the edge it would leave by, px. */
    val pull = Animatable(0f)
    /** The length of a full pull, px: the sheet's height, or its width when it is a side panel. */
    var extent by mutableFloatStateOf(1f)
    /** Where the Details key is on screen at this moment, in the root; empty before it is laid out. */
    var source: () -> Rect = { Rect.Zero }

    /** 0 = closed, 1 = fully open: what the scrim and the page behind follow. */
    fun progress(): Float = (open.value * (1f - pull.value / extent)).coerceIn(0f, 1f)
}

private enum class Tab { Details, Guide }

private val THROW_SPEED = 650.dp

/** The drop on one frame, in the coordinates of the box the sheet rests in. */
private class DropShape {
    var l = 0f; var t = 0f; var r = 0f; var b = 0f
    var radius = 0f
    /** 0 … 1: how much of the glass is there (it is gone only for the last instant, on the key itself). */
    var body = 0f
    /** 0 … 1: how much of the content has cleared. */
    var content = 0f
    var moving = false
    var shiftX = 0f
    var shiftY = 0f
}

@Composable
fun DetailsSheet(
    open: Boolean,
    motion: SheetMotion,
    result: CalculationResult,
    glass: GlassSettings,
    onClose: () -> Unit,
    /** Wide windows: a panel on the trailing edge, where the action rail is, instead of along the bottom. */
    side: Boolean = false,
) {
    val p = LocalPalette.current
    val s = LocalStrings.current
    val animate = LocalMotion.current
    val scope = rememberCoroutineScope()
    val close by rememberUpdatedState(onClose)
    var shown by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(Tab.Details) }
    val density = LocalDensity.current
    // +1 when the trailing edge is on the right (English), −1 when it is on the left (Arabic)
    val dir = if (LocalLayoutDirection.current == LayoutDirection.Rtl) -1f else 1f
    // where the sheet rests in the root
    val restAt = remember { arrayOf(Offset.Zero) }
    val outline = remember { Path() }
    val dropNow = remember { DropShape() }
    val live = open || shown

    // Composed a moment after the app has opened, then kept: opening it later only has to show it.
    var warm by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(1100); warm = true }
    // While it is parked the figures in it are left alone (typing an amount does not rebuild a hidden
    // sheet on every key); they are brought up to date the moment it is asked for.
    val held = remember { arrayOf(result) }
    if (live) held[0] = result
    val shownResult = held[0]

    val restRadius = with(density) { 36.dp.toPx() }
    val swellPx = with(density) { 22.dp.toPx() }
    val fallbackW = with(density) { 120.dp.toPx() }
    val fallbackH = with(density) { 56.dp.toPx() }
    val parked = with(density) { 6000.dp.roundToPx() }

    /** Where everything is on this frame. Reads the motion, so whoever calls it is redrawn as it changes. */
    fun settle(paneW: Float, paneH: Float): DropShape {
        val t = motion.open.value.coerceIn(0f, 1f)
        val pulled = motion.pull.value
        val shiftX = if (side) pulled * dir else 0f
        val shiftY = if (side) 0f else pulled
        // the sheet, where the finger has left it
        val sl = shiftX
        val st = shiftY
        val sr = paneW + shiftX
        val sb = paneH + shiftY
        // the key, in the same coordinates
        val from = motion.source()
        val known = from.width > 1f && from.height > 1f
        val fw = fallbackW.coerceAtMost(paneW)
        val fh = fallbackH.coerceAtMost(paneH)
        val bl = if (known) from.left - restAt[0].x else (paneW - fw) / 2f
        val bt = if (known) from.top - restAt[0].y else paneH - fh
        val br = if (known) from.right - restAt[0].x else (paneW + fw) / 2f
        val bb = if (known) from.bottom - restAt[0].y else paneH
        // it rises a shade ahead of spreading; on the way back it narrows a shade ahead of falling
        val rise = t
        val spread = t * sqrt(sqrt(t))
        dropNow.l = bl + (sl - bl) * spread
        dropNow.r = br + (sr - br) * spread
        dropNow.t = bt + (st - bt) * rise
        dropNow.b = bb + (sb - bb) * rise
        val pill = minOf((bb - bt) / 2f, restRadius)
        // surface tension: rounder in mid-flight than at either end
        val swell = 4f * t * (1f - t) * swellPx
        dropNow.radius = (pill + (restRadius - pill) * t + swell)
            .coerceAtMost(minOf(dropNow.r - dropNow.l, dropNow.b - dropNow.t) / 2f).coerceAtLeast(0f)
        dropNow.body = (t * 7f).coerceIn(0f, 1f)
        dropNow.content = ((t - 0.3f) / 0.45f).coerceIn(0f, 1f)
        dropNow.moving = t < 0.9995f
        dropNow.shiftX = shiftX
        dropNow.shiftY = shiftY
        return dropNow
    }

    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = if (side) Alignment.CenterEnd else Alignment.BottomCenter) {
        val sheetH: Dp = min(maxHeight * 0.84f, 700.dp)
        val sheetW: Dp = min(maxWidth * 0.5f, 440.dp)
        val fullPull = with(density) { (if (side) sheetW else sheetH).toPx() }
        LaunchedEffect(fullPull) { motion.extent = fullPull.coerceAtLeast(1f) }

        LaunchedEffect(open) {
            if (open) {
                shown = true
                // opened again while it was on its way out, pulled: it comes back to rest as it opens
                if (motion.pull.value != 0f) launch { motion.pull.animateTo(0f, Springs.SheetOpen.float) }
                if (animate) motion.open.animateTo(1f, Springs.SheetMorphOpen.float) else motion.open.snapTo(1f)
            } else if (shown) {
                if (animate) motion.open.animateTo(0f, Springs.SheetMorphClose.float) else motion.open.snapTo(0f)
                motion.pull.snapTo(0f)
                shown = false
            }
        }

        PredictiveBackHandler(enabled = open) { events ->
            try {
                // the drop draws back toward its key as the swipe goes
                events.collect { e -> motion.open.snapTo(1f - e.progress * 0.16f) }
                close()
            } catch (c: CancellationException) {
                scope.launch { motion.open.animateTo(1f, Springs.SheetMorphOpen.float) }
                throw c
            }
        }

        // scrim: the page dims behind; a tap on it closes
        if (live) {
            Spacer(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = motion.progress() }
                    .background(p.scrim)
                    .then(if (open) Modifier.clickable(interactionSource = null, indication = null, onClick = { close() }) else Modifier),
            )
        }
        if (!live && !warm) return@BoxWithConstraints

        val dragModifier = Modifier.pointerInput(side, dir) {
            val tracker = VelocityTracker()
            var from = 0f
            var moved = 0f
            detectDragGestures(
                onDragStart = { tracker.resetTracking(); from = motion.pull.value; moved = 0f },
                onDragEnd = {
                    val velocity = tracker.calculateVelocity()
                    val v = if (side) velocity.x * dir else velocity.y
                    val dismiss = v > THROW_SPEED.toPx() || (motion.pull.value > motion.extent * 0.28f && v > -200.dp.toPx())
                    if (dismiss) close()
                    else scope.launch { motion.pull.animateTo(0f, Springs.SheetOpen.float, initialVelocity = v) }
                },
                onDragCancel = { scope.launch { motion.pull.animateTo(0f, Springs.SheetOpen.float) } },
            ) { change, amount ->
                tracker.addPosition(change.uptimeMillis, change.position)
                change.consume()
                moved += if (side) amount.x * dir else amount.y
                var next = from + moved
                if (next < 0f) next = rubberBand(next, 220.dp.toPx(), 0.35f)    // pulled the wrong way: it gives a little, then resists
                // at once, inside this pointer event: the sheet is under the finger in the same frame
                scope.launch(start = CoroutineStart.UNDISPATCHED) { motion.pull.snapTo(next) }
            }
        }

        // The sheet's place on the screen. This box only marks it: it draws nothing and takes no touch.
        Box(
            (if (side) Modifier
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(10.dp)
                .width(sheetW)
                .fillMaxHeight()
            else Modifier
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(horizontal = 8.dp)
                .padding(bottom = 8.dp)
                .widthIn(max = 480.dp)
                .fillMaxWidth()
                .height(sheetH))
                .onGloballyPositioned { restAt[0] = it.positionInRoot() },
        ) {
        Box(
            Modifier
                .fillMaxSize()
                // closed, it waits far below the screen: nothing of it can be touched or read out
                .offset { if (live) IntOffset.Zero else IntOffset(0, parked) }
                .drawWithContent {
                    val d = settle(size.width, size.height)
                    if (d.body > 0.001f) {
                        outline.rewind()
                        outline.addRoundRect(RoundRect(d.l, d.t, d.r, d.b, CornerRadius(d.radius)))
                        drawDropShadow(outline, d.l, d.t, d.r, d.b, d.radius, p.shadow.copy(alpha = p.shadow.alpha * d.body))
                        clipPath(outline) { this@drawWithContent.drawContent() }
                        // the one frame of the sheet, moving and at rest alike
                        drawDropRim(d.l, d.t, d.r, d.b, d.radius, p.rim, p.rimHi, p.rimLo, p.rimMid, p.outline, d.body)
                    }
                }
                .then(if (live) Modifier.semantics { paneTitle = s.sheetTitle } else Modifier.clearAndSetSemantics { }),
        ) {
            // the glass: where it rests (or where the finger has it), seen through the drop
            GlassSurface(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val d = settle(size.width, size.height)
                        translationX = d.shiftX
                        translationY = d.shiftY
                        alpha = d.body
                        compositingStrategy = if (d.moving) CompositingStrategy.Offscreen else CompositingStrategy.Auto
                    },
                radius = 36.dp,
                variant = GlassVariant.Sheet,
                spec = GlassSpec(blur = 26.dp, refract = false),
                // the drop draws the shadow and the rim, around itself
                shadow = false,
                frame = false,
                // frosted from where it rests: a pull of the finger does not re-render that large blur
                anchor = { restAt[0] },
            ) { }
            // the content: one picture, growing with the drop from its top corner and clearing as it grows
            Column(
                Modifier.fillMaxSize().graphicsLayer {
                    val d = settle(size.width, size.height)
                    val paneW = size.width
                    val k = if (paneW > 1f) ((d.r - d.l) / paneW).coerceIn(0.05f, 1f) else 1f
                    transformOrigin = TransformOrigin(0f, 0f)
                    scaleX = k
                    scaleY = k
                    translationX = d.l
                    translationY = d.t
                    alpha = d.content
                    compositingStrategy = if (d.moving) CompositingStrategy.Offscreen else CompositingStrategy.Auto
                },
            ) {
                    // handle
                    Box(Modifier.fillMaxWidth().height(24.dp).then(dragModifier), contentAlignment = Alignment.Center) {
                        Spacer(Modifier.size(38.dp, 5.dp).background(p.ink3.copy(alpha = 0.4f), RoundedCornerShape(3.dp)))
                    }
                    // header: tabs and close
                    Row(
                        Modifier.fillMaxWidth().then(dragModifier).padding(start = 14.dp, end = 14.dp, top = 2.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        val type = LocalType.current
                        LensSegmented(
                            options = Tab.entries.toList(),
                            selected = tab,
                            onSelect = { tab = it },
                            label = { if (it == Tab.Details) s.detailsShort else s.guideShort },
                            modifier = Modifier.weight(1f),
                            onTrack = false, radius = 24.dp, pad = 4.dp, height = 40.dp,
                        ) { option, sel ->
                            BasicText(
                                if (option == Tab.Details) s.detailsShort else s.guideShort,
                                style = type.label.copy(color = if (sel) p.ink else p.ink2, fontSize = type.label.fontSize),
                            )
                        }
                        CloseButton(s.close) { close() }
                    }

                    // body, with soft fade at the edges
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                            .drawWithContent {
                                drawContent()
                                val top = 14.dp.toPx() / size.height
                                val bottom = 1f - 22.dp.toPx() / size.height
                                drawRect(
                                    Brush.verticalGradient(0f to Color.Transparent, top to Color.Black, bottom to Color.Black, 1f to Color.Transparent),
                                    blendMode = BlendMode.DstIn,
                                )
                            },
                    ) {
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 22.dp, end = 22.dp, top = 10.dp, bottom = 22.dp)) {
                            key(tab) {
                                PanelIn {
                                    when (tab) {
                                        Tab.Details -> {
                                            SheetTitle(s.detailsTitle)
                                            if (shownResult.hasAmount) Ledger(shownResult)
                                            else BasicText(
                                                s.detailsEmpty,
                                                style = LocalType.current.body.copy(color = p.ink2, textAlign = TextAlign.Center, fontSize = 14.sp),
                                                modifier = Modifier.fillMaxWidth().padding(vertical = 28.dp),
                                            )
                                        }
                                        Tab.Guide -> {
                                            SheetTitle(s.guideTitle)
                                            Guide()
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (glass.canRefract && glass.quality != GlassQuality.Solid) GlassSetting(glass)
            }
        }
        }
    }
}

/*
 * The drop's shadow: soft, below it, outside it only. Drawn as gradients (four edges, four corners) instead of
 * a blurred shape: a blur of a shape that changes size and roundness every frame would be regenerated every
 * frame, gradients are plain GPU fills at any size.
 */
private fun DrawScope.drawDropShadow(drop: Path, l: Float, t: Float, r: Float, b: Float, radius: Float, color: Color) {
    val reach = 26.dp.toPx()
    val dy = 9.dp.toPx()
    val top = t + dy
    val bottom = b + dy
    val peak = color.copy(alpha = color.alpha * 0.46f)
    val mid = color.copy(alpha = color.alpha * 0.15f)
    val low = color.copy(alpha = color.alpha * 0.035f)
    val none = color.copy(alpha = 0f)
    val rr = radius.coerceAtLeast(0.5f)
    clipPath(drop, ClipOp.Difference) {
        // under the drop's lower edge
        drawRect(peak, Offset(l + rr, top), Size((r - l - 2f * rr).coerceAtLeast(0f), bottom - top))
        drawRect(peak, Offset(l, top + rr), Size(rr, (bottom - top - 2f * rr).coerceAtLeast(0f)))
        drawRect(peak, Offset(r - rr, top + rr), Size(rr, (bottom - top - 2f * rr).coerceAtLeast(0f)))
        // edges: falling away from the shape
        val edgeW = (r - l - 2f * rr).coerceAtLeast(0f)
        val edgeH = (bottom - top - 2f * rr).coerceAtLeast(0f)
        drawRect(
            Brush.verticalGradient(0f to none, 0.3f to low, 0.62f to mid, 1f to peak, startY = top - reach, endY = top),
            Offset(l + rr, top - reach), Size(edgeW, reach),
        )
        drawRect(
            Brush.verticalGradient(0f to peak, 0.38f to mid, 0.7f to low, 1f to none, startY = bottom, endY = bottom + reach),
            Offset(l + rr, bottom), Size(edgeW, reach),
        )
        drawRect(
            Brush.horizontalGradient(0f to none, 0.3f to low, 0.62f to mid, 1f to peak, startX = l - reach, endX = l),
            Offset(l - reach, top + rr), Size(reach, edgeH),
        )
        drawRect(
            Brush.horizontalGradient(0f to peak, 0.38f to mid, 0.7f to low, 1f to none, startX = r, endX = r + reach),
            Offset(r, top + rr), Size(reach, edgeH),
        )
        // corners: the same fall-off, around the corner's own centre
        val outer = rr + reach
        val k = rr / outer
        val g = 1f - k
        dropCorner(Offset(l + rr, top + rr), Offset(l - reach, top - reach), outer, k, g, peak, mid, low, none)
        dropCorner(Offset(r - rr, top + rr), Offset(r - rr, top - reach), outer, k, g, peak, mid, low, none)
        dropCorner(Offset(l + rr, bottom - rr), Offset(l - reach, bottom - rr), outer, k, g, peak, mid, low, none)
        dropCorner(Offset(r - rr, bottom - rr), Offset(r - rr, bottom - rr), outer, k, g, peak, mid, low, none)
    }
}

private fun DrawScope.dropCorner(
    around: Offset, topLeft: Offset, outer: Float, k: Float, g: Float,
    peak: Color, mid: Color, low: Color, none: Color,
) {
    drawRect(
        Brush.radialGradient(
            0f to peak, k to peak, k + g * 0.38f to mid, k + g * 0.7f to low, 1f to none,
            center = around, radius = outer,
        ),
        topLeft, Size(outer, outer),
    )
}

/** The rim of the drop: bright toward the light (top-left), an answering glint opposite, a soft band inside. */
private fun DrawScope.drawDropRim(
    l: Float, t: Float, r: Float, b: Float, radius: Float,
    rim: Color, hi: Float, lo: Float, mid: Float, outline: Color, strength: Float,
) {
    if (strength <= 0.003f) return
    val w = 1.5.dp.toPx()
    val band = 3.dp.toPx()
    drawRoundRect(
        color = rim.copy(alpha = lo * 0.6f * strength),
        topLeft = Offset(l + band / 2f, t + band / 2f), size = Size((r - l - band).coerceAtLeast(0f), (b - t - band).coerceAtLeast(0f)),
        cornerRadius = CornerRadius((radius - band / 2f).coerceAtLeast(0f)), style = Stroke(band),
    )
    drawRoundRect(
        brush = Brush.linearGradient(
            0f to rim.copy(alpha = hi * strength), 0.32f to rim.copy(alpha = lo * 1.6f * strength),
            0.7f to rim.copy(alpha = lo * 1.6f * strength), 1f to rim.copy(alpha = mid * strength),
            start = Offset(l, t), end = Offset(r, b),
        ),
        topLeft = Offset(l + w / 2f, t + w / 2f), size = Size((r - l - w).coerceAtLeast(0f), (b - t - w).coerceAtLeast(0f)),
        cornerRadius = CornerRadius((radius - w / 2f).coerceAtLeast(0f)), style = Stroke(w),
    )
    drawRoundRect(
        color = outline.copy(alpha = outline.alpha * strength),
        topLeft = Offset(l, t), size = Size(r - l, b - t),
        cornerRadius = CornerRadius(radius), style = Stroke(0.5.dp.toPx()),
    )
}

@Composable
private fun CloseButton(label: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    val source = remember { MutableInteractionSource() }
    val fx = rememberPressFx(source)
    Box(
        Modifier
            .size(48.dp)
            .graphicsLayer { val k = 1f + 0.05f * fx.swell.value; scaleX = k; scaleY = k }
            .background(p.well, CircleShape)
            .clickable(source, null, role = Role.Button, onClickLabel = label, onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) { Icon(Icons.Close, p.ink, size = 18.dp) }
}

@Composable
private fun SheetTitle(text: String) {
    val p = LocalPalette.current
    BasicText(text, style = LocalType.current.title.copy(color = p.ink), modifier = Modifier.padding(bottom = 14.dp).semantics { heading() })
}

/** panel-in: 420 ms, from 10 dp lower and transparent. */
@Composable
private fun PanelIn(content: @Composable () -> Unit) {
    val animate = LocalMotion.current
    val t = remember { Animatable(if (animate) 0f else 1f) }
    LaunchedEffect(Unit) { t.animateTo(1f, tween(420, easing = FastOutSlowInEasing)) }
    Column(Modifier.graphicsLayer { alpha = t.value; translationY = (1f - t.value) * 10.dp.toPx() }) { content() }
}

/**
 * A row of the ledger. The rows used to arrive one after another; now the sheet's own opening is the
 * entrance, and a picture that is at rest is what lets that opening be one texture instead of a redraw per
 * frame. Kept as the single place a row is wrapped.
 */
@Composable
private fun ItemIn(index: Int, content: @Composable () -> Unit) {
    Column { content() }
}

/*
 * The calculation as an invoice reads (components/Ledger.tsx): what the store keeps, plus each fee,
 * equals what the customer pays. Arithmetic is always shown as a left-to-right line — inside an Arabic
 * sentence the bidi algorithm would reorder numbers, brackets and operators.
 */
@Composable
private fun Ledger(r: CalculationResult) {
    val p = LocalPalette.current
    val s = LocalStrings.current
    val type = LocalType.current
    val f = ::formatMoney
    val l = s.labels
    val settleLabel = if (r.settlementType == SettlementType.BankTransfer) s.settlementFeeLabelTransfer else s.settlementFeeLabelProvider

    data class Item(val label: String, val value: String, val sign: String? = null, val math: String? = null, val note: String? = null, val sub: Boolean = false)
    val items = listOf(
        Item(l[5], f(r.pInput)),
        Item(l[0], f(r.baseFee), "+", "${f(r.x)} × ${pct(Fees.SERVICE_RATE)} + ${toFixed(Fees.FIXED_FEE, 2)} = ${f(r.baseFee)}"),
        Item(l[1], f(r.vat), "+", "${f(r.baseFee)} × ${pct(Fees.VAT_RATE)} = ${f(r.vat)}"),
        Item(l[2], f(r.totalServiceFee), math = "${f(r.baseFee)} + ${f(r.vat)} = ${f(r.totalServiceFee)}", sub = true),
        Item(settleLabel, f(r.sFinal), "+", note = s.settlementFeeNote(r)),
    )

    Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
        items.forEachIndexed { i, it ->
            ItemIn(i) {
                Column(Modifier.padding(start = if (it.sub) 12.dp else 0.dp)) {
                    LedgerRow(it.label, it.value, it.sign, emphasise = false, small = it.sub)
                    if (it.math != null) {
                        androidx.compose.runtime.CompositionLocalProvider(
                            androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Ltr,
                        ) {
                            BasicText(
                                it.math, style = type.money(12.sp, androidx.compose.ui.text.font.FontWeight.Normal).copy(color = p.ink3),
                                modifier = Modifier.fillMaxWidth().padding(top = 3.dp),
                            )
                        }
                    }
                    if (it.note != null) {
                        BasicText(
                            RichText.styled(it.note, p.ink, type.figures),
                            style = type.hint.copy(color = p.ink3),
                            modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                }
            }
        }
        ItemIn(items.size) {
            Column {
                Spacer(Modifier.fillMaxWidth().height(1.dp).background(p.hairline.copy(alpha = p.hairline.alpha * 2f)))
                Spacer(Modifier.height(10.dp))
                LedgerRow(l[4], f(r.x), null, emphasise = true, suffix = s.currency)
            }
        }
    }
}

@Composable
private fun LedgerRow(label: String, value: String, sign: String?, emphasise: Boolean, small: Boolean = false, suffix: String? = null) {
    val p = LocalPalette.current
    val type = LocalType.current
    Row(verticalAlignment = Alignment.Bottom) {
        BasicText(
            label,
            style = (if (emphasise) type.bodyStrong else type.body).copy(color = if (emphasise) p.ink else p.ink2, fontSize = if (small) 14.sp else type.body.fontSize),
            modifier = Modifier.weight(1f, fill = false),
        )
        // dotted leader between label and value
        Spacer(
            Modifier
                .weight(1f)
                .padding(horizontal = 8.dp)
                .height(10.dp)
                .drawWithContent {
                    val y = size.height - 2.dp.toPx()
                    drawLine(
                        p.hairline.copy(alpha = p.hairline.alpha * 2.2f), Offset(0f, y), Offset(size.width, y), 1.dp.toPx(),
                        pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(1.dp.toPx(), 4.dp.toPx())),
                        cap = androidx.compose.ui.graphics.StrokeCap.Round,
                    )
                },
        )
        Row(verticalAlignment = Alignment.Bottom) {
            if (sign != null) {
                BasicText(sign, style = type.money(16.sp, androidx.compose.ui.text.font.FontWeight.Normal).copy(color = p.ink3))
                Spacer(Modifier.width(3.dp))
            }
            BasicText(value, style = type.money(if (emphasise) 19.sp else 16.sp, if (emphasise) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Medium).copy(color = p.ink))
            if (suffix != null) {
                Spacer(Modifier.width(4.dp))
                BasicText(suffix, style = type.caption.copy(color = p.ink2), modifier = Modifier.padding(bottom = 2.dp))
            }
        }
    }
}

@Composable
private fun Guide() {
    val p = LocalPalette.current
    val s = LocalStrings.current
    val type = LocalType.current
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        s.notes.forEachIndexed { i, (q, a) ->
            ItemIn(i) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(p.well.copy(alpha = p.well.alpha * 0.7f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    BasicText(q.trimEnd(':', '：', ' '), style = type.bodyStrong.copy(color = p.ink))
                    for (item in RichText.items(a)) {
                        Row {
                            BasicText("•", style = type.body.copy(color = p.amberInk), modifier = Modifier.padding(end = 8.dp))
                            BasicText(RichText.styled(item, p.ink, type.figures), style = type.body.copy(color = p.ink2, fontSize = 14.sp))
                        }
                    }
                }
            }
        }
    }
}

/** Edge refraction on / off (it is the costly part of the glass on slow phones). */
@Composable
private fun GlassSetting(glass: GlassSettings) {
    val p = LocalPalette.current
    val s = LocalStrings.current
    val type = LocalType.current
    val on = glass.quality == GlassQuality.Full
    val change = { next: Boolean -> glass.set(if (next) GlassQuality.Full else GlassQuality.Frost, byUser = true) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .padding(bottom = 14.dp)
            .background(p.well.copy(alpha = p.well.alpha * 0.7f), RoundedCornerShape(22.dp))
            .clickable(interactionSource = null, indication = null, role = Role.Switch) { change(!on) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            BasicText(s.glassTitle, style = type.bodyStrong.copy(color = p.ink, fontSize = 14.sp))
            BasicText(if (glass.rimRefused) s.glassUnsupported else s.glassHint, style = type.hint.copy(color = p.ink2))
        }
        Spacer(Modifier.width(12.dp))
        LiquidSwitch(on, onDragToggle = change)
    }
}
