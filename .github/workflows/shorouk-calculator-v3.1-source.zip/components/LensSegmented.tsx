import React, { useEffect, useLayoutEffect, useRef } from 'react';
import { Spring, VelocityTracker, clamp, rubberBand } from '../lib/motion';
import { Lens, createLens, getQuality, subscribeQuality, useGlass } from '../lib/glass';
import { haptic } from '../lib/interaction';

/*
 * Segmented control with a liquid lens.
 *
 * The selected option sits on a soft pill. Over it rides a clear lens that bends and slightly magnifies
 * whatever is underneath. Tap an option and the lens springs across, stretching with its speed like a
 * drop of water; or grab it and drag: it lifts off the surface, follows the finger, resists at the ends
 * and settles on the nearest option carrying the speed of the throw.
 */

export interface LensOption<T extends string> {
    value: T;
    /** Accessible name. */
    label: string;
    /** What is drawn in the segment (defaults to the label). */
    content?: React.ReactNode;
}

interface LensSegmentedProps<T extends string> {
    options: LensOption<T>[];
    value: T;
    onChange: (value: T) => void;
    ariaLabel?: string;
    labelledBy?: string;
    className?: string;
    /** false: the track is frosted only (use on a surface that is already glass, like the sheet). */
    refract?: boolean;
}

const TRAVEL = { stiffness: 320, damping: 26, precision: 0.05 };
const CHASE = { stiffness: 900, damping: 54, precision: 0.05 };
const LIFT = { stiffness: 420, damping: 28, precision: 0.002 };
const DRAG_SLOP = 4;

export function LensSegmented<T extends string>({ options, value, onChange, ariaLabel, labelledBy, className = '', refract = true }: LensSegmentedProps<T>) {
    const root = useRef<HTMLDivElement>(null);
    const track = useRef<HTMLSpanElement>(null);
    const pill = useRef<HTMLSpanElement>(null);
    const lensEl = useRef<HTMLSpanElement>(null);
    const buttons = useRef<(HTMLButtonElement | null)[]>([]);
    const index = Math.max(0, options.findIndex((o) => o.value === value));

    useGlass(track, { bezel: 16, depth: 18, blur: 5, saturate: 1.4, refract });

    // everything the pointer handlers need, kept out of React state so a drag never re-renders
    const live = useRef({
        lefts: [] as number[], width: 0, height: 0,
        x: null as Spring | null, lift: null as Spring | null, lens: null as Lens | null,
        pointer: -1, grab: 0, startClientX: 0, dragging: false, onLens: false,
        tracker: new VelocityTracker(), index, ready: false, pointerAt: -1e9,
    });
    live.current.index = index;
    const latest = useRef({ options, onChange });
    latest.current = { options, onChange };

    const paint = () => {
        const s = live.current;
        const p = pill.current;
        const l = lensEl.current;
        if (!p || !l || !s.x || !s.lift) return;
        const lift = s.lift.value;
        const speed = Math.abs(s.x.velocity);
        const stretch = Math.min(speed / 2600, 0.22);
        const sx = 1 + stretch + lift * 0.05;
        const sy = 1 - stretch * 0.25 + lift * 0.14;
        const transform = `translate3d(${s.x.value.toFixed(2)}px, 0, 0) scale(${sx.toFixed(4)}, ${sy.toFixed(4)})`;
        p.style.transform = transform;
        l.style.transform = transform;
        l.style.setProperty('--lift', lift.toFixed(3));
        p.style.setProperty('--lift', lift.toFixed(3));
        s.lens?.setStrength(1 + lift * 1.6);
    };

    // springs live for the lifetime of the control
    useLayoutEffect(() => {
        const s = live.current;
        s.x = new Spring(0, TRAVEL, paint);
        s.lift = new Spring(0, LIFT, paint);
        return () => { s.x?.dispose(); s.lift?.dispose(); s.lens?.dispose(); s.lens = null; };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // measure the segments, size the lens, rebuild its refraction map
    useLayoutEffect(() => {
        const el = root.current;
        if (!el) return;
        const s = live.current;

        const measure = () => {
            const first = buttons.current[0];
            if (!first) return;
            s.lefts = buttons.current.map((b) => (b ? b.offsetLeft : 0));
            const w = Math.round(first.offsetWidth);
            const h = Math.round(first.offsetHeight);
            const resized = w !== s.width || h !== s.height;
            s.width = w;
            s.height = h;
            for (const node of [pill.current, lensEl.current]) {
                if (!node) continue;
                node.style.width = `${w}px`;
                node.style.height = `${h}px`;
                node.style.top = `${first.offsetTop}px`;
            }
            if (resized || !s.lens) buildLens();
            if (!s.dragging) s.x?.snap(s.lefts[s.index] ?? 0);
            s.ready = true;
        };

        const buildLens = () => {
            s.lens?.dispose();
            s.lens = null;
            const node = lensEl.current;
            if (!node) return;
            if (getQuality() !== 'full' || s.width < 8) { node.style.removeProperty('backdrop-filter'); return; }
            s.lens = createLens({ width: s.width, height: s.height, radius: s.height / 2, bezel: Math.min(15, s.height / 2), depth: 9, zoom: 1.035, dispersion: 0.07 });
            node.style.setProperty('backdrop-filter', `url(#${s.lens.id})`);
            paint();
        };

        measure();
        const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(measure) : null;
        observer?.observe(el);
        const unsubscribe = subscribeQuality(buildLens);
        // Arabic ⇄ English mirrors the segments without resizing anything: measure again
        const direction = new MutationObserver(measure);
        direction.observe(document.documentElement, { attributes: true, attributeFilter: ['dir'] });
        return () => { observer?.disconnect(); direction.disconnect(); unsubscribe(); };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [options.length]);

    // selection changed from outside (or after a tap): spring across, lifting a little on the way
    useEffect(() => {
        const s = live.current;
        if (!s.ready || s.dragging || !s.x || !s.lift) return;
        const target = s.lefts[index] ?? 0;
        if (Math.abs(s.x.target - target) < 0.5) return;
        s.lift.to(0.55);
        s.x.to(target, { config: TRAVEL, onRest: () => s.lift?.to(0) });
    }, [index]);

    const pick = (i: number) => {
        const option = latest.current.options[i];
        if (option && i !== live.current.index) { haptic(6); latest.current.onChange(option.value); }
    };

    const nearest = (x: number): number => {
        const { lefts } = live.current;
        let best = 0;
        for (let i = 1; i < lefts.length; i++) if (Math.abs(lefts[i] - x) < Math.abs(lefts[best] - x)) best = i;
        return best;
    };

    const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
        if (e.button !== 0) return;
        const el = root.current;
        const s = live.current;
        if (!el || !s.x || !s.lift) return;
        const px = e.clientX - el.getBoundingClientRect().left;
        s.onLens = px >= s.x.value && px <= s.x.value + s.width;
        s.grab = s.onLens ? px - s.x.value : s.width / 2;
        s.pointer = e.pointerId;
        s.startClientX = e.clientX;
        s.dragging = false;
        s.tracker.reset();
        s.tracker.add(e.clientX);
        el.setPointerCapture(e.pointerId);
        if (s.onLens) s.lift.to(1);                              // the lens rises under the finger
    };

    const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
        const el = root.current;
        const s = live.current;
        if (!el || e.pointerId !== s.pointer || !s.x || !s.lift) return;
        s.tracker.add(e.clientX);
        if (!s.dragging) {
            if (Math.abs(e.clientX - s.startClientX) < DRAG_SLOP) return;
            s.dragging = true;
            s.lift.to(1);
        }
        const min = Math.min(...s.lefts);
        const max = Math.max(...s.lefts);
        let x = e.clientX - el.getBoundingClientRect().left - s.grab;
        // past either end it gives a little, then holds
        if (x < min) x = min + rubberBand(x - min, s.width * 0.22);
        if (x > max) x = max + rubberBand(x - max, s.width * 0.22);
        if (s.onLens) s.x.drag(x, s.tracker.get());
        else s.x.to(x, { config: CHASE });                        // pressed elsewhere: the lens runs to the finger
    };

    const finish = (e: React.PointerEvent<HTMLDivElement>, cancelled: boolean) => {
        const el = root.current;
        const s = live.current;
        if (!el || e.pointerId !== s.pointer || !s.x || !s.lift) return;
        s.pointer = -1;
        s.pointerAt = performance.now();
        if (el.hasPointerCapture(e.pointerId)) el.releasePointerCapture(e.pointerId);
        const wasDragging = s.dragging;
        s.dragging = false;
        const settleLift = () => s.lift?.to(0);

        if (cancelled) {
            s.x.to(s.lefts[s.index] ?? 0, { config: TRAVEL, onRest: settleLift });
            return;
        }
        if (wasDragging) {
            const velocity = s.tracker.get();
            const min = Math.min(...s.lefts);
            const max = Math.max(...s.lefts);
            const landing = nearest(clamp(s.x.value + velocity * 0.12, min, max));
            s.x.to(s.lefts[landing], { velocity, config: TRAVEL, onRest: settleLift });
            pick(landing);
            return;
        }
        // a tap: choose the segment under the finger
        const px = e.clientX - el.getBoundingClientRect().left;
        const tapped = s.lefts.findIndex((left) => px >= left && px <= left + s.width);
        if (tapped === -1 || tapped === s.index) { settleLift(); return; }
        s.lift.to(0.55);
        s.x.to(s.lefts[tapped], { config: TRAVEL, onRest: settleLift });
        pick(tapped);
    };

    const onKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>, i: number) => {
        const rtl = document.documentElement.dir === 'rtl';
        const forward = rtl ? 'ArrowLeft' : 'ArrowRight';
        const back = rtl ? 'ArrowRight' : 'ArrowLeft';
        let next = -1;
        if (e.key === forward || e.key === 'ArrowDown') next = (i + 1) % options.length;
        if (e.key === back || e.key === 'ArrowUp') next = (i - 1 + options.length) % options.length;
        if (next === -1) return;
        e.preventDefault();
        pick(next);
        buttons.current[next]?.focus();
    };

    return (
        <div
            ref={root}
            className={`seg ${className}`.trim()}
            role="radiogroup"
            aria-label={ariaLabel}
            aria-labelledby={labelledBy}
            style={{ '--count': options.length } as React.CSSProperties}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={(e) => finish(e, false)}
            onPointerCancel={(e) => finish(e, true)}
        >
            <span className="seg__track g__bg" ref={track} aria-hidden="true" />
            <span className="seg__pill" ref={pill} aria-hidden="true" />
            {options.map((option, i) => (
                <button
                    key={option.value}
                    ref={(node) => { buttons.current[i] = node; }}
                    type="button"
                    role="radio"
                    aria-checked={i === index}
                    aria-label={option.content ? option.label : undefined}
                    tabIndex={i === index ? 0 : -1}
                    className="seg__opt"
                    // pointer taps are resolved in finish(); this handles keyboard and assistive-technology activation
                    onClick={() => { if (performance.now() - live.current.pointerAt > 500) pick(i); }}
                    onKeyDown={(e) => onKeyDown(e, i)}
                >
                    {option.content ?? option.label}
                </button>
            ))}
            <span className="seg__lens" ref={lensEl} aria-hidden="true" />
        </div>
    );
}
