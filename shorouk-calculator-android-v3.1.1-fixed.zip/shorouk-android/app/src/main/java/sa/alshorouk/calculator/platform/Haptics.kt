package sa.alshorouk.calculator.platform

import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View

/*
 * Haptics through the View's own feedback constants rather than raw vibration: they are tuned by each
 * manufacturer for its motor (Qualcomm and MediaTek phones alike), respect the system "touch feedback"
 * setting, and need no VIBRATE permission.
 */
class Haptics(private val view: View) {
    /** A light tick: a segment snapping into place, a switch flipping. */
    fun tick() = perform(
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) HapticFeedbackConstants.SEGMENT_TICK
        else HapticFeedbackConstants.CLOCK_TICK,
    )

    /** A switch toggled. */
    fun toggle(on: Boolean) = perform(
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE -> if (on) HapticFeedbackConstants.TOGGLE_ON else HapticFeedbackConstants.TOGGLE_OFF
            else -> HapticFeedbackConstants.CLOCK_TICK
        },
    )

    /** Something done: the amount copied. */
    fun confirm() = perform(
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.CONFIRM
        else HapticFeedbackConstants.VIRTUAL_KEY,
    )

    fun reject() = perform(
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.REJECT
        else HapticFeedbackConstants.LONG_PRESS,
    )

    private fun perform(constant: Int) {
        runCatching { view.performHapticFeedback(constant) }
    }
}
