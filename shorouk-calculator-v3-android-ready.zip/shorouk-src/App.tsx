import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { I18N } from './constants';
import type { Provider } from './types';
import { calculateFees } from './lib/calc';
import { fill, formatMoney } from './lib/format';
import { Spring, watchFrameRate } from './lib/motion';
import { getQuality, qualityChosenByUser, setQuality } from './lib/glass';
import { haptic } from './lib/interaction';
import { usePreferences } from './hooks/usePreferences';
import { Scene } from './components/Scene';
import { Dock, TopBar } from './components/Chrome';
import { AmountField } from './components/AmountField';
import { ResultSlab } from './components/ResultSlab';
import { LensSegmented } from './components/LensSegmented';
import { SettlementRow } from './components/SettlementRow';
import { Sheet } from './components/Sheet';
import { PrintReceipt, ProviderMark, Toast } from './components/Extras';

/** The horizon runs just inside the top edge of the result panel: the sun rises over it. */
const HORIZON_INSET = 6;
const SUNRISE = { stiffness: 26, damping: 10.5, precision: 0.0015 };
const SUNSET = { stiffness: 70, damping: 17, precision: 0.0015 };

function legacyCopy(text: string): boolean {
    try {
        const area = document.createElement('textarea');
        area.value = text;
        area.setAttribute('readonly', '');
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.appendChild(area);
        area.select();
        const ok = document.execCommand('copy');
        document.body.removeChild(area);
        return ok;
    } catch {
        return false;
    }
}

function offsetWithin(el: HTMLElement, ancestor: HTMLElement): number {
    let top = 0;
    let node: HTMLElement | null = el;
    while (node && node !== ancestor) {
        top += node.offsetTop;
        node = node.offsetParent as HTMLElement | null;
    }
    return top;
}

const App: React.FC = () => {
    // State (as in the first version)
    const [price, setPrice] = useState<string>('');
    const [provider, setProvider] = useState<Provider>('tabby');
    const [includeSettlement, setIncludeSettlement] = useState<boolean>(false);
    const { theme, lang, toggleTheme, toggleLang } = usePreferences();
    const t = I18N[lang];
    const currency = t.currencySuffix.trim();

    // Calculation logic: unchanged, in lib/calc.ts
    const calculations = useMemo(
        () => calculateFees({ price, provider, includeSettlement, lang }),
        [price, provider, includeSettlement, lang],
    );
    const hasAmount = calculations.P_input > 0;

    // Handlers (print / WhatsApp message unchanged)
    const handlePrint = () => window.print();
    const handleShare = () => {
        const data = I18N[lang];
        const cur = data.currencySuffix.trim();
        const msg = data.shareMessageTemplate
            .replace('{P}', `${calculations.P_input.toFixed(2)}`)
            .replace('{X}', `${calculations.X.toFixed(2)}`)
            .replace(/{C}/g, cur);
        window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank', 'noopener,noreferrer');
    };

    // Copy the amount to charge (plain "2727.91", ready to paste into the Tabby / Tamara app)
    const [copied, setCopied] = useState(false);
    const [toast, setToast] = useState({ text: '', show: false, ok: true });
    const [copyLive, setCopyLive] = useState('');
    const timers = useRef<number[]>([]);
    useEffect(() => () => timers.current.forEach((id) => clearTimeout(id)), []);

    const copyAmount = useCallback(async () => {
        if (calculations.P_input <= 0) return;
        const value = calculations.X.toFixed(2);
        let ok = false;
        try {
            await navigator.clipboard.writeText(value);
            ok = true;
        } catch {
            ok = legacyCopy(value);
        }
        const message = ok ? fill(t.ui.copiedToast, { X: `${formatMoney(calculations.X)} ${currency}` }) : t.ui.copyFailed;
        timers.current.forEach((id) => clearTimeout(id));
        setCopied(ok);
        setToast({ text: message, show: true, ok });
        setCopyLive('');   // emptied first so copying the same amount twice is announced twice
        if (ok) haptic(8);
        timers.current = [
            window.setTimeout(() => setCopyLive(message), 40),
            window.setTimeout(() => setCopied(false), 1800),
            window.setTimeout(() => setToast((s) => ({ ...s, show: false })), 2200),
            window.setTimeout(() => { setToast((s) => ({ ...s, text: '' })); setCopyLive(''); }, 2700),
        ];
    }, [calculations, t, currency]);

    useEffect(() => { setCopied(false); }, [calculations.X]);

    /* ---- the scene: horizon behind the result panel, sun up while there is an amount ---- */

    const appRef = useRef<HTMLDivElement>(null);
    const slabRef = useRef<HTMLElement>(null);

    useLayoutEffect(() => {
        const app = appRef.current;
        const slab = slabRef.current;
        if (!app || !slab) return;
        let last = -1;
        const place = () => {
            const horizon = Math.round(offsetWithin(slab, app) + HORIZON_INSET);
            if (horizon === last) return;
            last = horizon;
            app.style.setProperty('--hz', `${horizon}px`);
        };
        place();
        const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(place) : null;
        observer?.observe(app);
        app.querySelectorAll('.stack > *').forEach((el) => observer?.observe(el));
        document.fonts?.ready.then(place).catch(() => { /* no font loading API */ });
        window.addEventListener('resize', place);
        return () => { observer?.disconnect(); window.removeEventListener('resize', place); };
    }, []);

    const sun = useRef<Spring | null>(null);
    useLayoutEffect(() => {
        const app = appRef.current;
        if (!app) return;
        const spring = new Spring(0, SUNRISE, (value) => app.style.setProperty('--sun', value.toFixed(4)));
        sun.current = spring;
        return () => { spring.dispose(); sun.current = null; };
    }, []);
    useEffect(() => {
        sun.current?.to(hasAmount ? 1 : 0, { config: hasAmount ? SUNRISE : SUNSET });
    }, [hasAmount]);

    // The entrance plays once; its helper attribute (set before first paint in index.html) is then removed.
    useEffect(() => {
        const id = window.setTimeout(() => document.documentElement.removeAttribute('data-intro'), 1900);
        return () => clearTimeout(id);
    }, []);

    // Edge refraction is the costly part of the glass. If this device cannot keep up, fall back to plain
    // frosted glass, unless the person has chosen for themselves (the switch is in the details sheet).
    useEffect(() => {
        if (getQuality() !== 'full' || qualityChosenByUser()) return;
        return watchFrameRate(() => {
            if (getQuality() === 'full' && !qualityChosenByUser()) setQuality('frost', 'auto');
        });
    }, []);

    /* ---- details sheet ---- */

    const [sheetOpen, setSheetOpen] = useState(false);
    const sheetIsOpen = useRef(false);

    const openSheet = useCallback(() => {
        if (sheetIsOpen.current) return;
        sheetIsOpen.current = true;
        const app = appRef.current;
        // the page recedes around the middle of what is on screen now
        if (app) app.style.transformOrigin = `50% ${Math.round(window.scrollY + window.innerHeight * 0.42)}px`;
        setSheetOpen(true);
        // the phone's back gesture closes the sheet instead of leaving the app
        try { window.history.pushState({ sheet: true }, ''); } catch { /* history unavailable */ }
    }, []);

    const closeSheet = useCallback(() => {
        if (!sheetIsOpen.current) return;                         // closing twice must not go back twice
        sheetIsOpen.current = false;
        setSheetOpen(false);
        try { if (window.history.state?.sheet) window.history.back(); } catch { /* history unavailable */ }
    }, []);

    useEffect(() => {
        // a reload while the sheet was open leaves its history entry behind: neutralise it
        try { if (window.history.state?.sheet) window.history.replaceState(null, ''); } catch { /* ignore */ }
        const onPop = () => { sheetIsOpen.current = false; setSheetOpen(false); };
        window.addEventListener('popstate', onPop);
        return () => window.removeEventListener('popstate', onPop);
    }, []);

    useEffect(() => {
        document.documentElement.classList.toggle('sheet-open', sheetOpen);
    }, [sheetOpen]);

    const onSheetProgress = useCallback((p: number) => {
        const app = appRef.current;
        if (!app) return;
        if (p < 0.002) {
            app.style.removeProperty('transform');
            app.style.removeProperty('border-radius');
            return;
        }
        app.style.transform = `scale(${(1 - p * 0.055).toFixed(4)})`;
        app.style.borderRadius = `${(p * 34).toFixed(1)}px`;
    }, []);

    // Screen readers hear the result once typing pauses, not on every keystroke
    const [announcement, setAnnouncement] = useState('');
    useEffect(() => {
        if (!hasAmount) { setAnnouncement(''); return; }
        const id = window.setTimeout(
            () => setAnnouncement(`${t.ui.resultLabel}: ${formatMoney(calculations.X)} ${currency}`),
            900,
        );
        return () => clearTimeout(id);
    }, [calculations.X, hasAmount, t, currency]);

    return (
        <>
            <div className="app" ref={appRef} inert={sheetOpen}>
                <Scene />
                <div className="col">
                    <TopBar t={t} theme={theme} onToggleTheme={toggleTheme} onToggleLang={toggleLang} />

                    <main className="stack">
                        <AmountField
                            value={price}
                            onChange={setPrice}
                            label={t.ui.amountLabel}
                            hint={t.ui.amountHint}
                            currency={currency}
                            clearLabel={t.ui.clear}
                        />

                        <ResultSlab t={t} result={calculations} onCopy={copyAmount} slabRef={slabRef} />

                        <LensSegmented<Provider>
                            className="providers"
                            ariaLabel={t.ui.providerLabel}
                            value={provider}
                            onChange={setProvider}
                            options={[
                                { value: 'tabby', label: t.ui.tabby, content: <ProviderMark provider="tabby" name={t.ui.tabby} /> },
                                { value: 'tamara', label: t.ui.tamara, content: <ProviderMark provider="tamara" name={t.ui.tamara} /> },
                            ]}
                        />

                        <SettlementRow
                            t={t}
                            result={calculations}
                            includeSettlement={includeSettlement}
                            onChange={(next) => { setIncludeSettlement(next); haptic(6); }}
                            provider={provider}
                        />
                    </main>

                    <footer className="footer">
                        {t.footerText.replace('{YEAR}', new Date().getFullYear().toString())}
                    </footer>
                </div>
            </div>

            <Dock
                t={t}
                ready={hasAmount}
                copied={copied}
                hidden={sheetOpen}
                onCopy={copyAmount}
                onShare={handleShare}
                onPrint={handlePrint}
                onDetails={openSheet}
            />
            <Sheet t={t} result={calculations} open={sheetOpen} onClose={closeSheet} onProgress={onSheetProgress} />
            <Toast text={toast.text} show={toast.show} ok={toast.ok} />
            <div className="sr-only" aria-live="polite">{announcement}</div>
            <div className="sr-only" role="status" aria-live="polite">{copyLive}</div>
            <PrintReceipt t={t} result={calculations} lang={lang} />
        </>
    );
};

export default App;
