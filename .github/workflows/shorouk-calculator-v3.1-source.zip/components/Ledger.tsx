import React from 'react';
import type { CalculationResult, I18nData } from '../types';
import { FIXED_FEE, SERVICE_RATE, VAT_RATE } from '../constants';
import { formatMoney as f } from '../lib/format';

interface LedgerItem {
    key: string;
    label: string;
    value: string;
    math?: string;      // left-to-right arithmetic line, reads the same in Arabic and English
    note?: string;      // explanatory sentence (HTML from constants.ts)
    sign?: string;
    sub?: boolean;
}

const pct = (rate: number) => `${+(rate * 100).toFixed(2)}%`;

/**
 * The calculation as an invoice reads: what the store keeps, plus each fee, equals what the
 * customer pays. Arithmetic is shown as plain left-to-right lines: mixed into an Arabic sentence,
 * numbers, brackets and operators get reordered by the bidi algorithm and become hard to follow.
 */
export function Ledger({ t, result }: { t: I18nData; result: CalculationResult }) {
    const s = t.currencySuffix;
    const d = t.calculationDetails;
    const L = t.labels;
    const settleLabel = result.settlementType === 'bank_transfer' ? t.settlementFeeLabel_transfer : t.settlementFeeLabel_provider;

    const items: LedgerItem[] = [
        { key: 'net', label: L[5], value: f(result.P_input) },
        {
            key: 'base', sign: '+', label: L[0], value: f(result.baseFee),
            math: `${f(result.X)} × ${pct(SERVICE_RATE)} + ${FIXED_FEE.toFixed(2)} = ${f(result.baseFee)}`,
        },
        {
            key: 'vat', sign: '+', label: L[1], value: f(result.vat),
            math: `${f(result.baseFee)} × ${pct(VAT_RATE)} = ${f(result.vat)}`,
        },
        {
            key: 'svc', sub: true, label: L[2], value: f(result.totalServiceFee),
            math: `${f(result.baseFee)} + ${f(result.vat)} = ${f(result.totalServiceFee)}`,
        },
        {
            key: 'settle', sign: '+', label: settleLabel, value: f(result.S_final),
            note: d.settlementFee(result.settlementType, result.providerForSettlement, f(result.S_final), s, result.settlementFeeActive, result.X),
        },
    ];

    return (
        <div className="ledger">
            {items.map((it, i) => (
                <div
                    key={it.key}
                    className={`ledger__item${it.sub ? ' ledger__item--sub' : ''}`}
                    style={{ '--i': i } as React.CSSProperties}
                    data-row={it.key}
                >
                    <div className="ledger__row">
                        <span className="ledger__label">{it.label}</span>
                        <span className="ledger__leader" aria-hidden="true" />
                        <span className="ledger__value money">
                            {it.sign && <span className="ledger__sign">{it.sign}</span>}
                            {it.value}
                        </span>
                    </div>
                    {it.math && <p className="ledger__math" dir="ltr">{it.math}</p>}
                    {it.note && <p className="ledger__formula" dangerouslySetInnerHTML={{ __html: it.note }} />}
                </div>
            ))}
            <div className="ledger__rule" aria-hidden="true" />
            <div className="ledger__item ledger__item--total" style={{ '--i': items.length } as React.CSSProperties} data-row="total">
                <div className="ledger__row">
                    <span className="ledger__label">{L[4]}</span>
                    <span className="ledger__leader" aria-hidden="true" />
                    <span className="ledger__value">
                        <span className="money">{f(result.X)}</span> <small>{s.trim()}</small>
                    </span>
                </div>
            </div>
        </div>
    );
}
