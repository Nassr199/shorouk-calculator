package sa.alshorouk.calculator.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sa.alshorouk.calculator.core.CalculationResult
import sa.alshorouk.calculator.core.Fees
import sa.alshorouk.calculator.core.Provider
import sa.alshorouk.calculator.core.SettlementType
import sa.alshorouk.calculator.core.fill
import sa.alshorouk.calculator.core.toFixed
import sa.alshorouk.calculator.ui.LocalPalette
import sa.alshorouk.calculator.ui.LocalStrings
import sa.alshorouk.calculator.ui.LocalType
import sa.alshorouk.calculator.ui.glass.GlassSpec
import sa.alshorouk.calculator.ui.glass.GlassSurface
import sa.alshorouk.calculator.ui.motion.Springs

/*
 * Below 2,500 the store decides whether to add the provider's settlement fee, and the fee shown follows
 * the chosen provider (rolling between 28.75 and 25.00). From 2,500 the calculation always applies the bank
 * transfer fee, so the switch gives way to a row that says so — a switch that does nothing would be a lie.
 */
@Composable
fun SettlementRow(
    result: CalculationResult,
    include: Boolean,
    provider: Provider,
    onChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val s = LocalStrings.current
    val type = LocalType.current
    val transfer = result.settlementType == SettlementType.BankTransfer
    val mode by animateFloatAsState(if (transfer) 1f else 0f, Springs.Gentle.float, label = "settle-mode")
    val fee = Fees.settlementFor(provider)

    GlassSurface(
        modifier = modifier.fillMaxWidth(),
        radius = 28.dp,
        spec = GlassSpec(bezel = 18.dp, depth = 22.dp, blur = 6.dp),
    ) {
        Box(Modifier.fillMaxWidth().heightIn(min = 68.dp), contentAlignment = Alignment.Center) {
            // the switch face
            if (mode < 0.999f) {
                val feeColor by animateColorAsState(if (include) p.amberInk else p.ink2.copy(alpha = 0.8f), tween(320), label = "fee")
                Row(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 68.dp)
                        .graphicsLayer { alpha = 1f - mode; translationY = -mode * 10.dp.toPx() }
                        .toggleable(
                            value = include,
                            enabled = !transfer,
                            role = Role.Switch,
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onValueChange = onChange,
                        )
                        .semantics { contentDescription = "${s.settlementToggle}، ${s.settlementShort}، ${toFixed(fee, 2)} ${s.currency}" }
                        .padding(start = 18.dp, end = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Column(Modifier.weight(1f)) {
                        BasicText(s.settlementToggle, style = type.bodyStrong.copy(color = p.ink))
                        BasicText(s.settlementShort, style = type.hint.copy(color = p.ink2))
                    }
                    Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.clearAndSetSemantics { }) {
                        RollingNumber(fee, type.money(15.sp), feeColor, decimalScale = 1f, decimalAlpha = 1f)
                        Spacer(Modifier.width(4.dp))
                        BasicText(s.currency, style = type.tiny.copy(color = feeColor, fontSize = 11.sp), modifier = Modifier.padding(bottom = 2.dp))
                    }
                    LiquidSwitch(include, onDragToggle = onChange)
                }
            }
            // the bank transfer face
            if (mode > 0.001f) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 68.dp)
                        .graphicsLayer { alpha = mode; translationY = (1f - mode) * 10.dp.toPx() }
                        .semantics(mergeDescendants = true) { }
                        .padding(start = 14.dp, end = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Box(Modifier.size(40.dp).background(Color(0x33E9A41C), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Bank, p.amberInk, size = 21.dp)
                    }
                    Column(Modifier.weight(1f)) {
                        BasicText(s.transferTitle, style = type.bodyStrong.copy(color = p.ink))
                        BasicText(fill(s.transferHint, mapOf("T" to "2,500")), style = type.hint.copy(color = p.ink2))
                    }
                    Row(verticalAlignment = Alignment.Bottom) {
                        BasicText(toFixed(Fees.TRANSFER_FEE_TOTAL, 2), style = type.money(15.sp).copy(color = p.amberInk))
                        Spacer(Modifier.width(4.dp))
                        BasicText(s.currency, style = type.tiny.copy(color = p.amberInk, fontSize = 11.sp), modifier = Modifier.padding(bottom = 2.dp))
                    }
                }
            }
        }
    }
}
