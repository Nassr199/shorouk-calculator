import React, { forwardRef, useRef } from 'react';
import { GlassOptions, useGlass } from '../lib/glass';

/*
 * A Liquid Glass surface.
 *
 * The glass itself is a separate layer (.g__bg) behind the content rather than the element's own
 * background. An element with a backdrop filter hides everything behind it from its descendants, so if
 * the panel carried the filter, a lens inside it (segmented thumb, switch) could no longer see the scene.
 * Keeping the filter on a sibling layer lets lenses refract the panel they sit on.
 */

interface GlassProps extends GlassOptions {
    as?: React.ElementType;
    /** regular: frosted panel · clear: little frost, for small controls · tint: amber, for the primary action */
    variant?: 'regular' | 'clear' | 'tint';
    className?: string;
    children?: React.ReactNode;
    [prop: string]: unknown;
}

export const Glass = forwardRef<HTMLElement, GlassProps>(function Glass(
    { as: Tag = 'div', variant = 'regular', className = '', children, bezel, depth, blur, saturate, dispersion, refract, ...rest },
    ref,
) {
    const layer = useRef<HTMLSpanElement>(null);
    useGlass(layer, { bezel, depth, blur, saturate, dispersion, refract });
    return (
        <Tag ref={ref} className={`g g--${variant} ${className}`.trim()} {...rest}>
            <span className="g__bg" ref={layer} aria-hidden="true" />
            {children}
        </Tag>
    );
});
