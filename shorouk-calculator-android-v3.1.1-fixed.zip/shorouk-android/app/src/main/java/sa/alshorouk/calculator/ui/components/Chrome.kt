package sa.alshorouk.calculator.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import sa.alshorouk.calculator.ui.LocalPalette
import sa.alshorouk.calculator.ui.LocalStrings
import sa.alshorouk.calculator.ui.LocalType
import sa.alshorouk.calculator.ui.glass.GlassSpec
import sa.alshorouk.calculator.ui.glass.GlassSurface
import sa.alshorouk.calculator.ui.glass.GlassVariant
import sa.alshorouk.calculator.ui.glass.PressFx
import sa.alshorouk.calculator.ui.glass.rememberPressFx
import sa.alshorouk.calculator.ui.motion.Springs

/* The floating layer (components/Chrome.tsx): brand and view controls at the top, actions in the dock. */

@Composable
fun TopBar(
    dark: Boolean,
    compactName: Boolean,
    onToggleTheme: (Offset) -> Unit,
    onToggleLang: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val s = LocalStrings.current
    val type = LocalType.current
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        GlassSurface(
            Modifier.weight(1f, fill = false).height(46.dp),
            radius = 23.dp, variant = GlassVariant.Clear,
            spec = GlassSpec(bezel = 14.dp, depth = 16.dp, blur = 3.dp),
        ) {
            Row(Modifier.fillMaxHeight().padding(start = 8.dp, end = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                StoreLogoTile()
                Spacer(Modifier.width(9.dp))
                BasicText(
                    s.appName, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = type.brand.copy(color = p.ink).let { if (compactName) it.copy(fontSize = it.fontSize * 0.93f) else it },
                    modifier = Modifier.semantics { heading() },
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        GlassSurface(
            Modifier.height(46.dp),
            radius = 23.dp, variant = GlassVariant.Clear,
            spec = GlassSpec(bezel = 14.dp, depth = 16.dp, blur = 3.dp),
        ) {
            Row(Modifier.fillMaxHeight().padding(4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                LanguageLens(lang = s.lang, onToggle = onToggleLang, modifier = Modifier.semantics { contentDescription = s.langButtonLabel })
                DayNightSwitch(dark = dark, label = if (dark) s.toLight else s.toDark, onToggle = onToggleTheme)
            }
        }
    }
}

/** A button inside a glass group: it lights up from the touch and its content dips (.tap in the CSS). */
@Composable
fun TapButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    minWidth: androidx.compose.ui.unit.Dp = 38.dp,
    height: androidx.compose.ui.unit.Dp = 38.dp,
    content: @Composable () -> Unit,
) {
    val p = LocalPalette.current
    val source = remember { MutableInteractionSource() }
    val fx = rememberPressFx(source)
    Box(
        modifier
            .defaultMinSize(minWidth, height)
            .height(height)
            .drawBehind { pressGlow(fx, p.rim, p.press) }
            .clickable(source, null, enabled = enabled, role = Role.Button, onClickLabel = label, onClick = onClick)
            .semantics { contentDescription = label }
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.graphicsLayer { val k = 1f - 0.12f * fx.swell.value; scaleX = k; scaleY = k }) { content() }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.pressGlow(fx: PressFx, rim: Color, strength: Float) {
    val g = fx.glow.value
    if (g < 0.001f) return
    val at = if (fx.at == Offset.Unspecified) center else fx.at
    val r = 130.dp.toPx()
    val rr = androidx.compose.ui.geometry.CornerRadius(size.height / 2)
    drawRoundRect(
        Brush.radialGradient(listOf(rim.copy(alpha = strength * g), rim.copy(alpha = 0f)), at, r * 0.72f),
        cornerRadius = rr,
    )
}

/**
 * The actions. On a phone they are a bar floating over the bottom of the page; on a tablet or any wide
 * window ([vertical]) they become a rail on the trailing edge, where the thumb of the hand holding the
 * device already is, and the page keeps its full height.
 */
@Composable
fun Dock(
    ready: Boolean,
    copied: Boolean,
    hidden: Boolean,
    vertical: Boolean,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onPrint: () -> Unit,
    onDetails: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val s = LocalStrings.current
    val away by animateFloatAsState(if (hidden) 1f else 0f, Springs.Spring.float, label = "dock")
    val enabled by animateFloatAsState(if (ready) 1f else 0.42f, tween(260), label = "dock-ready")
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl

    val copy: @Composable (Modifier) -> Unit = { m ->
        CopyButton(ready && !hidden, copied, enabled, vertical, rtl, onCopy, m)
    }
    val group: @Composable () -> Unit = {
        DockItem(Icons.Send, s.share, ready && !hidden, enabled, vertical, mirror = rtl, onClick = onShare)
        DockItem(Icons.Printer, s.print, ready && !hidden, enabled, vertical, onClick = onPrint)
        DockItem(Icons.Receipt, s.detailsShort, !hidden, 1f, vertical, onClick = onDetails)
    }
    val groupSpec = GlassSpec(bezel = 18.dp, depth = 20.dp, blur = 10.dp)

    if (vertical) {
        Column(
            modifier
                .graphicsLayer { translationX = away * 150.dp.toPx() * (if (rtl) -1f else 1f); alpha = 1f - away * 0.6f }
                .width(84.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            copy(Modifier.fillMaxWidth().height(88.dp))
            GlassSurface(Modifier.fillMaxWidth(), radius = 30.dp, variant = GlassVariant.Dock, spec = groupSpec) {
                Column(Modifier.fillMaxWidth().padding(4.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) { group() }
            }
        }
    } else {
        Row(
            modifier
                .fillMaxWidth()
                .graphicsLayer { translationY = away * 140.dp.toPx(); alpha = 1f - away * 0.6f }
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            copy(Modifier.weight(1f).height(60.dp))
            GlassSurface(Modifier.height(60.dp), radius = 30.dp, variant = GlassVariant.Dock, spec = groupSpec) {
                Row(Modifier.padding(4.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) { group() }
            }
        }
    }
}

/** The one primary action, in tinted glass. A band of light crosses it when the amount is copied. */
@Composable
private fun CopyButton(enabled: Boolean, copied: Boolean, alpha: Float, vertical: Boolean, rtl: Boolean, onCopy: () -> Unit, modifier: Modifier) {
    val p = LocalPalette.current
    val s = LocalStrings.current
    val type = LocalType.current
    val done by animateFloatAsState(if (copied) 1f else 0f, Springs.Snappy.float, label = "copied")
    val check by animateFloatAsState(if (copied) 1f else 0f, tween(380, delayMillis = 60, easing = FastOutSlowInEasing), label = "check")
    val sweep = remember { Animatable(0f) }
    LaunchedEffect(copied) {
        if (copied) { sweep.snapTo(0f); sweep.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
    }
    val source = remember { MutableInteractionSource() }
    val fx = rememberPressFx(source)
    GlassSurface(
        modifier
            .graphicsLayer { this.alpha = alpha }
            .clickable(source, null, enabled = enabled, role = Role.Button, onClickLabel = s.copyAmount, onClick = onCopy),
        radius = 30.dp, variant = GlassVariant.Tint,
        spec = GlassSpec(bezel = 18.dp, depth = 20.dp, blur = 8.dp),
        press = fx,
    ) {
        Spacer(Modifier.matchParentSize().drawBehind {
            val t = sweep.value
            if (t <= 0f || t >= 1f) return@drawBehind
            val a = if (t < 0.18f) t / 0.18f else 1f - (t - 0.18f) / 0.82f
            val ltr = size.width * (1.3f - 1.6f * t)
            val x = if (rtl) size.width - ltr else ltr
            val band = size.width * 0.5f
            drawRect(Brush.linearGradient(
                listOf(Color.Transparent, Color.White.copy(alpha = 0.75f * a), Color.Transparent),
                start = Offset(x - band / 2, 0f), end = Offset(x + band / 2, size.height * 0.27f),
            ))
        })
        val icon: @Composable () -> Unit = {
            Box(Modifier.size(if (vertical) 24.dp else 20.dp)) {
                Icon(Icons.Copy, p.onTint, Modifier.graphicsLayer {
                    this.alpha = 1f - done; val k = 1f - 0.6f * done; scaleX = k; scaleY = k; rotationZ = 30f * done
                }, size = if (vertical) 24.dp else 20.dp)
                AnimatedCheck({ check }, p.onTint, Modifier.graphicsLayer {
                    this.alpha = done; val k = 0.4f + 0.6f * done; scaleX = k; scaleY = k; rotationZ = -30f * (1f - done)
                }, size = if (vertical) 24.dp else 20.dp)
            }
        }
        if (vertical) {
            Column(Modifier.matchParentSize().padding(6.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                icon()
                Spacer(Modifier.height(6.dp))
                BasicText(if (copied) s.copied else s.copy, maxLines = 1, style = type.dockItem.copy(color = p.onTint, fontSize = type.dockItem.fontSize * 1.1f))
            }
        } else {
            Row(Modifier.matchParentSize().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                icon()
                Spacer(Modifier.width(8.dp))
                BasicText(if (copied) s.copied else s.copyAmount, maxLines = 1, style = type.button.copy(color = p.onTint))
            }
        }
    }
}

@Composable
private fun DockItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    enabled: Boolean,
    alpha: Float,
    vertical: Boolean,
    mirror: Boolean = false,
    onClick: () -> Unit,
) {
    val p = LocalPalette.current
    val type = LocalType.current
    TapButton(
        label = label, onClick = onClick, enabled = enabled,
        minWidth = 60.dp, height = if (vertical) 62.dp else 52.dp,
        modifier = (if (vertical) Modifier.fillMaxWidth() else Modifier).graphicsLayer { this.alpha = alpha },
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(if (vertical) 3.dp else 1.dp)) {
            Icon(icon, p.ink, Modifier.graphicsLayer { scaleX = if (mirror) -1f else 1f }, size = if (vertical) 23.dp else 21.dp)
            BasicText(label, maxLines = 1, style = type.dockItem.copy(color = p.ink2))
        }
    }
}
