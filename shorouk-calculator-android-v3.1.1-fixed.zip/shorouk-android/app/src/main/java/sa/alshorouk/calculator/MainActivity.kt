package sa.alshorouk.calculator

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Display
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import sa.alshorouk.calculator.ui.CalculatorApp
import sa.alshorouk.calculator.ui.glass.GlassSettings

class MainActivity : ComponentActivity() {
    private lateinit var glass: GlassSettings

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        glass = GlassSettings(applicationContext)
        applySystemBars(dark = resources.configuration.nightUi())
        preferHighestRefreshRate()

        setContent {
            CalculatorApp(glass = glass, onDarkChanged = ::applySystemBars)
        }
    }

    /** Transparent bars over the scene; light or dark icons to match the sky. */
    private fun applySystemBars(dark: Boolean) {
        val style = if (dark) SystemBarStyle.dark(Color.TRANSPARENT)
        else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
        enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
    }

    /*
     * Many Qualcomm and MediaTek phones run apps at 60 Hz unless they ask for more. Ask for the fastest mode
     * at the current resolution, so springs and drags move at 90/120/144 Hz where the panel allows. LTPO
     * panels still drop the rate on their own while nothing moves.
     */
    private fun preferHighestRefreshRate() {
        runCatching {
            val display: Display = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display else null)
                ?: @Suppress("DEPRECATION") windowManager.defaultDisplay
            val current = display.mode
            val best = display.supportedModes
                .filter { it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight }
                .maxByOrNull { it.refreshRate } ?: return
            if (best.modeId != current.modeId || best.refreshRate > current.refreshRate) {
                window.attributes = window.attributes.apply { preferredDisplayModeId = best.modeId }
            }
        }
    }
}

private fun android.content.res.Configuration.nightUi(): Boolean =
    (uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
