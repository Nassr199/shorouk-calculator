import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './styles.css';
import { initGlass } from './lib/glass';
import { initLight, initPress } from './lib/interaction';
import { loadArabicType } from './lib/arabicType';

// glass quality is decided before the first render; press feedback and the tilt-driven highlight are page-wide
initGlass();
initPress();
initLight();

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = createRoot(rootElement);
  const start = () => root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
  // In Arabic, wait a moment for the typeface (it comes from the offline cache after the first visit) so the
  // page is drawn once, in its own letters, instead of being redrawn when the font arrives.
  if (document.documentElement.lang === 'ar') {
    const patience = new Promise((resolve) => setTimeout(resolve, 700));
    Promise.race([loadArabicType(), patience]).then(start, start);
  } else {
    start();
  }
}

// Offline support / installability (production builds only, so dev reloads never hit a stale cache)
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch((err) => {
      console.warn('Service worker registration failed:', err);
    });
  });
}
