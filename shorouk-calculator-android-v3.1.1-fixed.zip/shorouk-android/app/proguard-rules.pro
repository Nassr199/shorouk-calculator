# Nothing in the app is reached by reflection; R8's defaults (with the libraries' own consumer rules)
# are enough. Keep line numbers so a crash report still points at the right line.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
