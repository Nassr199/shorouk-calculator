import { Spring, prefersReducedMotion } from './motion';

/*
 * Two document-level behaviours shared by every glass control:
 *
 *  - Press: an element marked data-press lights up from the exact point it was touched and swells a
 *    little, then springs back (the CSS reads --px / --py and [data-pressed]).
 *  - Light: the bright arc on every glass rim turns with the phone's tilt (or the mouse on a desktop),
 *    the way a highlight slides around a real glass edge. CSS reads --la, an angle in degrees.
 */

const MIN_PRESS_MS = 130;   // a quick tap still shows the press

export function initPress(): () => void {
    let current: HTMLElement | null = null;
    let downAt = 0;
    let timer = 0;

    const release = () => {
        const el = current;
        if (!el) return;
        current = null;
        const wait = Math.max(0, MIN_PRESS_MS - (performance.now() - downAt));
        timer = window.setTimeout(() => el.removeAttribute('data-pressed'), wait);
    };

    const onDown = (e: PointerEvent) => {
        if (e.button !== 0) return;
        const el = (e.target as Element | null)?.closest<HTMLElement>('[data-press]');
        if (!el || el.matches(':disabled, [aria-disabled="true"]')) return;
        clearTimeout(timer);
        current?.removeAttribute('data-pressed');
        const rect = el.getBoundingClientRect();
        el.style.setProperty('--px', `${(((e.clientX - rect.left) / rect.width) * 100).toFixed(1)}%`);
        el.style.setProperty('--py', `${(((e.clientY - rect.top) / rect.height) * 100).toFixed(1)}%`);
        el.setAttribute('data-pressed', 'true');
        current = el;
        downAt = performance.now();
    };

    document.addEventListener('pointerdown', onDown, { passive: true });
    document.addEventListener('pointerup', release, { passive: true });
    document.addEventListener('pointercancel', release, { passive: true });
    return () => {
        document.removeEventListener('pointerdown', onDown);
        document.removeEventListener('pointerup', release);
        document.removeEventListener('pointercancel', release);
        clearTimeout(timer);
    };
}

const MAX_TURN = 26;        // degrees the highlight may turn either way
const DEAD_ZONE = 2.5;       // degrees of highlight turn below which nothing moves

export function initLight(): () => void {
    if (prefersReducedMotion()) return () => {};
    const root = document.documentElement;
    let written = 0;
    const spring = new Spring(0, { stiffness: 60, damping: 16, precision: 0.05 }, (angle) => {
        if (Math.abs(angle - written) < 0.25) return;
        written = angle;
        root.style.setProperty('--la', `${angle.toFixed(1)}deg`);
    });

    // small changes (a hand that is never perfectly still) are ignored, so the page is not repainted for nothing
    const aim = (unit: number) => {
        const angle = Math.max(-1, Math.min(1, unit)) * MAX_TURN;
        if (Math.abs(angle - spring.target) >= DEAD_ZONE) spring.to(angle);
    };

    const onTilt = (e: DeviceOrientationEvent) => {
        if (e.gamma == null) return;
        aim(e.gamma / 30);                                         // 30° of roll = full turn of the highlight
    };
    const onPointer = (e: PointerEvent) => {
        if (e.pointerType !== 'mouse') return;
        aim((e.clientX / window.innerWidth) * 2 - 1);
    };

    window.addEventListener('deviceorientation', onTilt, { passive: true });
    window.addEventListener('pointermove', onPointer, { passive: true });
    return () => {
        window.removeEventListener('deviceorientation', onTilt);
        window.removeEventListener('pointermove', onPointer);
        spring.dispose();
        root.style.removeProperty('--la');
    };
}

/** Light vibration on supported phones. */
export const haptic = (ms: number) => {
    try { navigator.vibrate?.(ms); } catch { /* not supported */ }
};
